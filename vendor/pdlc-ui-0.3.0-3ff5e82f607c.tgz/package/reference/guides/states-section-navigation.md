# SectionNavigation: состояния

## variants

Horizontal сохраняет прежний контракт; vertical использует тот же текущий пункт, focus и tokens, располагая ссылки колонкой. Stories: Default, Vertical

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Самостоятельного disabled-контракта нет; доступность предметных действий задаёт продукт.

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Компонент не выполняет запросов; ошибки ресурса передаются отдельному ResourceStateView.

## long-content

Длинная подпись и содержимое остаются читаемыми на 320/375 px; элементы управления доступны. Stories: LongContent

## selection

URL/current контролирует вызывающий Router. aria-current=page и location оформляются одинаково; native ссылки и fragment сохраняются. Stories: Usage, Vertical

## keyboard

Tab/Shift+Tab переходят между ссылками; Enter использует настоящий href/Router. Это navigation, не tablist со стрелками. Stories: Default, Usage

## focus

Видимый focus-ring сохраняется при смене текущего пункта и оформления; навигация не переводит фокус на другие элементы сама. Stories: Default, Usage

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: Default, Vertical, LongContent
