# Input: состояния

## variants

Default и inline используют один CSS-контракт React/SSR. Inline не меняет native form semantics и callbacks. Stories: Default, Inline, SemanticHeading, WithAction, Color

## sizes

Отдельный size-контракт отсутствует; размер определяется общей компоновкой или содержимым.

## disabled

Недоступный контрол не выполняет действие и не принимает фокус. Stories: Disabled, Color

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

Ошибка связана с полем и доступна вспомогательным технологиям. Stories: Invalid

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: LongContent

## selection

Native color picker подтверждает HEX; reset восстанавливает defaultValue без дополнительных change. Браузер/ОС владеет диалогом выбора. Stories: Color

## keyboard

Tab и активация штатной клавишей; для overlay проверить Escape и возврат на trigger. Stories: Default, Usage, WithAction, Color

## focus

Фокус видим; открытие/закрытие не теряет текущую точку взаимодействия. Stories: Default, Usage, WithAction, Color

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent, WithAction, Color
