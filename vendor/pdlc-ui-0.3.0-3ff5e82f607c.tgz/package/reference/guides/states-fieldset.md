# Fieldset: состояния

## variants

Видимый и визуально скрытый legend сохраняют доступное имя native группы. Stories: Default, HiddenLegend

## sizes

Размер группы задаёт содержание; typography легенды и её переносы принадлежат Base.

## disabled

Native disabled блокирует дочерние controls и исключает их из FormData; действует стандартное исключение первой legend. Stories: Disabled

## pending

Запросов нет. Владелец может передать disabled на время своей операции.

## loading

Группа не загружает ресурс; ResourceState передаётся содержимым.

## empty

Пустота предметного каталога определяется продуктом.

## error

Ошибки отдельных полей оформляются FormField; группа не придумывает результат валидации.

## long-content

Длинный legend переносится в доступной ширине без page overflow. Stories: LongContent

## selection

Значения принадлежат дочерним controls. Fieldset не запускает onChange при mount или смене disabled.

## keyboard

Tab и активация используют native controls; disabled controls пропускаются, сама группа не получает tabIndex. Stories: Default, Disabled

## focus

Видимый focus дочерних Input/Checkbox задаёт Base. Изменение оформления не заменяет controls. Stories: Default

## mobile

320/375/1920/2560, три темы, standard/large: legend не создаёт min-content overflow. Stories: LongContent
