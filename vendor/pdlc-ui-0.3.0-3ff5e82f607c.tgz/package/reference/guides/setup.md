# Подключение React

Импортируйте компоненты из `@pdlc/ui/ui`, providers из `@pdlc/ui/lib`,
переводы `pdlcLocales` из `@pdlc/ui/i18n`, стили `@pdlc/ui/tokens.css`.
Сохраняйте существующую Tailwind-интеграцию продукта: классы Base и примеров
должны входить в source scan. Утилитарные классы примера не заменяют tokens.css.

Поле `setup` перечисляет дополнительные контексты компонента. Примеры являются
React-компонентами: они не создают DOM root и не дублируют окружение приложения.
Для платформенных подписей настройте I18nextProvider с ru/en ресурсами Base.
Компоненты useUiLabels имеют встроенные ru/en fallback-подписи.

Текстовый поиск: SearchInput получает native onChange/value/defaultValue и
необязательный clear={label, onClear}; запрос, debounce и URL остаются у продукта.
Это не SearchableSelect: выбор ресурса и запрос текста имеют разные контракты.
Для accessible label/ошибки используйте FormField или отдельный Label.

В Vite и Vitest используйте `createUiProviderDedupe` из `@pdlc/ui/build`:

```ts
import { createUiProviderDedupe } from "@pdlc/ui/build";

export default {
  resolve: { dedupe: createUiProviderDedupe() },
};
```

Приложение и Base должны получать одни экземпляры React и context providers.
Иначе совместимые peer-версии могут создать раздельные контексты, и общие
компоненты не увидят Router/i18n приложения. Список принадлежит Base.

ThemeToggle и ThemeMenuItems требуют ThemeProvider. По умолчанию он использует
общую cookie/localStorage настройку темы. Изолированные previews передают
`theme` и `onThemeChange`; управляемый режим не читает и не сохраняет настройку.
Пример:

```tsx
const [theme, setTheme] = useState<"light" | "dark" | "gray">("light");
<ThemeProvider theme={theme} onThemeChange={setTheme}>
  {children}
</ThemeProvider>;
```

Ссылки навигации требуют React Router. UnsavedChangesGuard требует data router
(createBrowserRouter/createMemoryRouter + RouterProvider); MemoryRouter недостаточно.
Его пример создаёт собственный router, поэтому не оборачивайте пример вторым router.

ServiceSwitcher читает PlatformServicesProvider. URL реального каталога передаёт
продукт из своей конфигурации. Примеры используют синтетический data URL.
AppShell/PlatformHeader требуют окружение темы, маршрутов и каталога сервисов.

Примеры не выполняют настоящий SSO или запись в продукт. Сохранение в памяти
примера не подтверждает надёжность продуктового autosave. Компоненты получают
данные и callbacks; API, DTO, доступ и подтверждение записанной версии принадлежат продукту.

## Общий каркас и продуктовая композиция

Продукт использует AppShell; собственные aside/main и копия мобильного drawer не нужны. Для групп проектов используйте renderNavigation; для контекста и действий — renderHeader с PlatformHeader. Справочник показывает тот же каркас. Controls открываются отдельно в Storybook; внутри приложения показывается только один Canvas.

Имя, логотип и поддерживаемые цветовые параметры читает PlatformProvider. ThemeProvider задаёт тему; демонстрации темы используют controlled-режим без записи пользовательской cookie. Отдельного алгоритма брендовой палитры у справочника нет.

Vite: `createUiFontAssetsPlugin()` из `@pdlc/ui/build` добавляется в plugins.
Он поставляет notices и provenance встроенных fonts в dist независимо от CSS
preprocessor. Продукт не копирует реализацию build-hook.

Готовность переводов проверяется штатным `useTranslation(undefined, { i18n,
useSuspense: false }).ready` из react-i18next. Он владеет подпиской и cleanup;
локальный useEffect с on/off initialized не нужен. Конкретный i18n instance,
namespaces, resources, язык и композиция providers принадлежат приложению.
