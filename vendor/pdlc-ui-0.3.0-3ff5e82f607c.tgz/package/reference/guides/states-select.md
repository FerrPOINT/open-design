# Select: состояния

## variants

У компонента нет собственного перечисления визуальных вариантов; композиция показана отдельно.

## sizes

Trigger 40/44 px; длинный список прокручивается в пределах viewport. Stories: Default, Multiple, VisibleRows

## disabled

Недоступный контрол не выполняет действие и не принимает фокус. Stories: Disabled, DisabledOption

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Пустой список явно показывает отсутствие вариантов, выбор не подставляется. Stories: Empty

## error

Недоступный ID сохраняется, invalid передаётся на trigger. Stories: Invalid, MissingSelection

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: LongContent

## selection

Изменить значение с клавиатуры и проверить отображаемый выбор. Stories: Default, Usage, Multiple, VisibleRows

## keyboard

Tab и активация штатной клавишей; для overlay проверить Escape и возврат на trigger. Stories: Default, Usage, InDialog

## focus

Фокус видим; открытие/закрытие не теряет текущую точку взаимодействия. Stories: Default, Usage, InDialog

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: LongContent
