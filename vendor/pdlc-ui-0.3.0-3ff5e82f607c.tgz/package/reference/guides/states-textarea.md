# Textarea: состояния

## variants

Default и inline используют один CSS-контракт React/SSR. Inline не меняет native form semantics и callbacks. Stories: Default, Inline

## sizes

rows и CSS min/max-height принадлежат обычному полю. autoSize растёт и уменьшается по содержимому, после max-height сохраняется внутренний scroll; Input/Button не меняют свои минимумы. Stories: AutoSize, Long

## disabled

Недоступный контрол не выполняет действие и не принимает фокус. Stories: Disabled

## pending

Компонент не запускает запись; pending принадлежит вызывающему механизму или переданному действию.

## loading

Компонент не загружает ресурс; загрузку показывает ResourceStateView или владелец данных.

## empty

Компонент не определяет пустоту предметного каталога; это контракт владельца данных.

## error

aria-invalid показывает ошибочное поле; текст ошибки и aria-describedby задаёт FormField. Stories: Invalid

## long-content

Длинное содержимое остаётся читаемым на узком экране. Stories: Long

## selection

Выбираемого значения нет; компонент не является selector.

## keyboard

Нативные Enter, Tab и выделение текста сохраняются. Измерение не забирает фокус, не меняет selection и не создаёт продуктовых записей. Stories: Default, Usage

## focus

Фокус видим; открытие/закрытие не теряет текущую точку взаимодействия. Stories: Default, Usage

## mobile

Проверить 320/375/1920/2560; внутренний scroll допустим без overflow страницы. Stories: Long, AutoSize
