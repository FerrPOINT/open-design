# Выбор компонента и формы UI 0.2

Select — одно значение из известного списка; MultiSelect — несколько без Ctrl;
SearchableSelect — загружаемый каталог с поиском и пагинацией.
ProjectPicker остаётся навигационным выбором проекта с иконкой.

```tsx
import { Select, MultiSelect } from '@pdlc/ui/ui'
import '@pdlc/ui/tokens.css'
const options = [{value: '', label: 'Все'}, {value: 'review', label: 'На проверке'}]
// In a component: values and persistence are owned by the product.
<Select options={options} value={status} onValueChange={setStatus} />
<MultiSelect options={roles} value={selectedRoles} onValueChange={setSelectedRoles} />
```

Это фрагмент выбора API; самостоятельные компилируемые examples находятся
в карточках Select/MultiSelect/SearchableSelect. Не нужны Router или auth provider;
CSS обязателен. options содержат строки value/label и необязательный disabled.
Ref ведёт на видимый button; label/htmlFor и aria-describedby/invalid передаются ему.

name/form/required обслуживает технический bridge Base. Пустая строка сохраняет
смысл значения; FormData MultiSelect возвращает повторяющийся name. Uncontrolled
reset возвращает defaultValue без записи. Controlled reset обрабатывает владелец
формы. JSX option/onChange/multiple/size заменены options/onValueChange и MultiSelect.

SSR: штатный select_control и initChoice/refreshChoice/destroyChoice из
@pdlc/ui/select-runtime. Пример SsrChoice использует синтетическую форму.
Для выбора значка `initChoice(control, {appearance: 'icons', renderOption})`
показывает компактный trigger и сетку 4 колонки. Renderer возвращает рисунок;
`option.label` остаётся именем для подсказки, доступности и поиска с клавиатуры.
Для выбора именованного ресурса сохраняется обычное текстовое представление.
Данные, разрешения, числовые преобразования и сохранение остаются в продукте.
