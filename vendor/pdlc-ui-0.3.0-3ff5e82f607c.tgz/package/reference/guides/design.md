# Дизайн-основа Base

Генерируется из @pdlc/ui/tokens.css. Значения в селекторах и media rules относятся к указанному контексту; вычисленное значение показывает браузер.

## --base-badge-color

Цвета

- @layer components · .base-badge: var(--color-text-secondary)
- @layer components · .base-badge[data-tone="muted"]: var(--color-text-muted)
- @layer components · .base-badge[data-tone="info"]: var(--color-highlight)
- @layer components · .base-badge[data-tone="success"]: var(--color-success)
- @layer components · .base-badge[data-tone="warning"]: var(--color-warning)
- @layer components · .base-badge[data-tone="danger"]: var(--color-danger)

## --base-button-foreground

Цвета

- .base-button:hover: var(--color-accent-hover-foreground)

## --base-color-control-size

Компоновка

- .base-input.base-control[type="color"]: var(--shell-control-min)
- @media (max-width: 767px) · .base-input.base-control[type="color"]: var(--shell-control-mobile-min)

## --base-control-padding-block

Компоновка

- @theme static: 8px
- :root, [data-theme="dark"]: 8px
- [data-theme="gray"]: 8px
- [data-theme="light"]: 8px

## --base-control-padding-inline

Компоновка

- @theme static: 16px
- :root, [data-theme="dark"]: 16px
- [data-theme="gray"]: 16px
- [data-theme="light"]: 16px

## --base-dialog-close-size

Компоновка

- .base-dialog-content: var(--shell-control-min)
- @media (max-width: 767px) · .base-dialog-content: max(44px, var(--shell-control-min))

## --base-font-body

Типографика

- @theme static: 14px
- :root, [data-theme="dark"]: 14px
- [data-theme="gray"]: 14px
- [data-theme="light"]: 14px

## --base-font-label

Типографика

- @theme static: 12px
- :root, [data-theme="dark"]: 12px
- [data-theme="gray"]: 12px
- [data-theme="light"]: 12px

## --base-font-mono

Типографика

- :root: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono",
    "Courier New", monospace

## --base-font-page-title

Типографика

- @theme static: 24px
- :root, [data-theme="dark"]: 24px
- [data-theme="gray"]: 24px
- [data-theme="light"]: 24px

## --base-font-sans

Типографика

- @theme static: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- :root, [data-theme="dark"]: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- [data-theme="gray"]: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- [data-theme="light"]: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif

## --base-line-body

Типографика

- @theme static: 20px
- :root, [data-theme="dark"]: 20px
- [data-theme="gray"]: 20px
- [data-theme="light"]: 20px

## --base-panel-padding

Компоновка

- @theme static: 20px
- :root, [data-theme="dark"]: 20px
- [data-theme="gray"]: 20px
- [data-theme="light"]: 20px

## --base-radius

Скругления

- @theme static: 6px
- :root, [data-theme="dark"]: 6px
- [data-theme="gray"]: 6px
- [data-theme="light"]: 6px

## --base-radius-card

Скругления

- @theme static: 8px
- :root, [data-theme="dark"]: 8px
- [data-theme="gray"]: 8px
- [data-theme="light"]: 8px

## --base-radius-dialog

Скругления

- @theme static: 8px
- :root, [data-theme="dark"]: 8px
- [data-theme="gray"]: 8px
- [data-theme="light"]: 8px

## --base-radius-menu

Скругления

- @theme static: 6px
- :root, [data-theme="dark"]: 6px
- [data-theme="gray"]: 6px
- [data-theme="light"]: 6px

## --base-row-height

Компоновка

- @theme static: 48px
- :root, [data-theme="dark"]: 48px
- [data-theme="gray"]: 48px
- [data-theme="light"]: 48px

## --base-section-item-justify

Компоновка

- .base-section-navigation: center
- .base-section-navigation[data-orientation="vertical"]: space-between

## --color-accent

Цвета

- @theme static: #5c8af0
- :root, [data-theme="dark"]: #5c8af0
- [data-theme="gray"]: #89abf4
- [data-theme="light"]: #2563eb

## --color-accent-foreground

Цвета

- @theme static: #000000
- :root, [data-theme="dark"]: #000000
- [data-theme="gray"]: #000000
- [data-theme="light"]: #ffffff

## --color-accent-hover

Цвета

- @theme static: #7098f2
- :root, [data-theme="dark"]: #7098f2
- [data-theme="gray"]: #97b5f5
- [data-theme="light"]: #2157cf

## --color-accent-hover-foreground

Цвета

- @theme static: #000000
- :root, [data-theme="dark"]: #000000
- [data-theme="gray"]: #000000
- [data-theme="light"]: #ffffff

## --color-background

Цвета

- @theme static: #09090b
- :root, [data-theme="dark"]: #09090b
- [data-theme="gray"]: #1f1f23
- [data-theme="light"]: #f4f4f5

## --color-border

Цвета

- @theme static: #27272a
- :root, [data-theme="dark"]: #27272a
- [data-theme="gray"]: #3f3f46
- [data-theme="light"]: #e4e4e7

## --color-border-strong

Цвета

- @theme static: #717176
- :root, [data-theme="dark"]: #717176
- [data-theme="gray"]: #89898f
- [data-theme="light"]: #8c8c8f

## --color-danger

Цвета

- @theme static: #f87171
- :root, [data-theme="dark"]: #f87171
- [data-theme="gray"]: #fca5a5
- [data-theme="light"]: #b91c1c

## --color-danger-foreground

Цвета

- @theme inline: var(--color-destructive-foreground)

## --color-danger-strong

Цвета

- @theme inline: var(--color-danger)

## --color-destructive

Цвета

- @theme static: #f87171
- :root, [data-theme="dark"]: #f87171
- [data-theme="gray"]: #fca5a5
- [data-theme="light"]: #b91c1c
- @theme inline: var(--color-danger)

## --color-destructive-foreground

Цвета

- @theme static: #18181b
- :root, [data-theme="dark"]: #18181b
- [data-theme="gray"]: #18181b
- [data-theme="light"]: #ffffff

## --color-focus

Цвета

- @theme static: #5c8af0
- :root, [data-theme="dark"]: #5c8af0
- [data-theme="gray"]: #89abf4
- [data-theme="light"]: #2563eb

## --color-highlight

Цвета

- @theme static: #14b8a6
- :root, [data-theme="dark"]: #14b8a6
- [data-theme="gray"]: #27bead
- [data-theme="light"]: #0e7d71

## --color-muted

Цвета

- @theme static: #27272a
- :root, [data-theme="dark"]: #27272a
- [data-theme="gray"]: #3f3f46
- [data-theme="light"]: #f4f4f5
- @theme inline: var(--color-surface-raised)

## --color-muted-foreground

Цвета

- @theme static: #a1a1aa
- :root, [data-theme="dark"]: #a1a1aa
- [data-theme="gray"]: #b4b4bd
- [data-theme="light"]: #52525b
- @theme inline: var(--color-text-muted)

## --color-popover

Цвета

- @theme static: #18181b
- :root, [data-theme="dark"]: #18181b
- [data-theme="gray"]: #2a2a2f
- [data-theme="light"]: #ffffff

## --color-popover-foreground

Цвета

- @theme static: #fafafa
- :root, [data-theme="dark"]: #fafafa
- [data-theme="gray"]: #f4f4f5
- [data-theme="light"]: #18181b

## --color-primary

Цвета

- @theme static: #5c8af0
- :root, [data-theme="dark"]: #5c8af0
- [data-theme="gray"]: #89abf4
- [data-theme="light"]: #2563eb
- @theme inline: var(--color-accent)

## --color-primary-foreground

Цвета

- @theme static: #000000
- :root, [data-theme="dark"]: #000000
- [data-theme="gray"]: #000000
- [data-theme="light"]: #ffffff
- @theme inline: var(--color-accent-foreground)

## --color-secondary

Цвета

- @theme static: #27272a
- :root, [data-theme="dark"]: #27272a
- [data-theme="gray"]: #3f3f46
- [data-theme="light"]: #f4f4f5
- @theme inline: var(--color-surface-raised)

## --color-secondary-foreground

Цвета

- @theme static: #fafafa
- :root, [data-theme="dark"]: #fafafa
- [data-theme="gray"]: #f4f4f5
- [data-theme="light"]: #18181b
- @theme inline: var(--color-text-primary)

## --color-selection

Цвета

- @theme static: #172e2e
- :root, [data-theme="dark"]: #172e2e
- [data-theme="gray"]: #273e40
- [data-theme="light"]: #def5f3

## --color-selection-foreground

Цвета

- @theme static: #fafafa
- :root, [data-theme="dark"]: #fafafa
- [data-theme="gray"]: #f4f4f5
- [data-theme="light"]: #18181b

## --color-success

Цвета

- @theme static: #4ade80
- :root, [data-theme="dark"]: #4ade80
- [data-theme="gray"]: #86efac
- [data-theme="light"]: #166534

## --color-surface

Цвета

- @theme static: #18181b
- :root, [data-theme="dark"]: #18181b
- [data-theme="gray"]: #2a2a2f
- [data-theme="light"]: #ffffff

## --color-surface-raised

Цвета

- @theme static: #27272a
- :root, [data-theme="dark"]: #27272a
- [data-theme="gray"]: #3f3f46
- [data-theme="light"]: #f4f4f5

## --color-text-muted

Цвета

- @theme static: #a1a1aa
- :root, [data-theme="dark"]: #a1a1aa
- [data-theme="gray"]: #b4b4bd
- [data-theme="light"]: #52525b

## --color-text-primary

Цвета

- @theme static: #fafafa
- :root, [data-theme="dark"]: #fafafa
- [data-theme="gray"]: #f4f4f5
- [data-theme="light"]: #18181b

## --color-text-secondary

Цвета

- @theme static: #d4d4d8
- :root, [data-theme="dark"]: #d4d4d8
- [data-theme="gray"]: #e4e4e7
- [data-theme="light"]: #3f3f46

## --color-warning

Цвета

- @theme static: #fbbf24
- :root, [data-theme="dark"]: #fbbf24
- [data-theme="gray"]: #fde047
- [data-theme="light"]: #92400e

## --error-text

Уведомления

- .base-toaster: var(--color-danger)

## --font-mono

Типографика

- @theme inline: var(--base-font-mono)

## --font-sans

Типографика

- @theme inline: var(--base-font-sans)

## --normal-bg

Уведомления

- .base-toaster: var(--color-surface)

## --normal-border

Уведомления

- .base-toaster: var(--color-border-strong)

## --normal-text

Уведомления

- .base-toaster: var(--color-text-primary)

## --platform-accent

Брендинг

- @theme static: #14b8a6
- :root, [data-theme="dark"]: #14b8a6
- [data-theme="gray"]: #14b8a6
- [data-theme="light"]: #14b8a6

## --platform-primary

Брендинг

- @theme static: #2563eb
- :root, [data-theme="dark"]: #2563eb
- [data-theme="gray"]: #2563eb
- [data-theme="light"]: #2563eb

## --platform-primary-foreground

Брендинг

- @theme static: #ffffff
- :root, [data-theme="dark"]: #ffffff
- [data-theme="gray"]: #ffffff
- [data-theme="light"]: #ffffff

## --platform-surface

Брендинг

- @theme static: #18181b
- :root, [data-theme="dark"]: #18181b
- [data-theme="gray"]: #2a2a2f
- [data-theme="light"]: #ffffff

## --radius-lg

Скругления

- @theme static: 8px
- :root, [data-theme="dark"]: 8px
- [data-theme="gray"]: 8px
- [data-theme="light"]: 8px

## --radius-md

Скругления

- @theme static: 6px
- :root, [data-theme="dark"]: 6px
- [data-theme="gray"]: 6px
- [data-theme="light"]: 6px

## --radius-sm

Скругления

- @theme static: 4px
- :root, [data-theme="dark"]: 4px
- [data-theme="gray"]: 4px
- [data-theme="light"]: 4px

## --radius-xl

Скругления

- @theme static: 10px
- :root, [data-theme="dark"]: 10px
- [data-theme="gray"]: 10px
- [data-theme="light"]: 10px

## --resource-row-min-height

Списки

- .base-resource-list: var(--base-row-height)
- .base-resource-list[data-density="comfortable"]: 56px

## --resource-row-padding-block

Списки

- .base-resource-list: var(--base-control-padding-block)
- .base-resource-list[data-density="comfortable"]: 16px

## --resource-row-padding-inline

Списки

- .base-resource-list: var(--base-control-padding-inline)

## --shell-aside-width

Компоновка

- :root: 320px

## --shell-control-min

Компоновка

- @theme static: 40px
- :root, [data-theme="dark"]: 40px
- [data-theme="gray"]: 40px
- [data-theme="light"]: 40px

## --shell-control-mobile-min

Компоновка

- @theme static: 44px
- :root, [data-theme="dark"]: 44px
- [data-theme="gray"]: 44px
- [data-theme="light"]: 44px

## --shell-header-height

Компоновка

- :root: 60px
- @media (max-width: 767px) · :root:has(.platform-header-context [data-namespace-picker]): 104px

## --shell-page-block-gap

Компоновка

- :root: 20px

## --shell-page-gutter

Компоновка

- :root: clamp(16px, 2vw, 32px)

## --shell-platform-mark-size

Компоновка

- :root: 40px

## --shell-readable-width

Компоновка

- :root: 760px

## --shell-sidebar-compact

Компоновка

- :root: 72px

## --shell-sidebar-expanded

Компоновка

- :root: 264px

## --success-text

Уведомления

- .base-toaster: var(--color-success)

## --text-2xl

Типографика

- @theme inline: var(--base-font-page-title)

## --text-2xl--line-height

Типографика

- @theme inline: calc(var(--base-line-body) + 12px)

## --text-base

Типографика

- @theme inline: calc(var(--base-font-body) + 2px)

## --text-base--line-height

Типографика

- @theme inline: calc(var(--base-line-body) + 4px)

## --text-lg

Типографика

- @theme inline: calc(var(--base-font-body) + 4px)

## --text-lg--line-height

Типографика

- @theme inline: calc(var(--base-line-body) + 4px)

## --text-sm

Типографика

- @theme inline: var(--base-font-body)

## --text-sm--line-height

Типографика

- @theme inline: var(--base-line-body)

## --text-xl

Типографика

- @theme inline: calc(var(--base-font-body) + 6px)

## --text-xl--line-height

Типографика

- @theme inline: calc(var(--base-line-body) + 8px)

## --text-xs

Типографика

- @theme inline: var(--base-font-label)

## --text-xs--line-height

Типографика

- @theme inline: calc(var(--base-line-body) - 4px)

## --warning-text

Уведомления

- .base-toaster: var(--color-warning)

## Адаптивные условия

- (forced-colors: active)
- (max-width: 1023px)
- (max-width: 640px)
- (max-width: 767px)
- (min-width: 1280px)
- (min-width: 640px)
- (min-width: 768px)
- (min-width: 768px) and (max-width: 1279px)
- (prefers-reduced-motion: reduce)
