# Metric: состояния

## variants

Карточка и строка с общими semantic tones: default/info/success/warning/danger; цвет значения задаёт Base. React и SSR используют один CSS. Stories: Default, Inline, Icon, Tones

## sizes

Отдельного size API нет; геометрия задаётся общими Card и typography tokens.

## disabled

Показатель не является control. Доступ к данным задаётся явным ResourceState.

## pending

Компонент не выполняет запись; загрузка данных отражается через state.

## loading

До подтверждения чтения прежнее значение не показывается. Stories: Loading

## empty

Null не становится нулём; пояснение отсутствующего значения задаёт продукт. Stories: Empty

## error

Ошибка и потеря доступа скрывают значение; частичная ошибка сохраняет подтверждённое значение. Stories: Error, Partial, Denied

## long-content

Длинные подписи и значения переносятся внутри карточки. Stories: LongContent

## selection

Показатель не выбирает данные и не меняет фильтры.

## keyboard

Повтор чтения — обычная кнопка Base с клавиатурной активацией. Stories: Error

## focus

Завершение чтения не перехватывает focus; ошибка не заменяет соседние показатели. Stories: Error

## mobile

Проверить 320/375/1920/2560; число колонок задаёт продуктовая сетка. Stories: LongContent
