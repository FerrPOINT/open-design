# BrandingEditor: состояния

## variants

Отдельного перечисления вариантов нет; BrandingPreview является частью общей композиции.

## sizes

Размер определяется контейнером; отдельного size-контракта нет.

## disabled

Все поля недоступны, callbacks не вызываются. Stories: Disabled, Readonly

## pending

Сохранение выполняет приложение; на время записи оно передаёт disabled.

## loading

Компонент не загружает документ; состояние загрузки принадлежит вызывающему приложению.

## empty

Форма всегда получает полный документ; пустые имена и nullable поля можно редактировать.

## error

API и серверная валидация принадлежат Admin; незавершённый HEX показан в IncompleteColor.

## long-content

Длинные имена остаются видимыми без горизонтального overflow. Stories: LongContent

## selection

Выбора ресурса нет; управляемый ввод цветов показан в Usage.

## keyboard

Tab проходит поля; HEX редактируется без native picker. Stories: Usage

## focus

Фокус Input и пары HEX/color видим во всех темах. Stories: Usage

## mobile

Параметры и preview переходят в одну колонку на 320/375 px. Stories: LongContent
