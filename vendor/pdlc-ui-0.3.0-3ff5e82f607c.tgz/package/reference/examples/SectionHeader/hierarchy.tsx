import { useId } from "react";
import { SectionHeader } from "@pdlc/ui/ui";

export default function Example() {
  const id = useId();
  return (
    <div className="base-page-stack">
      {([2, 3, 4, 5, 6] as const).map((level) => (
        <section key={level} aria-labelledby={`${id}-${level}`}>
          <SectionHeader
            level={level}
            headingId={`${id}-${level}`}
            title={`Раздел уровня h${level}`}
            context="Уровень выбирает владелец страницы; оформление задаёт Base."
          />
          <p>Содержание вложенного раздела.</p>
        </section>
      ))}
    </div>
  );
}
