import {
  Card,
  CardHeader,
  CardTitle,
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
  Button,
} from "@pdlc/ui/ui";
import { useId, useState } from "react";

function RolesTable({ name }: { name: string }) {
  const [expanded, setExpanded] = useState(false);
  const detailsId = useId();
  return (
    <Table aria-label={name}>
      <TableHeader>
        <TableRow>
          <TableHead>Claim</TableHead>
          <TableHead>Значение</TableHead>
          <TableHead>Роль</TableHead>
          <TableHead>Создан</TableHead>
          <TableHead>Действия</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableRow>
          <TableCell>email</TableCell>
          <TableCell
            className="max-w-[22rem] truncate"
            title="long-synthetic-subject-for-layout-check@example.test"
          >
            long-synthetic-subject-for-layout-check@example.test
          </TableCell>
          <TableCell>platform_viewer</TableCell>
          <TableCell>22.10.2026</TableCell>
          <TableCell>
            <Button
              variant="outline"
              aria-expanded={expanded}
              aria-controls={detailsId}
              onClick={() => setExpanded((value) => !value)}
            >
              Подробности
            </Button>
          </TableCell>
        </TableRow>
        {expanded && (
          <TableRow>
            <TableCell colSpan={5} id={detailsId}>
              Синтетическая запись: действие изменяет только этот пример.
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
}

/** Framing must not change the native minimum width of words in table columns. */
export default function InCardExample() {
  return (
    <div className="grid min-w-0 gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Таблица внутри карточки</CardTitle>
        </CardHeader>
        <RolesTable name="Роли в карточке" />
      </Card>
      <RolesTable name="Роли без карточки" />
    </div>
  );
}
