import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    children: "Обзор",
    active: true,
    onClick: () => {},
  } satisfies ComponentProps<typeof UI.SidebarItem>;
  const render = (args: ComponentProps<typeof UI.SidebarItem>) => (
    <UI.SidebarItem {...args} />
  );
  return render(args);
}
