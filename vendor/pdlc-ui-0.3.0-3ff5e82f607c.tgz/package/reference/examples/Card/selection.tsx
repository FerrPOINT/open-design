import { useState } from "react";
import { Card } from "@pdlc/ui/ui";

export default function Example() {
  const [selected, setSelected] = useState("first");
  return (
    <div className="base-page-stack" role="group" aria-label="Выбор ресурса">
      {[
        { id: "first", label: "Первый ресурс" },
        { id: "second", label: "Второй ресурс" },
      ].map((resource) => (
        <Card
          key={resource.id}
          asChild
          interactive
          className="base-card-content"
        >
          <button
            type="button"
            aria-pressed={selected === resource.id}
            onClick={() => setSelected(resource.id)}
          >
            {resource.label}
          </button>
        </Card>
      ))}
    </div>
  );
}
