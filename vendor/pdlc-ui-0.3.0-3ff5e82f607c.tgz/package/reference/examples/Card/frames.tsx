import { useState } from "react";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  RadioGroup,
  Checkbox,
  Button,
} from "@pdlc/ui/ui";

export default function Example() {
  const [compact, setCompact] = useState(false);
  const [highlighted, setHighlighted] = useState(false);
  const [events, setEvents] = useState(0);
  const density = compact ? "compact" : "default";
  return (
    <div className="space-y-4">
      <RadioGroup
        appearance="segmented"
        label="Плотность карточки"
        value={density}
        options={[
          { value: "default", label: "Обычная" },
          { value: "compact", label: "Компактная" },
        ]}
        onValueChange={(value) => setCompact(value === "compact")}
      />
      <Checkbox
        checked={highlighted}
        onCheckedChange={(value) => setHighlighted(value === true)}
      >
        Подсветить рамку
      </Checkbox>
      <Card highlighted={highlighted}>
        <CardHeader density={density}>
          <CardTitle>Общая поверхность</CardTitle>
        </CardHeader>
        <CardContent density={density}>
          <Card asChild surface="raised">
            <article
              draggable
              onDragStart={(event) => {
                event.dataTransfer.setData("text/plain", "synthetic-item");
                setEvents((count) => count + 1);
              }}
            >
              <CardContent density={density}>
                <p>
                  Приподнятая карточка с длинным названием и отдельным
                  действием.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setEvents((count) => count + 1)}
                >
                  Действие
                </Button>
              </CardContent>
            </article>
          </Card>
        </CardContent>
      </Card>
      <p role="status">Событий в синтетическом примере: {events}</p>
    </div>
  );
}
