import * as UI from "@pdlc/ui/ui";
import type { ComponentProps } from "react";

export default function Example({
  interactive = true,
}: Pick<ComponentProps<typeof UI.Card>, "interactive"> = {}) {
  return (
    <div className="space-y-4">
      <UI.Card asChild interactive={interactive}>
        <a href="#project-card-details">
          <UI.CardHeader>
            <UI.CardTitle asChild>
              <h2>Проект платформы</h2>
            </UI.CardTitle>
          </UI.CardHeader>
          <UI.CardContent>
            Вся карточка — одна ссылка. Доступны обычные Tab и Enter; вложенные
            кнопки и ссылки в такую карточку не добавляются.
          </UI.CardContent>
        </a>
      </UI.Card>
      <p id="project-card-details">
        Локальное описание проекта. Запросов к продуктам нет.
      </p>
    </div>
  );
}
