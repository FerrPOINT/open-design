import { useId, useState } from "react";
import { Button, Card, Checkbox, Radio } from "@pdlc/ui/ui";

export default function Example() {
  const id = useId();
  const [mode, setMode] = useState("standard");
  const [result, setResult] = useState("");
  return (
    <form
      className="base-page-stack"
      onSubmit={(event) => {
        event.preventDefault();
        setResult(
          JSON.stringify(Array.from(new FormData(event.currentTarget))),
        );
      }}
    >
      <fieldset className="grid min-w-0 gap-3">
        <legend>Режим работы</legend>
        {["standard", "extended"].map((value) => (
          <Card key={value} asChild interactive className="base-card-content">
            <label className="flex min-w-0 items-start gap-3">
              <Radio
                name="mode"
                value={value}
                checked={mode === value}
                onCheckedChange={() => setMode(value)}
              />
              <span className="grid min-w-0 gap-2">
                <strong>
                  {value === "standard" ? "Стандартный" : "Расширенный"}
                </strong>
                <span>Нажатие на описание тоже выбирает этот вариант.</span>
              </span>
            </label>
          </Card>
        ))}
      </fieldset>
      <Card asChild interactive className="base-card-content">
        <label className="flex min-w-0 items-start gap-3">
          <Checkbox id={id} name="feature" value="history" defaultChecked />
          <span>Сохранять историю</span>
        </label>
      </Card>
      <fieldset disabled>
        <legend>Недоступный выбор</legend>
        <Card asChild interactive className="base-card-content">
          <label className="flex min-w-0 items-start gap-3">
            <Checkbox name="unavailable" value="restricted" />
            <span>Недоступная возможность</span>
          </label>
        </Card>
      </fieldset>
      <Button type="submit">Прочитать форму</Button>
      <output aria-label="Данные формы">{result}</output>
    </form>
  );
}
