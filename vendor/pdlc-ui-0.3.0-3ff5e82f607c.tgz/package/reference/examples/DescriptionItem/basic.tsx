import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    label: "Идентификатор",
    children: "demo-namespace-42",
    technical: true,
  } satisfies ComponentProps<typeof UI.DescriptionItem>;
  const render = (args: ComponentProps<typeof UI.DescriptionItem>) => (
    <dl>
      <UI.DescriptionItem {...args} />
    </dl>
  );
  return render(args);
}
