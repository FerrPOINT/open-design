import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    children:
      "pnpm --dir components-dictionary dev\n# Локальная разработка компонентов",
    "aria-label": "Команды запуска",
  } satisfies ComponentProps<typeof UI.CodeBlock>;
  const render = (args: ComponentProps<typeof UI.CodeBlock>) => (
    <UI.CodeBlock {...args} />
  );
  return render(args);
}
