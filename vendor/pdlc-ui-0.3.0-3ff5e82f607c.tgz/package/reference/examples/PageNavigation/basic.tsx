import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useState } from "react";

function useExampleValue<T>(value: T) {
  const [current, setCurrent] = useState(value);
  useEffect(() => setCurrent(value), [value]);
  return [current, setCurrent] as const;
}

export function ControlledPageNavigation(
  args: ComponentProps<typeof UI.PageNavigation>,
) {
  const [page, setPage] = useExampleValue(args.page);
  return (
    <UI.PageNavigation
      {...args}
      page={page}
      onPageChange={(value) => {
        setPage(value);
        args.onPageChange(value);
      }}
    />
  );
}

export default function Example() {
  const args = {
    page: 1,
    pageCount: 5,
    label: "Страница",
    onPageChange: () => {},
  } satisfies ComponentProps<typeof UI.PageNavigation>;
  const render = (args: ComponentProps<typeof UI.PageNavigation>) => (
    <ControlledPageNavigation {...args} />
  );
  return render(args);
}
