import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    htmlFor: "label-input",
    children: "Название",
  } satisfies ComponentProps<typeof UI.Label>;
  const render = (args: ComponentProps<typeof UI.Label>) => (
    <div className="space-y-4">
      <UI.Label {...args} />
      <UI.Input id={args.htmlFor} placeholder="Введите название" />
    </div>
  );
  return render(args);
}
