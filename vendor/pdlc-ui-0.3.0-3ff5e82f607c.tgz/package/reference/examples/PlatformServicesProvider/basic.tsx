import * as UI from "@pdlc/ui/ui";
import { PlatformServicesProvider, ServiceSwitcher } from "@pdlc/ui/ui";
import { useMemo } from "react";

function CatalogConsumer() {
  const catalog = UI.usePlatformServices();
  // Keep compiled-in platform links out of the example until its catalog is confirmed.
  if (catalog.source !== "runtime")
    return <UI.LoadingState message="Готовим локальный каталог…" />;
  return (
    <div className="space-y-4">
      <ServiceSwitcher currentKey="wiki" showCurrentLabel />
      <UI.JsonBlock aria-label="Локальный каталог сервисов" value={catalog} />
    </div>
  );
}

export default function Example() {
  const catalogUrl = useMemo(() => {
    // Runtime catalog URLs must be absolute HTTP(S); keep the synthetic target local.
    const url = new URL(
      "/?path=/story/base-platform-services-provider--usage",
      window.location.origin,
    ).href;
    const services = [
      {
        key: "wiki",
        label: "Wiki",
        url,
        ui_url: url,
        health: "unknown",
        capabilities: [],
        contract_version: "1.0.0",
      },
    ];
    return (
      "data:application/json," +
      encodeURIComponent(JSON.stringify({ services }))
    );
  }, []);
  return (
    <PlatformServicesProvider catalogUrl={catalogUrl}>
      <CatalogConsumer />
    </PlatformServicesProvider>
  );
}

export function ServiceCatalogDemo() {
  const catalog = UI.usePlatformServices();
  return (
    <div className="space-y-4">
      <UI.ServiceSwitcher currentKey="wiki" showCurrentLabel />
      <UI.JsonBlock aria-label="Локальный каталог сервисов" value={catalog} />
      <p>Все ссылки ведут в этот Storybook.</p>
    </div>
  );
}
