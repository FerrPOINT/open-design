import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogTitle,
  Button,
} from "@pdlc/ui/ui";

export default function ControlledAlertExample() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setOpen(true)}>
        Открыть управляемое подтверждение
      </Button>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent>
          <AlertDialogTitle>Подтверждение примера</AlertDialogTitle>
          <AlertDialogDescription>
            Данные не записываются. Отмена возвращает фокус без
            AlertDialogTrigger.
          </AlertDialogDescription>
          <AlertDialogCancel>Отмена</AlertDialogCancel>
          <AlertDialogAction>Подтвердить пример</AlertDialogAction>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
