import * as UI from "@pdlc/ui/ui";
export default function Example() {
  const render = () => (
    <UI.AlertDialog>
      <UI.AlertDialogTrigger asChild>
        <UI.Button variant="destructive">Подтвердить действие</UI.Button>
      </UI.AlertDialogTrigger>
      <UI.AlertDialogContent>
        <UI.AlertDialogHeader>
          <UI.AlertDialogTitle>Продолжить?</UI.AlertDialogTitle>
          <UI.AlertDialogDescription>
            Это демонстрация. Данные не изменяются.
          </UI.AlertDialogDescription>
        </UI.AlertDialogHeader>
        <UI.AlertDialogFooter>
          <UI.AlertDialogCancel>Отмена</UI.AlertDialogCancel>
          <UI.AlertDialogAction>Продолжить</UI.AlertDialogAction>
        </UI.AlertDialogFooter>
      </UI.AlertDialogContent>
    </UI.AlertDialog>
  );
  return render();
}
