import * as UI from "@pdlc/ui/ui";
export default function Example() {
  const render = () => (
    <UI.DropdownMenu>
      <UI.DropdownMenuTrigger asChild>
        <UI.Button variant="outline">Выбрать тему</UI.Button>
      </UI.DropdownMenuTrigger>
      <UI.DropdownMenuContent>
        <UI.ThemeMenuItems />
      </UI.DropdownMenuContent>
    </UI.DropdownMenu>
  );
  return render();
}
