import { BrandingWorkspaceLayout } from "@pdlc/ui/branding";
import { Button, Input } from "@pdlc/ui/ui";
export default function Example() {
  return (
    <BrandingWorkspaceLayout
      navigation="Редактор оформления"
      status="Пример: сохранение не подключено"
      actions={
        <Button form="brand-layout-example" type="submit">
          Сохранить
        </Button>
      }
    >
      <form
        id="brand-layout-example"
        onSubmit={(event) => event.preventDefault()}
      >
        <Input aria-label="Название продукта" defaultValue="PDLC" />
      </form>
    </BrandingWorkspaceLayout>
  );
}
