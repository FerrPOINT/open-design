import { useState } from "react";
import {
  ApplicationAccessProvider,
  ApplicationAccessDenied,
  RequireApplicationAccess,
  RequireAdministrator,
} from "@pdlc/ui/auth";

export type ExampleMode = "application" | "administrator" | "denied";

/** No bearer, owner requests or real SSO: unconfirmed access stays closed. */
export default function Example({
  mode = "application",
}: {
  mode?: ExampleMode;
}) {
  const [attempts, setAttempts] = useState(0);
  return (
    <ApplicationAccessProvider
      issuer="https://auth.fixture.invalid"
      token={null}
    >
      {mode === "application" && (
        <RequireApplicationAccess application="task-tracker">
          <p>Содержимое разрешённого приложения</p>
        </RequireApplicationAccess>
      )}
      {mode === "administrator" && (
        <RequireAdministrator>
          <p>Действия администратора</p>
        </RequireAdministrator>
      )}
      {mode === "denied" && (
        <>
          <ApplicationAccessDenied
            onRetry={() => setAttempts((value) => value + 1)}
          />
          <p role="status">
            Локальных попыток: {attempts}. Права не изменяются.
          </p>
        </>
      )}
    </ApplicationAccessProvider>
  );
}
