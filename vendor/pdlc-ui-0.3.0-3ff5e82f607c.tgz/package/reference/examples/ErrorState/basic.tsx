import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    message: "Не удалось загрузить проекты",
    onRetry: () => {},
  } satisfies ComponentProps<typeof UI.ErrorState>;
  const render = (args: ComponentProps<typeof UI.ErrorState>) => (
    <UI.ErrorState {...args} />
  );
  return render(args);
}
