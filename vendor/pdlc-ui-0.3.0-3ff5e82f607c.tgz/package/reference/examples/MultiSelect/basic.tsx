import { MultiSelect } from "@pdlc/ui/ui";
import { useState, type FormEvent } from "react";
import { Button } from "@pdlc/ui/ui";

export default function MultipleExample() {
  const [submitted, setSubmitted] = useState<string[]>([]);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitted(new FormData(event.currentTarget).getAll("roles").map(String));
  }
  return (
    <form onSubmit={submit} className="space-y-3">
      <label htmlFor="select-roles">Участники проверки</label>
      <MultiSelect
        id="select-roles"
        name="roles"
        defaultValue={["reviewer", "tester"]}
        options={[
          ...[{ value: String("analyst"), label: String("Аналитик") }],
          ...[{ value: String("developer"), label: String("Разработчик") }],
          ...[{ value: String("reviewer"), label: String("Ревьюер") }],
          ...[{ value: String("tester"), label: String("Тестировщик") }],
        ]}
      />
      <Button type="submit">Показать выбор</Button>
      <Button type="reset" variant="outline">
        Сбросить форму
      </Button>
      <output
        className="block min-h-6 text-sm text-text-secondary"
        aria-label="Отправленные значения"
      >
        {submitted.join(", ")}
      </output>
    </form>
  );
}
