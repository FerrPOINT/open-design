import { PlatformHost } from "@pdlc/ui/platform/host";

/** The caller supplies a synthetic Window (for example a jsdom test window).
 * Construction observes that window's history; start/navigate are deliberately not called.
 * No product iframe or network request is created. */
export function syntheticHostLifecycle(target: Window) {
  const root = target.document.createElement("main");
  const host = new PlatformHost({
    root,
    window: target,
    config: {
      authOrigin: "https://identity.example.invalid",
      services: [
        {
          key: "example",
          label: "Пример",
          origin: "https://product.example.invalid",
          path: "/example/",
        },
      ],
    },
  });
  try {
    return host.resolve("https://product.example.invalid/issues?state=open");
  } finally {
    host.dispose();
  }
}
