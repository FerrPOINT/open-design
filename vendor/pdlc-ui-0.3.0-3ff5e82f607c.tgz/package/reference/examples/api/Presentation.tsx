import { cn, sdlcPresentationRoleLabel } from "@pdlc/ui/lib";
import {
  buttonVariants,
  resourceErrorState,
  ResourceStateView,
} from "@pdlc/ui/ui";

export function presentation(role: string | null) {
  return {
    label: sdlcPresentationRoleLabel(role),
    className: cn(
      buttonVariants({ variant: "outline", size: "sm" }),
      "example-action",
    ),
  };
}
export default function Example() {
  const state = resourceErrorState(new Error("Синтетическая ошибка чтения"));
  return <ResourceStateView state={state} />;
}
