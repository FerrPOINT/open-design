import { useState } from "react";
import { useDebouncedValue } from "@pdlc/ui/lib";
import { Input } from "@pdlc/ui/ui";
export default function Example() {
  const [query, setQuery] = useState("");
  const confirmed = useDebouncedValue(query, 250);
  return (
    <section>
      <Input
        aria-label="Поиск"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
      />
      <p aria-live="polite">Отложенное значение: {confirmed}</p>
    </section>
  );
}
