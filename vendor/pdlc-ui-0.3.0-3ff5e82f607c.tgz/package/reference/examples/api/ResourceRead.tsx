import { useCallback } from "react";
import { useResourceRead } from "@pdlc/ui/lib";
import { ResourceStateView } from "@pdlc/ui/ui";

export default function ResourceReadExample({
  identity = "preview",
}: {
  identity?: string;
}) {
  const read = useCallback(async () => ["Подтверждённый пример"], []);
  const resource = useResourceRead(read, identity);
  return (
    <>
      <ResourceStateView state={resource.state} />
      <ul>
        {resource.data?.map((name) => (
          <li key={name}>{name}</li>
        ))}
      </ul>
    </>
  );
}
