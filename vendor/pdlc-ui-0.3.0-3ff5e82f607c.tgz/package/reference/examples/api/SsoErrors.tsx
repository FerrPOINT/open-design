import {
  SsoLogoutPendingError,
  SsoLoginRequiredError,
  isSsoNavigationInterruption,
  isSsoLoginRequired,
} from "@pdlc/ui/sso";

/** No token, redirect or real SSO transaction is created. */
export function classifySyntheticSsoErrors() {
  const logout = new SsoLogoutPendingError();
  const login = new SsoLoginRequiredError();
  return {
    interrupted: isSsoNavigationInterruption(logout),
    requiresLogin: isSsoLoginRequired(login),
  };
}
