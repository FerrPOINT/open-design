import {
  connectEventStream,
  connectAuthenticatedEventStream,
} from "@pdlc/ui/lib";

/** Call inside an effect and return the disposer. Use only a synthetic EventSource/fetch
 * adapter in a catalogue test. Production supplies the URL and current token separately. */
export function publicEvents(
  url: string,
  onEvent: (type: string, value: unknown) => void,
) {
  return connectEventStream({ url, eventTypes: ["updated"], onEvent });
}
export function privateEvents(
  url: string,
  token: string,
  onEvent: (type: string, value: unknown) => void,
) {
  return connectAuthenticatedEventStream({
    url,
    token,
    eventTypes: ["updated"],
    onEvent,
    lastEventId: "synthetic-cursor",
  });
}
