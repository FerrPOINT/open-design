import { createApiClient, ApiError, InvalidResponseError } from "@pdlc/ui/lib";

/** Constructing a client does not perform requests or persist a token. */
export default function apiClientExample(getAccessToken: () => string | null) {
  return createApiClient({ baseUrl: "", getAccessToken });
}

/** Synthetic failure objects document classification without issuing a request. */
export function syntheticApiErrors() {
  const unavailable = new ApiError(503, "Синтетическая недоступность");
  const invalid = new InvalidResponseError(200, "example-request");
  return {
    temporary: unavailable.status === 503,
    invalidResponse: invalid instanceof ApiError,
  };
}
