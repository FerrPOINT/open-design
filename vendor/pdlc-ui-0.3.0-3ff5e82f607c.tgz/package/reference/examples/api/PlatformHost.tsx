import { validatePlatformConfig } from "@pdlc/ui/platform/host";

/** Synthetic configuration validation only: no host, frames or network are started.
 * Production's authoritative catalogue owns all addresses. Validation normalises its input. */
export function hostConfigurationExample() {
  return validatePlatformConfig({
    authOrigin: "https://identity.example.invalid",
    services: [
      {
        key: "example",
        label: "Пример",
        origin: "https://product.example.invalid",
        path: "/example/",
      },
    ],
  });
}
