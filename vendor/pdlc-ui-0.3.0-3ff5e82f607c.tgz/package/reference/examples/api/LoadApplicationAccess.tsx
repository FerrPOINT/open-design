import { useState } from "react";
import { ApplicationAccessError, loadApplicationAccess } from "@pdlc/ui/auth";
import { Button } from "@pdlc/ui/ui";

/** The owning application supplies the configured issuer and its current bearer. */
export async function readCurrentAccess(input: {
  issuer: string;
  token: string;
  subject: string;
  tokenExpiresAt: number;
  signal: AbortSignal;
}) {
  return loadApplicationAccess(
    input.issuer,
    input.token,
    input.subject,
    input.tokenExpiresAt,
    input.signal,
  );
}

/** Deliberately invalid configuration is rejected before fetch; no credentials. */
export default function Example() {
  const [message, setMessage] = useState("Сеть не используется.");
  const check = async () => {
    try {
      await loadApplicationAccess("not-an-issuer", "", "synthetic-person", 0);
    } catch (error) {
      setMessage(
        error instanceof ApplicationAccessError
          ? `Конфигурация отклонена (${error.status}): ${error.message}`
          : "Неожиданная ошибка примера.",
      );
    }
  };
  return (
    <>
      <Button type="button" onClick={() => void check()}>
        Проверить неверную конфигурацию
      </Button>
      <p role="status">{message}</p>
    </>
  );
}
