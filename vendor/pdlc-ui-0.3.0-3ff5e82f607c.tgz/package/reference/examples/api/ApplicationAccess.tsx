import {
  ApplicationAccessError,
  applicationAccessBoundary,
  browserTokenIdentity,
  confirmApplicationAccess,
  permitsApplication,
  type AccessClock,
  type ApplicationAccessV1,
} from "@pdlc/ui/auth";

/** Fixed synthetic clocks illustrate the contract; they are not authorization. */
export function syntheticAccess() {
  const wall = Date.parse("2026-10-23T00:00:00Z");
  const clock: AccessClock = {
    issuer: "https://auth.fixture.invalid",
    subject: "synthetic-person",
    startedAt: 100,
    receivedAt: 120,
    wallAtReceipt: wall,
    tokenExpiresAt: wall + 60000,
  };
  const raw: ApplicationAccessV1 = {
    schema_version: 1,
    issuer: clock.issuer,
    subject: clock.subject,
    role: "user",
    applications: ["task-tracker"],
    revision: 1,
    enforced: true,
    observed_at: new Date(wall).toISOString(),
    expires_at: new Date(wall + 30000).toISOString(),
  };
  const access = confirmApplicationAccess(raw, clock);
  const error = new ApplicationAccessError(403, "Синтетический отказ");
  return {
    permitted: permitsApplication(access, ["task-tracker"], false, 120),
    unrelated: permitsApplication(access, ["wiki"], false, 120),
    expired: permitsApplication(
      access,
      ["task-tracker"],
      false,
      access.deadline,
    ),
    boundary: applicationAccessBoundary(access),
    invalidToken: browserTokenIdentity("not-a-bearer"),
    errorStatus: error.status,
  };
}

export default function Example() {
  return <p>Синтетическая проверка: {JSON.stringify(syntheticAccess())}</p>;
}
