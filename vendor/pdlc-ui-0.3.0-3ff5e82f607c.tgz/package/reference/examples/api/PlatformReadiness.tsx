import {
  createProductRouter,
  PlatformRoute,
  setPlatformQueryClient,
  usePlatformReadiness,
  usePlatformLeaveGuard,
} from "@pdlc/ui/platform";
import { RouterProvider } from "react-router";
import { Button } from "@pdlc/ui/ui";

function Content() {
  usePlatformReadiness({ pending: false, error: null });
  const leave = usePlatformLeaveGuard(false);
  return (
    <PlatformRoute>
      <p>Начальные данные готовы</p>
      {leave.blocked && (
        <>
          <Button onClick={leave.confirm}>Покинуть</Button>
          <Button onClick={leave.cancel}>Остаться</Button>
        </>
      )}
    </PlatformRoute>
  );
}
/** The product supplies its existing query client; this fixture never fetches real data. */
export function createExampleRouter(
  queryClient: Parameters<typeof setPlatformQueryClient>[0],
) {
  setPlatformQueryClient(queryClient);
  return createProductRouter([{ path: "*", element: <Content /> }], {
    serviceKey: "dictionary-example",
  });
}
export default function Example({
  router,
}: {
  router: ReturnType<typeof createExampleRouter>;
}) {
  return <RouterProvider router={router} />;
}
