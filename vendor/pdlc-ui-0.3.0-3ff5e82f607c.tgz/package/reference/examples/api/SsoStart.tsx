import {
  authorizationUrl,
  beginSso,
  isSsoNavigationInterruption,
  ssoNamespace,
  type SsoConfig,
} from "@pdlc/ui/sso";

/** Reference-only actions: tests mock the public SSO transport; importing does not navigate.
 * authorizationUrl prepares PKCE storage. Do not call it before beginSso for the same attempt. */
export function ssoActions(config: SsoConfig) {
  return {
    namespace: ssoNamespace(config.namespace),
    prepareForExternalNavigation: () => authorizationUrl(config, "/issues"),
    async signIn() {
      try {
        await beginSso(config, "/issues", { interactive: true });
      } catch (error) {
        if (!isSsoNavigationInterruption(error)) throw error;
      }
    },
  };
}
