import { ApplicationAccessProvider, useApplicationAccess } from "@pdlc/ui/auth";

function CurrentAccess() {
  const access = useApplicationAccess();
  return (
    <p role="status">
      Состояние: {access?.status ?? "provider отсутствует"}. Доступ к
      приложению:
      {access?.permits(["task-tracker"]) ? " разрешён" : " не подтверждён"}.
    </p>
  );
}

/** A signed-out fixture does not contact the owner or grant access. */
export default function Example() {
  return (
    <ApplicationAccessProvider
      issuer="https://auth.fixture.invalid"
      token={null}
    >
      <CurrentAccess />
    </ApplicationAccessProvider>
  );
}
