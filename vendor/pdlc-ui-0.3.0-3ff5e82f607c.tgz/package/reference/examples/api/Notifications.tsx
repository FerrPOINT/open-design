import { useId } from "react";
import { Button, Toaster, toast } from "@pdlc/ui/ui";
export default function Example() {
  const id = useId();
  return (
    <>
      <Button onClick={() => toast("Локальное уведомление", { toasterId: id })}>
        Показать
      </Button>
      <Toaster id={id} />
    </>
  );
}
