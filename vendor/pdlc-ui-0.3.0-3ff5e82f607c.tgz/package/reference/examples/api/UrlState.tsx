import {
  textQuery,
  enumQuery,
  positiveIntegerQuery,
  updateQuery,
} from "@pdlc/ui/lib";

export default function urlStateExample(search: string) {
  const params = new URLSearchParams(search);
  const filter = enumQuery(["all", "open"] as const, "all");
  const page = positiveIntegerQuery();
  return {
    query: textQuery().parse(params.get("q")),
    filter: filter.parse(params.get("filter")),
    page: page.parse(params.get("page")),
    next: updateQuery(
      params,
      { filter: filter.format("open") },
      true,
    ).toString(),
  };
}
