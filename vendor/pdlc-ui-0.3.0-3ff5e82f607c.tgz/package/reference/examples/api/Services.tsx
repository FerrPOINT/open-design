import {
  PlatformServicesProvider,
  usePlatformServices,
  getSwitcherServices,
} from "@pdlc/ui/ui";
const catalog =
  "data:application/json," +
  encodeURIComponent(
    JSON.stringify({
      services: [
        {
          key: "demo",
          label: "Демонстрация",
          url: "https://example.test",
          ui_url: "https://example.test",
          health: "unknown",
          capabilities: [],
          contract_version: "1.0.0",
        },
      ],
    }),
  );
function Directory() {
  const { services, source } = usePlatformServices();
  return (
    <section>
      <p>Источник: {source}</p>
      <ul>
        {getSwitcherServices(services).map((item) => (
          <li key={item.key}>{item.label}</li>
        ))}
      </ul>
    </section>
  );
}
export default function Example() {
  return (
    <PlatformServicesProvider catalogUrl={catalog}>
      <Directory />
    </PlatformServicesProvider>
  );
}
