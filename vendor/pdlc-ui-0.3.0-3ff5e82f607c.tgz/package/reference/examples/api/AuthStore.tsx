import { createAuthStore } from "@pdlc/ui/auth";

/** Call once at the product boundary, not during a component render.
 * The synthetic key cannot overwrite another application's stored profile. */
export function createExampleAuth() {
  return createAuthStore({ storageKey: "dictionary:example:auth-profile" });
}
