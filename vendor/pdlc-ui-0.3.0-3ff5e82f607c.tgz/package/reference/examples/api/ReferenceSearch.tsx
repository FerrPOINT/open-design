import index from "@pdlc/ui/reference/index.json";
import { search } from "@pdlc/ui/reference/search";

/** Reads the prepared index only; no server, filesystem scan or Storybook is needed. */
export default function searchExample(query = "выбор ресурса") {
  return search(index, query, 3);
}
