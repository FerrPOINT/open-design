import {
  connectPlatformProduct,
  getPlatformProduct,
  isPlatformProtocol,
  routePath,
  platformNavigate,
  platformReload,
  capturePlatformReturn,
  finishPlatformLogin,
} from "@pdlc/ui/platform";

/** Tests supply an isolated Window. A real product calls once at its entry point;
 * serviceKey and portalOrigin come from its configuration, never a guessed catalogue. */
export function connectExample(target: Window, portalOrigin: string) {
  const product = connectPlatformProduct({
    serviceKey: "dictionary-example",
    portalOrigin,
    window: target,
  });
  return () => product?.dispose();
}
export function platformActions(portalOrigin: string) {
  return {
    current: getPlatformProduct(),
    validProtocol: isPlatformProtocol("pdlc.platform.v1"),
    localRoute: routePath("/issues?project_scope=all", portalOrigin),
    navigate: () => platformNavigate("/issues"),
    reload: () => platformReload(),
    captureReturn: () => capturePlatformReturn(portalOrigin),
    finishLogin: () => finishPlatformLogin(portalOrigin),
  };
}
