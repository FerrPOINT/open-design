import { isUnknownWriteOutcome } from "@pdlc/ui/lib";

export default function Example() {
  const uncertain = isUnknownWriteOutcome({ status: 503 });
  return (
    <output>
      {uncertain ? "Сначала проверьте результат записи" : "Запрос отклонён"}
    </output>
  );
}
