import { contextualTarget, useNamespaceNavigate, Button } from "@pdlc/ui/ui";
import {
  parseNamespaceLocation,
  withNamespaceLocation,
  transportNamespaceLocation,
  projectNavigationScope,
  projectIdentity,
  sortProjectNavigation,
} from "@pdlc/ui/lib";
import { MemoryRouter } from "react-router";

export function namespaceTargets(search: string) {
  const ref = parseNamespaceLocation(search);
  const scope = projectNavigationScope(search, ref);
  const projects = ref
    ? [
        { name: "Команда 2", ref },
        { name: "Команда 1", ref },
      ]
    : [];
  return {
    scope,
    target: contextualTarget("/issues", search),
    url: withNamespaceLocation("/issues", ref, search),
    transport: transportNamespaceLocation("/issues", search),
    projects: sortProjectNavigation(
      projects,
      (item) => item.name,
      (item) => projectIdentity(item.ref),
    ),
  };
}
function Navigation() {
  const navigate = useNamespaceNavigate();
  return (
    <Button onClick={() => void navigate("/issues")}>
      Открыть задачи с текущим контекстом
    </Button>
  );
}
export default function Example() {
  return (
    <MemoryRouter initialEntries={["/?project_scope=all"]}>
      <Navigation />
    </MemoryRouter>
  );
}
