import {
  restoreSso,
  endSso,
  isSsoLoginRequired,
  type SsoConfig,
} from "@pdlc/ui/sso";

/** Importing is inert. Tests provide synthetic SSO replies; products call at their auth boundary. */
export async function restoreExample(config: SsoConfig) {
  try {
    return {
      kind: "authenticated" as const,
      session: await restoreSso(config, "/issues", { timeoutMs: 1000 }),
    };
  } catch (error) {
    if (isSsoLoginRequired(error)) return { kind: "login-required" as const };
    throw error;
  }
}
export function logoutExample(config: SsoConfig) {
  endSso(config);
}
