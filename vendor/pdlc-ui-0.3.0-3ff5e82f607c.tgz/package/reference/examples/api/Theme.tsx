import { useState } from "react";
import { ThemeProvider, useTheme, useOptionalTheme } from "@pdlc/ui/lib";
import { Button } from "@pdlc/ui/ui";
function Choice() {
  const { theme, setTheme } = useTheme();
  const optional = useOptionalTheme();
  return (
    <Button onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
      Тема: {optional?.theme ?? theme}
    </Button>
  );
}
export default function Example() {
  const [theme, setTheme] = useState<"light" | "dark" | "gray">("light");
  return (
    <ThemeProvider theme={theme} onThemeChange={setTheme}>
      <Choice />
    </ThemeProvider>
  );
}
