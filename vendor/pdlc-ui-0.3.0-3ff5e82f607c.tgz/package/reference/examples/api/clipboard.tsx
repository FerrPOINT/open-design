import { useClipboard } from "@pdlc/ui/lib";
import {
  Button,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@pdlc/ui/ui";

/** A menu action shares the same lifecycle as CopyButton; no clipboard access on mount. */
export default function ClipboardMenuExample() {
  const clipboard = useClipboard("demo/namespace-42");
  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button>Действия</Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem
            disabled={clipboard.pending}
            onSelect={() => {
              void clipboard.copy();
            }}
          >
            Копировать идентификатор
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      {clipboard.status === "copied" && <p role="status">Скопировано</p>}
      {clipboard.status === "error" && (
        <p role="alert">Выделите значение и скопируйте вручную.</p>
      )}
    </>
  );
}
