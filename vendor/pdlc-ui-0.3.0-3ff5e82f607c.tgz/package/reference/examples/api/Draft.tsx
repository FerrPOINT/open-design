import { createDraftTracker } from "@pdlc/ui/lib";

/** The product keeps separate trackers for independently saved parts. */
export default function draftVersionExample() {
  const tracker = createDraftTracker();
  tracker.edit();
  const submitted = tracker.beginSave();
  tracker.edit();
  tracker.finishSave(submitted, "saved");
  // The response confirms the submitted version; the later edit remains dirty.
  return { dirty: tracker.dirty, pending: tracker.pending };
}
