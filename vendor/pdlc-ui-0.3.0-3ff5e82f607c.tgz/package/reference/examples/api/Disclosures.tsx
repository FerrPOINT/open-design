import {
  useSidebarDisclosure,
  SidebarNavigationGroup,
  Button,
} from "@pdlc/ui/ui";
import { useProjectDisclosures } from "@pdlc/ui/lib";

/** Use a preview-only key; products supply their existing preference key. */
export default function Example() {
  const group = useSidebarDisclosure("/projects");
  const projects = useProjectDisclosures("dictionary:example:projects");
  return (
    <>
      <SidebarNavigationGroup label="Проекты" active compact={false} {...group}>
        <Button onClick={() => projects.toggle("synthetic-project")}>
          Изменить раскрытие проекта
        </Button>
      </SidebarNavigationGroup>
      <p>Свёрнутые проекты: {projects.collapsed.join(", ") || "нет"}</p>
    </>
  );
}
