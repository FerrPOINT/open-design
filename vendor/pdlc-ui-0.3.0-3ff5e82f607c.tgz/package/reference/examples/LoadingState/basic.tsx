import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = { message: "Загружаем проекты…" } satisfies ComponentProps<
    typeof UI.LoadingState
  >;
  const render = (args: ComponentProps<typeof UI.LoadingState>) => (
    <UI.LoadingState {...args} />
  );
  return render(args);
}
