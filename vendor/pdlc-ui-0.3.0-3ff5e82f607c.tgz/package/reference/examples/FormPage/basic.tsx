import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    title: "Новый проект",
    onSubmit: (event) => event.preventDefault(),
    actions: <UI.Button type="submit">Сохранить</UI.Button>,
    children: (
      <UI.FormField id="form-project" label="Название" required>
        {(attrs) => <UI.Input {...attrs} />}
      </UI.FormField>
    ),
  } satisfies ComponentProps<typeof UI.FormPage>;
  const render = (args: ComponentProps<typeof UI.FormPage>) => (
    <UI.FormPage {...args} />
  );
  return render(args);
}
