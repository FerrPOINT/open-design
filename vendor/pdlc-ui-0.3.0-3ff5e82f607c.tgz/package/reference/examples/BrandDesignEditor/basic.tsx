import { useState } from "react";
import {
  BrandDesignEditor,
  BrandDesignPreview,
  BrandingMark,
  BrandingPresentationProvider,
  createBrandDocument,
  type BrandDesignDocument,
  type BrandTheme,
} from "@pdlc/ui/branding";

export default function Example({
  disabled = false,
  theme = "dark",
  long = false,
  initial,
  initialVariant = "common",
  onChange,
}: {
  disabled?: boolean;
  theme?: BrandTheme;
  long?: boolean;
  initial?: BrandDesignDocument;
  initialVariant?: "common" | "light" | "dark";
  onChange?: (value: BrandDesignDocument) => void;
}) {
  const [value, setValue] = useState(() => {
    const document = structuredClone(initial ?? createBrandDocument());
    document.product_name = long
      ? "ОченьДлинноеНазваниеПлатформы".repeat(3)
      : (initial?.product_name ?? "PDLC");
    return document;
  });
  const [variant, setVariant] = useState<"common" | "light" | "dark">(
    initialVariant,
  );
  const [colorTheme, setColorTheme] = useState<BrandTheme>(theme);
  const [uploadError, setUploadError] = useState("");
  return (
    <BrandingPresentationProvider document={value} theme={colorTheme}>
      <BrandingMark document={value} theme={colorTheme} size={40} />
      <div className="base-brand-editor-layout">
        <BrandDesignEditor
          value={value}
          onChange={(next) => {
            setValue(next);
            onChange?.(next);
          }}
          disabled={disabled}
          variant={variant}
          onVariantChange={setVariant}
          colorTheme={colorTheme}
          onColorThemeChange={setColorTheme}
          onUpload={() =>
            setUploadError(
              "Загрузка изображений требует подключения Admin Panel.",
            )
          }
          uploadError={uploadError}
        />
        <BrandDesignPreview document={value} theme={colorTheme} />
      </div>
    </BrandingPresentationProvider>
  );
}
