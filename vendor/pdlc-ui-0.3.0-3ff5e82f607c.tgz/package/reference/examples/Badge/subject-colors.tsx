import { useEffect, useRef, useState } from "react";
import { Badge, Button } from "@pdlc/ui/ui";

export default function Example() {
  const [selected, setSelected] = useState(true);
  const [removed, setRemoved] = useState(0);
  const actionRef = useRef<HTMLButtonElement>(null);
  const interacted = useRef(false);
  useEffect(() => {
    // Removing a focus target is a composition decision, not a Badge side effect.
    if (interacted.current) actionRef.current?.focus();
  }, [selected]);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Badge subjectColor="#ef4444">Красная предметная метка</Badge>
        <Badge subjectColor="#1e293b">Тёмная метка</Badge>
        <Badge subjectColor="invalid">Неизвестный цвет</Badge>
        {selected ? (
          <Badge subjectColor="#eab308">
            Очень длинная выбранная метка с отдельным действием
            <Button
              type="button"
              variant="subject"
              size="icon"
              aria-label="Убрать выбранную метку"
              ref={actionRef}
              onClick={() => {
                interacted.current = true;
                setSelected(false);
                setRemoved((value) => value + 1);
              }}
            >
              ×
            </Button>
          </Badge>
        ) : (
          <Button
            type="button"
            variant="outline"
            ref={actionRef}
            onClick={() => {
              interacted.current = true;
              setSelected(true);
            }}
          >
            Восстановить метку
          </Button>
        )}
        <Badge subjectColor="#22c55e">
          Недоступное действие
          <Button
            type="button"
            variant="subject"
            size="icon"
            disabled
            aria-label="Нельзя убрать метку"
          >
            ×
          </Button>
        </Badge>
      </div>
      <p role="status">Удалений: {removed}</p>
    </div>
  );
}
