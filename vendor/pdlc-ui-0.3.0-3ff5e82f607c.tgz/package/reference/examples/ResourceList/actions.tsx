import { useState } from "react";
import { Badge, Notice, ResourceList, ResourceListButton } from "@pdlc/ui/ui";

const records = [
  { id: "alpha", name: "Одинаковое название", disabled: false },
  { id: "beta", name: "Одинаковое название", disabled: false },
  {
    id: "archived",
    name: "Недоступный ресурс с длинным названием",
    disabled: true,
  },
];

export default function ActionRowsExample() {
  const [selected, setSelected] = useState("alpha");
  return (
    <div className="base-page-stack">
      <ResourceList variant="bordered" role="group" aria-label="Ресурсы">
        {records.map((record) => (
          <ResourceListButton
            key={record.id}
            disabled={record.disabled}
            aria-pressed={selected === record.id}
            onClick={() => setSelected(record.id)}
            className="flex items-center justify-between gap-3"
          >
            <span>{record.name}</span>
            <Badge tone="muted" appearance="inline">
              {record.id}
            </Badge>
          </ResourceListButton>
        ))}
      </ResourceList>
      <Notice role="status" appearance="inline">
        Текущий ресурс: {selected}. Запросы не выполняются.
      </Notice>
    </div>
  );
}
