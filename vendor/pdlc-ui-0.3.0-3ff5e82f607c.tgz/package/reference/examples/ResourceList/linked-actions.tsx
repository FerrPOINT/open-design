import { useState } from "react";
import { Check } from "lucide-react";
import { Button, Notice, ResourceList, ResourceListRow } from "@pdlc/ui/ui";

/** A secondary action is a sibling, never a button nested inside a link. */
export default function LinkedActionsExample() {
  const [read, setRead] = useState(false);
  const [actionCount, setActionCount] = useState(0);
  function markRead() {
    setRead(true);
    setActionCount((count) => count + 1);
  }
  return (
    <div className="base-page-stack">
      <ResourceList asChild variant="bordered">
        <ul aria-label="Обновления">
          <li className="flex min-w-0 items-stretch">
            <ResourceListRow asChild interactive className="min-w-0 flex-1">
              <a href="#resource-details" onClick={markRead} className="block">
                <span className="block font-medium">Изменения проекта</span>
                <span className="block text-sm text-text-secondary">
                  Длинное содержимое остаётся в ссылке. Данные и маршрут
                  принадлежат приложению.
                </span>
              </a>
            </ResourceListRow>
            <ResourceListRow className="flex shrink-0 items-center">
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label="Отметить прочитанным"
                disabled={read}
                onClick={markRead}
              >
                <Check className="h-4 w-4" aria-hidden />
              </Button>
            </ResourceListRow>
          </li>
          <li>
            <ResourceListRow>
              Статическая запись без фиктивного перехода.
            </ResourceListRow>
          </li>
        </ul>
      </ResourceList>
      <Notice role="status" appearance="inline">
        {read ? "Прочитано" : "Не прочитано"}. Действий: {actionCount}. Hover и
        focus ничего не записывают.
      </Notice>
      <p id="resource-details">
        Синтетические подробности ресурса; запросов нет.
      </p>
    </div>
  );
}
