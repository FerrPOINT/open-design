import { useState } from "react";
import {
  Button,
  Dialog,
  DialogBody,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  FormField,
  Input,
  Prose,
} from "@pdlc/ui/ui";

export default function Example() {
  const [actions, setActions] = useState(0);
  return (
    <div className="space-y-4">
      <Dialog>
        <DialogTrigger asChild>
          <Button>Открыть диалог с секциями</Button>
        </DialogTrigger>
        <DialogContent layout="sectioned">
          <DialogHeader>
            <DialogTitle>
              Опубликованная ревизия документа с длинным названием и отдельной
              кнопкой закрытия
            </DialogTitle>
            <DialogDescription>
              Общие отступы секций и место для закрытия принадлежат Base.
            </DialogDescription>
          </DialogHeader>
          <DialogBody className="space-y-4">
            <FormField id="sectioned-note" label="Заметка">
              {(attrs) => (
                <Input
                  {...attrs}
                  defaultValue="Ввод сохраняется при прокрутке"
                />
              )}
            </FormField>
            <Prose>
              <p>
                ОченьДлиннаяСтрокаБезПробеловНеДолжнаРаздвигатьДиалогИВыходитьЗаПределыМобильногоЭкрана
              </p>
              {Array.from({ length: 12 }, (_, index) => (
                <p key={index}>
                  Раздел {index + 1}. Синтетическое содержимое ревизии позволяет
                  проверить прокрутку и доступность действий без продуктового
                  API.
                </p>
              ))}
            </Prose>
          </DialogBody>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline">
                Закрыть секции
              </Button>
            </DialogClose>
            <Button
              type="button"
              onClick={() => setActions((value) => value + 1)}
            >
              Синтетическое действие
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <p role="status">Синтетических действий: {actions}</p>
    </div>
  );
}
