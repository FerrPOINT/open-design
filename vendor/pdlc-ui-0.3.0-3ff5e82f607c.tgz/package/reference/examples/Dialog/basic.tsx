import * as UI from "@pdlc/ui/ui";
export default function Example() {
  const render = () => (
    <UI.Dialog>
      <UI.DialogTrigger asChild>
        <UI.Button>Открыть диалог</UI.Button>
      </UI.DialogTrigger>
      <UI.DialogContent>
        <UI.DialogHeader>
          <UI.DialogTitle>Название проекта</UI.DialogTitle>
          <UI.DialogDescription>
            Измените название в локальном примере.
          </UI.DialogDescription>
        </UI.DialogHeader>
        <UI.FormField id="dialog-name" label="Название">
          {(attrs) => <UI.Input {...attrs} defaultValue="Платформа" />}
        </UI.FormField>
        <UI.DialogFooter>
          <UI.DialogClose asChild>
            <UI.Button variant="outline">Закрыть</UI.Button>
          </UI.DialogClose>
        </UI.DialogFooter>
      </UI.DialogContent>
    </UI.Dialog>
  );
  return render();
}
