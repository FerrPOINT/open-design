import { useState } from "react";
import {
  Button,
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogTitle,
  FormField,
  Input,
} from "@pdlc/ui/ui";

export default function ControlledDialogExample() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button onClick={() => setOpen(true)}>Открыть управляемый диалог</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogTitle>Управляемое окно</DialogTitle>
          <DialogDescription>
            Закрытие возвращает фокус на прежний активный control без
            DialogTrigger.
          </DialogDescription>
          <FormField id="controlled-dialog-name" label="Название">
            {(attrs) => <Input {...attrs} defaultValue="Локальный пример" />}
          </FormField>
          <DialogClose asChild>
            <Button variant="outline">Закрыть пример</Button>
          </DialogClose>
        </DialogContent>
      </Dialog>
    </>
  );
}
