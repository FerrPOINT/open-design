import { Checkbox, Fieldset, FormField, Input } from "@pdlc/ui/ui";

export default function BasicExample() {
  return (
    <form onSubmit={(event) => event.preventDefault()}>
      <Fieldset legend="Настройки доступа" className="grid gap-3">
        <FormField id="fieldset-name" label="Название">
          {(props) => <Input {...props} name="name" defaultValue="Команда" />}
        </FormField>
        <Checkbox
          name="read"
          value="yes"
          label="Разрешить просмотр"
          defaultChecked
        />
      </Fieldset>
    </form>
  );
}
