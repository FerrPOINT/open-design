import { useState } from "react";
import { defaultBranding, type PlatformBranding } from "@pdlc/ui/lib";
import { BrandingEditor } from "@pdlc/ui/ui";

export default function BrandingExample({
  initial = defaultBranding,
  disabled = false,
}: {
  initial?: PlatformBranding;
  disabled?: boolean;
}) {
  const [value, setValue] = useState(initial);
  return (
    <BrandingEditor value={value} onChange={setValue} disabled={disabled} />
  );
}
