import { useState } from "react";
import { defaultBranding } from "@pdlc/ui/lib";
import { Badge, BrandingSettings, Button, PageFrame } from "@pdlc/ui/ui";

export default function SettingsExample({
  disabled = false,
}: {
  disabled?: boolean;
}) {
  const [value, setValue] = useState(defaultBranding);
  return (
    <PageFrame mode="reading">
      <BrandingSettings
        disabled={disabled}
        value={value}
        onChange={setValue}
        description="Локальный предпросмотр. Изменения не публикуются."
        actions={
          disabled ? (
            <Badge>Только чтение</Badge>
          ) : (
            <Button variant="outline" onClick={() => setValue(defaultBranding)}>
              Сбросить настройки
            </Button>
          )
        }
      />
    </PageFrame>
  );
}
