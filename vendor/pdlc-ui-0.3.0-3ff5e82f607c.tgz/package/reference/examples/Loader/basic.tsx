import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    size: "md",
    "aria-label": "Загрузка",
  } satisfies ComponentProps<typeof UI.Loader>;
  const render = (args: ComponentProps<typeof UI.Loader>) => (
    <UI.Loader {...args} />
  );
  return render(args);
}
