import { Prose, TextLink } from "@pdlc/ui/ui";

export default function Example() {
  return (
    <div className="space-y-4">
      <p>
        Связанные сведения находятся в{" "}
        <TextLink href="#record">карточке записи</TextLink>. Ссылка сохраняет
        высоту строки.
      </p>
      <p id="record">
        Назначение ссылки. URL и доступ к данным определяет приложение.
      </p>
      <Prose>
        <p>
          Подготовленный текст с <a href="#record">обычной HTML-ссылкой</a>{" "}
          использует тот же общий стиль.
        </p>
      </Prose>
    </div>
  );
}
