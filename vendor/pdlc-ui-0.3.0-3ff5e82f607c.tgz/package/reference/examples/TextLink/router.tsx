import { Link, MemoryRouter, useLocation } from "react-router";
import { TextLink } from "@pdlc/ui/ui";

function Content() {
  const at = useLocation();
  return (
    <div className="space-y-4">
      <p>
        Перейти к{" "}
        <TextLink asChild>
          <Link to="/records/item-42?scope=all#details">связанной записи</Link>
        </TextLink>
        .
      </p>
      <p role="status">Локальный адрес: {at.pathname + at.search + at.hash}</p>
    </div>
  );
}
export default function Example() {
  return (
    <MemoryRouter>
      <Content />
    </MemoryRouter>
  );
}
