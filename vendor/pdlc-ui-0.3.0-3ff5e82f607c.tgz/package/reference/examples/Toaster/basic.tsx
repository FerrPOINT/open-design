import { useId } from "react";
import { Button, Toaster, toast } from "@pdlc/ui/ui";
export default function Example() {
  const id = useId();
  return (
    <div className="base-page-actions">
      <Button onClick={() => toast("Локальное уведомление", { toasterId: id })}>
        Показать уведомление
      </Button>
      <Button
        variant="outline"
        onClick={() => toast.error("Синтетическая ошибка", { toasterId: id })}
      >
        Показать ошибку
      </Button>
      <Toaster id={id} />
    </div>
  );
}
