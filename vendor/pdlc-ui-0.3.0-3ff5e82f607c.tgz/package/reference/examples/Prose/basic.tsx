import * as UI from "@pdlc/ui/ui";

export default function Example(props: Omit<UI.ProseProps, "children"> = {}) {
  return (
    <UI.Prose {...props}>
      <h1>Описание решения</h1>
      <p>
        Опубликованный текст использует общую типографику и{" "}
        <a href="#prose-revision">ссылки</a>.
      </p>
      <h2>Критерии</h2>
      <ul>
        <li>Сохранять историю.</li>
        <li>Не подменять неизвестное значение нулём.</li>
      </ul>
      <blockquote>Данные и обработка ссылок принадлежат приложению.</blockquote>
      <p>
        Идентификатор: <code>demo-namespace-42</code>.
      </p>
      <UI.CodeBlock aria-label="Пример данных">
        {'{"amount":"0.000000000000000001"}'}
      </UI.CodeBlock>
      <table tabIndex={0} aria-label="Синтетические данные ревизий">
        <thead>
          <tr>
            <th>Ревизия</th>
            <th>Состояние</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>demo-42</td>
            <td>Опубликована</td>
          </tr>
        </tbody>
      </table>
      <p id="prose-revision">
        Ревизия из синтетического примера; продуктовые запросы не выполняются.
      </p>
    </UI.Prose>
  );
}
