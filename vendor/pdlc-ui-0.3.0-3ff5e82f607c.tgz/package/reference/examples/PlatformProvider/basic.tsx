import { PlatformProvider, usePlatformBranding } from "@pdlc/ui/lib";

function PlatformName() {
  const { branding } = usePlatformBranding();
  return <p>Платформа: {branding.product_name}</p>;
}

export default function BasicExample() {
  return (
    <PlatformProvider configUrl={null}>
      <PlatformName />
    </PlatformProvider>
  );
}
