import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useState } from "react";

function useExampleValue<T>(value: T) {
  const [current, setCurrent] = useState(value);
  useEffect(() => setCurrent(value), [value]);
  return [current, setCurrent] as const;
}

export const spaces = Array.from({ length: 20 }, (_, index) => ({
  value: `space-${index + 1}`,
  label: `Пространство ${index + 1}`,
}));

export function SearchDemo(args: ComponentProps<typeof UI.SearchableSelect>) {
  const [value, setValue] = useExampleValue(args.value);
  const [search, setSearch] = useExampleValue(args.search);
  const [offset, setOffset] = useExampleValue(args.offset);
  const options = args.options.filter((option) =>
    option.label.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <div className="space-y-4">
      <UI.SearchableSelect
        {...args}
        value={value}
        search={search}
        offset={offset}
        total={options.length}
        selectedLabel={
          value === args.value
            ? args.selectedLabel
            : args.options.find((option) => option.value === value)?.label
        }
        options={options.slice(offset, offset + args.pageSize)}
        onSearch={(next) => {
          setSearch(next);
          setOffset(0);
          args.onSearch(next);
        }}
        onPage={(next) => {
          setOffset(next);
          args.onPage(next);
        }}
        onChange={(next) => {
          setValue(next);
          args.onChange(next);
        }}
      />
      <output>Выбрано: {value || "ничего"}</output>
      <p className="text-sm text-text-muted">
        {args.options.length} локальных записей, по {args.pageSize} на странице.
        Начальное выбранное значение находится на другой странице.
      </p>
    </div>
  );
}

export default function Example() {
  const args = {
    id: "resource-picker",
    label: "Пространство",
    value: "space-12",
    selectedLabel: "Пространство 12",
    placeholder: "Выберите пространство",
    options: spaces,
    search: "",
    onSearch: () => {},
    offset: 0,
    pageSize: 5,
    total: 20,
    onPage: () => {},
    onChange: () => {},
    onRetry: () => {},
  } satisfies ComponentProps<typeof UI.SearchableSelect>;
  const render = (args: ComponentProps<typeof UI.SearchableSelect>) => (
    <SearchDemo {...args} />
  );
  return render(args);
}
