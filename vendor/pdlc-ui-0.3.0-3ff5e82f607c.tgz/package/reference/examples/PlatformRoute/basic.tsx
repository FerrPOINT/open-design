import { MemoryRouter } from "react-router";
import { PlatformRoute } from "@pdlc/ui/platform";
import type { ReactNode } from "react";
export default function BasicExample({
  children = (
    <p role="status">
      Маршрут отображён. Без parent bridge работает standalone.
    </p>
  ),
}: { children?: ReactNode } = {}) {
  return (
    <MemoryRouter>
      <PlatformRoute>{children}</PlatformRoute>
    </MemoryRouter>
  );
}
