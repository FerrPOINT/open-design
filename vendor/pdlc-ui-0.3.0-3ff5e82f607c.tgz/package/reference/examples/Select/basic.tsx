import { Select } from "@pdlc/ui/ui";
export default function Example() {
  return (
    <Select
      aria-label="Приоритет"
      defaultValue="normal"
      options={[
        { value: "low", label: "Низкий" },
        { value: "normal", label: "Обычный" },
        { value: "high", label: "Высокий" },
      ]}
    />
  );
}
