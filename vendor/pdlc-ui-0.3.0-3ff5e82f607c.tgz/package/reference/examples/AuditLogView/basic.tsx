import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    title: "История изменений",
    context: "Локальные примеры событий",
    filters: (
      <UI.Input
        type="search"
        aria-label="Поиск событий"
        placeholder="Поиск событий"
      />
    ),
    children: (
      <UI.ResourceList>
        <UI.ResourceListRow>Создан проект «Платформа»</UI.ResourceListRow>
      </UI.ResourceList>
    ),
  } satisfies ComponentProps<typeof UI.AuditLogView>;
  const render = (args: ComponentProps<typeof UI.AuditLogView>) => (
    <UI.AuditLogView {...args} />
  );
  return render(args);
}
