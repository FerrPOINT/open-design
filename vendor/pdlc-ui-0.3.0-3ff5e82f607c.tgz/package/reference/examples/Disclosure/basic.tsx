import { Disclosure, Button, ResourceList } from "@pdlc/ui/ui";
export default function Example() {
  return (
    <div className="grid gap-4">
      <Disclosure summary="Подробности">
        <p>Общее оформление и нативное управление клавиатурой.</p>
        <Button type="button" variant="outline">
          Действие внутри
        </Button>
      </Disclosure>
      <ResourceList>
        <Disclosure appearance="row" summary="Запись списка">
          <p>Содержимое и данные принадлежат продукту.</p>
        </Disclosure>
      </ResourceList>
    </div>
  );
}
