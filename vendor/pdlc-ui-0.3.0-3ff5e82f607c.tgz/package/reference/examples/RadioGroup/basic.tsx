import { Button, RadioGroup } from "@pdlc/ui/ui";

export default function RadioGroupExample() {
  return (
    <form className="base-page-stack">
      <RadioGroup
        label="Приоритет"
        name="priority"
        defaultValue="normal"
        required
        options={[
          { value: "normal", label: "Обычный" },
          { value: "high", label: "Высокий" },
          { value: "blocked", label: "Недоступно", disabled: true },
        ]}
      />
      <Button type="reset" variant="outline">
        Сбросить выбор
      </Button>
    </form>
  );
}
