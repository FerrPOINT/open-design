import { useState } from "react";
import { Button, FormField, Textarea } from "@pdlc/ui/ui";

const initial = "Описание задачи\nДополнительные условия остаются видимыми.";

/** Controlled text and reset belong to the form; measurement belongs to Base. */
export default function AutoSizeExample() {
  const [value, setValue] = useState(initial);
  return (
    <form className="base-page-stack" onReset={() => setValue(initial)}>
      <FormField
        id="autosize-description"
        label="Описание"
        hint="Поле растёт до 240 px, затем прокручивается внутри."
      >
        {(attrs) => (
          <Textarea
            {...attrs}
            autoSize
            rows={2}
            name="description"
            value={value}
            onChange={(event) => setValue(event.target.value)}
            style={{ maxHeight: 240 }}
          />
        )}
      </FormField>
      <div className="base-page-actions">
        <Button
          type="button"
          variant="outline"
          onClick={() =>
            setValue((text) => text + "\nНовая строка с подробностями задачи.")
          }
        >
          Добавить строку
        </Button>
        <Button type="reset" variant="outline">
          Сбросить текст
        </Button>
      </div>
    </form>
  );
}
