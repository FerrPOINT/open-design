import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    message: "Проектов пока нет",
    description: "Создайте первый проект, чтобы начать работу.",
    action: <UI.Button onClick={() => {}}>Создать проект</UI.Button>,
  } satisfies ComponentProps<typeof UI.EmptyState>;
  const render = (args: ComponentProps<typeof UI.EmptyState>) => (
    <UI.EmptyState {...args} />
  );
  return render(args);
}
