import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    name: "Анна Иванова",
    size: "lg",
    withName: true,
  } satisfies ComponentProps<typeof UI.InitialsAvatar>;
  const render = (args: ComponentProps<typeof UI.InitialsAvatar>) => (
    <UI.InitialsAvatar {...args} />
  );
  return render(args);
}
