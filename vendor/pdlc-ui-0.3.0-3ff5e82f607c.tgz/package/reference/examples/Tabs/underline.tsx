import { Badge, Tabs, TabsContent, TabsList, TabsTrigger } from "@pdlc/ui/ui";

/** Only the appearance changes; Radix retains keyboard and selection behavior. */
export default function UnderlineExample() {
  return (
    <Tabs defaultValue="discussion">
      <TabsList appearance="underline" aria-label="Разделы обсуждения">
        <TabsTrigger value="discussion">Обсуждение</TabsTrigger>
        <TabsTrigger value="questions">
          Вопросы <Badge tone="muted">3</Badge>
        </TabsTrigger>
        <TabsTrigger value="locked" disabled>
          Недоступный раздел
        </TabsTrigger>
      </TabsList>
      <TabsContent value="discussion">
        Синтетическое обсуждение без сетевых запросов.
      </TabsContent>
      <TabsContent value="questions">
        Три вопроса для демонстрации выбранной вкладки.
      </TabsContent>
    </Tabs>
  );
}
