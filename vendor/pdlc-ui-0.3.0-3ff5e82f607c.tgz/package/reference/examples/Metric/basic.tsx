import { Metric } from "@pdlc/ui/ui";

export default function MetricExample() {
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <Metric
        label="Выполнено"
        value={12}
        description="Подтверждённый результат"
      />
      <Metric appearance="inline" label="Ожидает" value={0} />
    </div>
  );
}
