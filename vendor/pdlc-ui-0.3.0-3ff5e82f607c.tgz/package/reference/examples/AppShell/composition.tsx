import {
  AppShell,
  Button,
  NamespaceNavLink,
  PlatformHeader,
  SidebarItem,
} from "@pdlc/ui/ui";
import { Folder } from "lucide-react";

export default function Composition() {
  return (
    <AppShell
      currentServiceKey="task-tracker"
      title="Рабочая область"
      collapsibleSidebar
      renderHeader={(navigationTrigger) => (
        <PlatformHeader
          currentServiceKey="task-tracker"
          leading={navigationTrigger}
          context={<span>Контекст продукта</span>}
        />
      )}
      renderNavigation={({ compact, mobile, onNavigate }) => (
        <nav className="base-sidebar-list" aria-label="Проекты">
          {mobile && <Button onClick={onNavigate}>Действие продукта</Button>}
          <SidebarItem asChild compact={compact}>
            <NamespaceNavLink to="/projects" onClick={onNavigate}>
              <Folder aria-hidden />
              <span className="base-sidebar-item-label">Проекты команды</span>
            </NamespaceNavLink>
          </SidebarItem>
        </nav>
      )}
    >
      <h1>Общий каркас, продуктовые маршруты и данные</h1>
    </AppShell>
  );
}
