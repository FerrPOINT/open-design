import * as UI from "@pdlc/ui/ui";
import { LayoutDashboard, Folder } from "lucide-react";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    currentServiceKey: "task-tracker",
    title: "Task Tracker",
    collapsibleSidebar: true,
    description: "Пример оболочки продукта",
    navigation: [
      { to: "/", label: "Обзор", icon: LayoutDashboard, end: true },
      { to: "/projects", label: "Проекты", icon: Folder },
    ],
    account: {
      label: "Анна Иванова",
      secondary: "Демонстрация",
      onLogout: () => {},
    },
    children: (
      <UI.ListPage title="Проекты" context="Рабочее пространство команды">
        <UI.EmptyState
          message="Проектов пока нет"
          description="Создайте первый проект"
          action={<UI.Button>Создать проект</UI.Button>}
        />
      </UI.ListPage>
    ),
  } satisfies ComponentProps<typeof UI.AppShell>;
  const render = (args: ComponentProps<typeof UI.AppShell>) => (
    <UI.AppShell {...args} />
  );
  return render(args);
}
