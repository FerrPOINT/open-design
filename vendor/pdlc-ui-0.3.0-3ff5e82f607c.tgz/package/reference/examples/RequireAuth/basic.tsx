import { create } from "zustand";
import { MemoryRouter, Routes, Route } from "react-router";
import {
  RequireAuth,
  type AuthState,
  type RequireAuthProps,
} from "@pdlc/ui/auth";
export const useDemoAuth = create<AuthState>(() => ({
  token: "synthetic-preview",
  userId: "preview",
  email: "preview@example.test",
  username: "preview",
  displayName: "Пример",
  setAuth() {},
  setUser() {},
  logout() {},
}));
export const useAnonymousAuth = create<AuthState>(() => ({
  ...useDemoAuth.getState(),
  token: null,
}));
export default function BasicExample({
  store = useDemoAuth,
  ...props
}: Partial<RequireAuthProps> = {}) {
  return (
    <MemoryRouter initialEntries={["/example"]}>
      <Routes>
        <Route
          path="/login"
          element={
            <p role="status">Требуется вход: локальный маршрут без SSO</p>
          }
        />
        <Route element={<RequireAuth {...props} store={store} />}>
          <Route
            path="/example"
            element={
              <p role="status">Маршрут открыт для синтетической сессии</p>
            }
          />
        </Route>
      </Routes>
    </MemoryRouter>
  );
}
