import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    id: "input-example",
    placeholder: "Название проекта",
    "aria-label": "Название проекта",
  } satisfies ComponentProps<typeof UI.Input>;
  const render = (args: ComponentProps<typeof UI.Input>) => (
    <UI.Input {...args} />
  );
  return render(args);
}
