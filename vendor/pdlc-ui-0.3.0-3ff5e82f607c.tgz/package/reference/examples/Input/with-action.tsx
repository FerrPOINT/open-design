import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { InputWithAction, Label } from "@pdlc/ui/ui";

/** Synthetic value only; the owner controls visibility and keeps saving outside the field. */
export default function InputWithActionExample() {
  const [visible, setVisible] = useState(false);
  return (
    <div>
      <Label htmlFor="input-action-example">Значение для демонстрации</Label>
      <InputWithAction
        id="input-action-example"
        name="example-value"
        defaultValue="Синтетический пример"
        type={visible ? "text" : "password"}
        autoComplete="off"
        action={{
          label: visible ? "Скрыть значение" : "Показать значение",
          icon: visible ? <EyeOff /> : <Eye />,
          pressed: visible,
          onAction: () => setVisible(!visible),
        }}
      />
    </div>
  );
}
