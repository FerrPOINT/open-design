import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = { size: "md", withName: true } satisfies ComponentProps<
    typeof UI.PlatformMark
  >;
  const render = (args: ComponentProps<typeof UI.PlatformMark>) => (
    <UI.PlatformMark {...args} />
  );
  return render(args);
}
