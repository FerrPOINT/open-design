import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = { failed: false, onRetry: () => {} } satisfies ComponentProps<
    typeof UI.SsoCallbackView
  >;
  const render = (args: ComponentProps<typeof UI.SsoCallbackView>) => (
    <UI.SsoCallbackView {...args} />
  );
  return render(args);
}
