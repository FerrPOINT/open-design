import { Link, useLocation } from "react-router";
import { Badge, SectionNavigation, SectionNavigationItem } from "@pdlc/ui/ui";

const sections = [
  { id: "navigation-overview", label: "Основное", count: 1 },
  { id: "navigation-checks", label: "Проверки", count: 3 },
  {
    id: "navigation-evidence",
    label: "Подтверждения с длинным названием раздела",
    count: 2,
  },
];

/** The router owns the fragment; Base only paints links and their current state. */
export default function VerticalExample() {
  const { hash } = useLocation();
  const current = hash || "#navigation-overview";
  return (
    <div className="base-page-stack">
      <SectionNavigation orientation="vertical" aria-label="Разделы документа">
        {sections.map((section) => (
          <SectionNavigationItem
            key={section.id}
            asChild
            aria-current={current === `#${section.id}` ? "location" : undefined}
          >
            <Link to={{ hash: `#${section.id}` }}>
              <span>{section.label}</span>
              <Badge tone="muted" appearance="inline">
                {section.count}
              </Badge>
            </Link>
          </SectionNavigationItem>
        ))}
      </SectionNavigation>
      <p>
        Адресом и выбором управляет Router; компонент не сохраняет данные и не
        запускает scrollspy.
      </p>
      {sections.map((section) => (
        <section key={section.id} id={section.id} aria-label={section.label}>
          <h3>{section.label}</h3>
          <p>Синтетическое содержание раздела.</p>
        </section>
      ))}
    </div>
  );
}
