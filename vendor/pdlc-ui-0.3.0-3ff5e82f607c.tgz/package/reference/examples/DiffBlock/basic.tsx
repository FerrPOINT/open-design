import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    patch:
      '--- a/config.json\n+++ b/config.json\n@@ -1 +1 @@\n- {"enabled": false}\n+ {"enabled": true}',
    notice: "Пример изменения конфигурации",
    "aria-label": "Изменения конфигурации",
  } satisfies ComponentProps<typeof UI.DiffBlock>;
  const render = (args: ComponentProps<typeof UI.DiffBlock>) => (
    <UI.DiffBlock {...args} />
  );
  return render(args);
}
