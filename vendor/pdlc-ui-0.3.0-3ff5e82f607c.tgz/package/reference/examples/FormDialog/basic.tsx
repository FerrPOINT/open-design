import { useRef, useState } from "react";
import { Button, FormDialog, FormField, Input } from "@pdlc/ui/ui";

export default function Example({
  pending = false,
  error,
  long = false,
}: {
  pending?: boolean;
  error?: string;
  long?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("");
  const trigger = useRef<HTMLButtonElement>(null);
  return (
    <>
      <Button ref={trigger} onClick={() => setOpen(true)}>
        Изменить
      </Button>
      <FormDialog
        open={open}
        onOpenChange={setOpen}
        title={
          long
            ? "Изменить название сервиса в выбранном рабочем пространстве"
            : "Изменить сервис"
        }
        pending={pending}
        error={error}
        dirty={Boolean(value)}
        returnFocusRef={trigger}
        onSubmit={(event) => {
          event.preventDefault();
          setOpen(false);
        }}
        actions={<Button type="submit">Сохранить</Button>}
      >
        <FormField id="dialog-name" label="Название" required>
          {(attrs) => (
            <Input
              {...attrs}
              value={value}
              onChange={(event) => setValue(event.target.value)}
            />
          )}
        </FormField>
      </FormDialog>
    </>
  );
}
