import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    data: ["Платформа", "Документация"],
    isLoading: false,
    error: null,
    isEmpty: (data: unknown) => Array.isArray(data) && data.length === 0,
    empty: {
      title: "Проектов пока нет",
      description: "Создайте первый проект",
    },
    onRetry: () => {},
    children: (data: unknown) => (
      <ul>
        {(data as string[]).map((name) => (
          <li key={name}>{name}</li>
        ))}
      </ul>
    ),
  } satisfies ComponentProps<typeof UI.QueryState>;
  const render = (args: ComponentProps<typeof UI.QueryState>) => (
    <UI.QueryState {...args} />
  );
  return render(args);
}
