import { useCallback, useState } from "react";
import {
  AccessFreshnessBoundary,
  FormField,
  Input,
  type AdmissionWindowV1,
} from "@pdlc/ui/ui";

// Synthetic display metadata only. Real products use an authorized owner endpoint.
const load = async (): Promise<AdmissionWindowV1> => ({
  schema_version: 1,
  enforced: true,
  remaining_millis: 60000,
  scope_revision: "a".repeat(64),
});
export default function Example() {
  const [generation, setGeneration] = useState(0);
  const retire = useCallback(() => setGeneration((value) => value + 1), []);
  return (
    <AccessFreshnessBoundary
      enabled
      authorityKey={generation}
      load={load}
      onRetire={retire}
    >
      <form key={generation}>
        <FormField label="Черновик" id="access-fixture-draft">
          {(attrs) => <Input {...attrs} defaultValue="Приватный текст" />}
        </FormField>
      </form>
    </AccessFreshnessBoundary>
  );
}
