import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useMemo, useState } from "react";
import { createMemoryRouter, Link, RouterProvider } from "react-router";

function DraftEditor({ enabled }: { enabled: boolean }) {
  const [text, setText] = useState("Черновик проекта");
  const [saved, setSaved] = useState(text);
  return (
    <div className="space-y-4">
      <UI.UnsavedChangesGuard when={enabled && text !== saved} />
      <UI.FormField id="draft" label="Черновик">
        {(attrs) => (
          <UI.Textarea
            {...attrs}
            value={text}
            onChange={(event) => setText(event.target.value)}
          />
        )}
      </UI.FormField>
      <div className="flex flex-wrap gap-2">
        <UI.Button disabled={text === saved} onClick={() => setSaved(text)}>
          Сохранить локально
        </UI.Button>
        <UI.Button asChild variant="outline">
          <Link to="/next">Перейти дальше</Link>
        </UI.Button>
      </div>
      <output>
        {text === saved
          ? "Правки подтверждены локально"
          : "Есть несохранённые правки"}
      </output>
    </div>
  );
}

export function UnsavedDemo({ enabled }: { enabled: boolean }) {
  const router = useMemo(
    () =>
      createMemoryRouter([
        { path: "/", element: <DraftEditor enabled={enabled} /> },
        {
          path: "/next",
          element: (
            <div className="space-y-4">
              <p>Следующая локальная страница</p>
              <Link to="/">Вернуться к редактору</Link>
            </div>
          ),
        },
      ]),
    [enabled],
  );
  useEffect(() => () => router.dispose(), [router]);
  return <RouterProvider router={router} />;
}

export default function Example() {
  const args = { when: true } satisfies ComponentProps<
    typeof UI.UnsavedChangesGuard
  >;
  const render = (args: ComponentProps<typeof UI.UnsavedChangesGuard>) => (
    <UnsavedDemo enabled={args.when} />
  );
  return render(args);
}
