import { useState } from "react";
import { Button } from "@pdlc/ui/ui";

export default function Example() {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="base-page-stack">
      <Button
        type="button"
        variant="outline"
        aria-pressed={expanded}
        onClick={() => setExpanded((current) => !current)}
      >
        Подробности
      </Button>
      <p role="status">{expanded ? "Подробности включены" : "Краткий вид"}</p>
    </div>
  );
}
