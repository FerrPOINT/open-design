import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    children: "Сохранить",
    variant: "default",
    size: "default",
    onClick: () => {},
  } satisfies ComponentProps<typeof UI.Button>;
  const render = (args: ComponentProps<typeof UI.Button>) => (
    <UI.Button {...args} />
  );
  return render(args);
}
