import { useState } from "react";
import { Button } from "@pdlc/ui/ui";
import { Trash2 } from "lucide-react";

export default function Example() {
  const [actions, setActions] = useState(0);
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Button
          type="button"
          variant="destructive-outline"
          onClick={() => setActions((value) => value + 1)}
        >
          Удалить выбранную запись
        </Button>
        <Button
          type="button"
          variant="destructive-outline"
          size="icon"
          aria-label="Удалить выбранную запись иконкой"
          onClick={() => setActions((value) => value + 1)}
        >
          <Trash2 className="h-4 w-4" aria-hidden />
        </Button>
        <Button
          type="button"
          variant="destructive-outline"
          disabled
          onClick={() => setActions((value) => value + 1)}
        >
          Действие недоступно
        </Button>
      </div>
      <p role="status">Синтетических действий: {actions}</p>
    </div>
  );
}
