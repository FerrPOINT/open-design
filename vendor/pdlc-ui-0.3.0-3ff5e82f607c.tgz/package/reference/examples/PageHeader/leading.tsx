import { useState } from "react";
import { PageHeader, Badge, Button } from "@pdlc/ui/ui";

export default function LeadingExample() {
  const [actions, setActions] = useState(0);
  return (
    <div className="base-page-stack">
      <PageHeader
        title="Проект платформы"
        leading={<Badge tone="info">PD</Badge>}
        context="Знак задаёт продукт. Заголовок, переносы и ряд действий оформлены в Base."
        actions={
          <Button onClick={() => setActions((n) => n + 1)}>
            Локальное действие
          </Button>
        }
      />
      <output aria-label="Действия">
        Выполнено: {actions}. Данные не сохраняются.
      </output>
    </div>
  );
}
