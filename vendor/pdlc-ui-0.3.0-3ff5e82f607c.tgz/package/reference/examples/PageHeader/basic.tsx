import * as UI from "@pdlc/ui/ui";
import { type ComponentProps } from "react";

export default function Example() {
  const args = {
    title: "Подключённые проекты",
    context: "Показатели относятся к проектам из этого каталога",
    actions: (
      <>
        <UI.Button variant="outline">Настройки</UI.Button>
        <UI.Button>Добавить проект</UI.Button>
      </>
    ),
  } satisfies ComponentProps<typeof UI.PageHeader>;
  const render = (args: ComponentProps<typeof UI.PageHeader>) => (
    <UI.PageHeader {...args} />
  );
  return render(args);
}
