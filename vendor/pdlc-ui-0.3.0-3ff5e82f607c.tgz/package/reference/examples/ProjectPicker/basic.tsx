import * as UI from "@pdlc/ui/ui";
import { type ComponentProps, useEffect, useState } from "react";

function useExampleValue<T>(value: T) {
  const [current, setCurrent] = useState(value);
  useEffect(() => setCurrent(value), [value]);
  return [current, setCurrent] as const;
}

export function ControlledProjectPicker(
  args: ComponentProps<typeof UI.ProjectPicker>,
) {
  const [value, setValue] = useExampleValue(args.value);
  return (
    <div className="space-y-4">
      <UI.ProjectPicker
        {...args}
        value={value}
        onChange={(next) => {
          setValue(next);
          args.onChange(next);
        }}
      />
      <output>Выбрано: {value || "ничего"}</output>
    </div>
  );
}

export default function Example() {
  const args = {
    value: "BASE",
    options: [
      { value: "BASE", label: "Платформа", projectKey: "BASE" },
      { value: "DOCS", label: "Документация", projectKey: "DOCS" },
    ],
    placeholder: "Выберите проект",
    onChange: () => {},
    allowEmpty: true,
  } satisfies ComponentProps<typeof UI.ProjectPicker>;
  const render = (args: ComponentProps<typeof UI.ProjectPicker>) => (
    <ControlledProjectPicker {...args} />
  );
  return render(args);
}
