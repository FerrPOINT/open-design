import { PLATFORM_PROTOCOL, isPlatformProtocol, routePath } from './bridge.js'
import { platformTitle } from '../lib/platform-title.js'

/** @param {import("./contracts").PlatformConfig} config */
export function validatePlatformConfig(config) {
  if (config?.protocol !== undefined && !isPlatformProtocol(config.protocol)) throw new Error('Неподдерживаемый протокол PDLC.')
  if (!config || !Array.isArray(config.services) || !config.services.length) throw new Error('Не настроены приложения PDLC.')
  const keys = new Set(), paths = new Set(), origins = new Set()
  for (const service of config.services) {
    const url = new URL(service.origin)
    if (!/^[a-z0-9-]+$/.test(service.key) || !/^\/[a-z0-9-]+\/$/.test(service.path) || !['http:', 'https:'].includes(url.protocol) || url.href !== url.origin + '/' || !service.label || keys.has(service.key) || paths.has(service.path) || origins.has(url.origin)) throw new Error('Некорректный каталог размещения PDLC.')
    keys.add(service.key); paths.add(service.path); origins.add(url.origin)
    service.origin = url.origin
  }
  return config
}

export class PlatformHost {
  /** @param {{root: HTMLElement, config: import("./contracts").PlatformConfig, window?: Window, onError?: (message: string | null) => void, timeoutMs?: number}} options */
  constructor({ root, config, window: target = window, onError = () => {}, timeoutMs = 15000 }) {
    this.root = root; this.window = target; this.config = validatePlatformConfig(config)
    this.onError = onError; this.timeoutMs = timeoutMs
    this.active = null; this.candidate = null; this.retiring = null; this.index = 0; this.popAction = null
    this.receive = event => this.message(event)
    this.pop = () => this.popstate()
    target.addEventListener('message', this.receive)
    target.addEventListener('popstate', this.pop)
    target.history.replaceState({ platformIndex: 0 }, '', target.location.href)
  }
  resolve(value) {
    const url = new URL(value, this.window.location.origin)
    for (const service of this.config.services) {
      if (url.origin === service.origin) return { service, route: routePath(url.href, service.origin) }
      if (url.origin === this.window.location.origin && (url.pathname === service.path.slice(0, -1) || url.pathname.startsWith(service.path))) {
        return { service, route: routePath('/' + url.pathname.slice(service.path.length) + url.search + url.hash, service.origin) }
      }
    }
    throw new Error('Приложение не настроено для размещения в PDLC.')
  }
  publicUrl({ service, route }) { return service.path.slice(0, -1) + route }
  start() {
    let target
    try { target = this.resolve(this.window.location.href) } catch { target = { service: this.config.services[0], route: '/' } }
    this.prepare(target, { replace: true })
  }
  navigate(value, options = {}) {
    try { this.prepare(this.resolve(value), options) } catch (error) { this.onError(error.message) }
  }
  prepare(target, options) {
    this.cancel()
    this.root.dataset.platformPreparing = target.service.label
    this.root.dataset.platformPreparingKey = target.service.key
    if (this.retiring) {
      this.afterRetire = { target, options }
      this.retire(this.retiring)
      return
    }
    const frame = this.window.document.createElement('iframe')
    const attempt = { ...target, options, frame, id: this.window.crypto.randomUUID(), ready: false, leaving: false, allowed: false, activationRequested: false }
    frame.title = target.service.label
    frame.className = 'platform-frame platform-frame-preparing'
    frame.dataset.platformFrame = target.service.key
    frame.setAttribute('aria-hidden', 'true'); frame.inert = true
    // Keep a real viewport for layout; display:none would prevent meaningful readiness.
    frame.src = target.service.origin + target.route
    this.candidate = attempt
    this.root.append(frame)
    this.lastTarget = target
    this.loginUrl = undefined
    attempt.timer = this.window.setTimeout(() => this.fail(attempt, 'Приложение не подтвердило готовность. Текущий экран сохранён.'), this.timeoutMs)
    this.onError(null)
  }
  cancel() {
    delete this.root.dataset.platformPreparing; delete this.root.dataset.platformPreparingKey
    this.afterRetire = null
    if (this.candidate) {
      this.window.clearTimeout(this.candidate.timer); this.candidate.frame.remove(); this.candidate = null
    }
    if (this.active) this.send(this.active, 'resume')
  }
  send(attempt, type, payload = {}) {
    attempt.frame.contentWindow?.postMessage({ protocol: this.config.protocol ?? PLATFORM_PROTOCOL, serviceKey: attempt.service.key, attemptId: attempt.id, type, ...payload }, attempt.service.origin)
  }
  message(event) {
    const data = event.data
    if (!data || !isPlatformProtocol(data.protocol)) return
    const attempt = [this.active, this.candidate, this.retiring].find(item => item && item.frame.contentWindow === event.source && item.service.origin === event.origin && item.service.key === data.serviceKey)
    if (!attempt) return
    if (attempt === this.retiring) {
      if (data.protocol === (this.config.protocol ?? PLATFORM_PROTOCOL) && data.attemptId === attempt.id && data.type === 'retired') this.finishRetire(attempt)
      return
    }
    if (data.type === 'connect') {
      this.send(attempt, 'initialize', { publicPath: attempt.service.path, services: this.config.services })
      return
    }
    if (data.protocol !== (this.config.protocol ?? PLATFORM_PROTOCOL)) return
    if (data.attemptId !== attempt.id) return
    if (data.type === 'route' && typeof data.route === 'string' && attempt === this.candidate) {
      try { attempt.route = routePath(data.route, attempt.service.origin) } catch { this.fail(attempt, 'Недопустимое перенаправление приложения.') }
      return
    }
    if (data.type === 'login-required') {
      this.loginUrl = attempt.service.origin + '/login?platform_return=' + encodeURIComponent(this.publicUrl(attempt))
      if (attempt === this.candidate) this.fail(attempt, 'Центральная сессия завершена. Войдите через SSO.')
      else {
        this.cancel(); attempt.frame.remove(); this.active = null
        delete this.root.dataset.platformActive
        this.root.dataset.platformReady = 'false'
        this.onError('Центральная сессия завершена. Войдите через SSO.')
      }
      return
    }
    if (data.type === 'session-ending' && typeof data.url === 'string' && attempt === this.active) {
      let destination
      try { destination = new URL(data.url) } catch { return }
      if (destination.origin !== this.config.authOrigin || destination.pathname !== '/oidc/logout') return
      this.cancel(); this.active?.frame.remove(); this.active = null
      this.root.dataset.platformReady = 'false'; delete this.root.dataset.platformActive
      this.window.location.assign(destination.href)
      return
    }
    if (attempt === this.active) {
      if (data.type === 'navigate' && typeof data.url === 'string') {
        // An expired access token does not prove the central browser session ended.
        // Keep a user-selected target when its fresh SSO check is already underway.
        if (data.recheckAuth === true) {
          if (!this.candidate && !this.afterRetire) this.prepare({ service: attempt.service, route: attempt.route }, { replace: true })
        } else this.navigate(data.url, { replace: data.replace === true })
      }
      if (data.type === 'route' && typeof data.route === 'string') {
        try { attempt.route = routePath(data.route, attempt.service.origin); this.history(attempt, data.replace === true) } catch { /* Reject foreign/technical routes. */ }
      }
      if (data.type === 'leave-result' && this.candidate?.id === data.transitionId && typeof data.allowed === 'boolean') {
        if (data.allowed) this.activate(this.candidate)
        else this.cancel()
      }
      return
    }
    if (data.type === 'error' && typeof data.message === 'string') this.fail(attempt, data.message)
    if (data.type === 'pending') { attempt.ready = false; attempt.activationRequested = false }
    if (data.type === 'ready') {
      attempt.ready = true
      if (!attempt.leaving) {
        this.window.clearTimeout(attempt.timer)
        // Leave dialogs remain unobstructed; a transient pending target does
        // not invalidate the current product's decision to leave.
        delete this.root.dataset.platformPreparing; delete this.root.dataset.platformPreparingKey
        attempt.leaving = true
        if (this.active) this.send(this.active, 'prepare-leave', { transitionId: attempt.id })
        else this.activate(attempt)
      } else if (attempt.allowed) this.activate(attempt)
    }
    if (data.type === 'activated' && attempt.ready && attempt.allowed && attempt.activationRequested) {
      if (attempt.options.pop) {
        this.popAction = { kind: 'commit', index: attempt.options.index, run: () => this.commit(attempt) }
        this.window.history.go(attempt.options.delta)
      } else this.commit(attempt)
    }
  }
  retry() { if (this.lastTarget) this.prepare(this.lastTarget, {}) }
  setBranding(branding) {
    this.config.branding = branding
    if (this.active) this.window.document.title = platformTitle(this.active.service.label, branding)
  }
  activate(attempt) {
    this.root.dataset.platformPreparing = attempt.service.label
    this.root.dataset.platformPreparingKey = attempt.service.key
    if (!attempt.allowed) {
      attempt.allowed = true
      // One fixed deadline covers all readiness changes after leave approval.
      attempt.timer = this.window.setTimeout(() => this.fail(attempt, 'Приложение не подтвердило показ экрана. Текущий экран сохранён.'), this.timeoutMs)
    }
    if (attempt.ready && !attempt.activationRequested) {
      attempt.activationRequested = true
      this.send(attempt, 'activate')
    }
  }
  history(attempt, replace) {
    if (!replace) this.index++
    this.window.history[replace ? 'replaceState' : 'pushState']({ platformIndex: this.index }, '', this.publicUrl(attempt))
  }
  commit(attempt) {
    if (this.candidate !== attempt) return
    this.window.clearTimeout(attempt.timer)
    const old = this.active
    attempt.frame.className = 'platform-frame platform-frame-active'
    attempt.frame.removeAttribute('aria-hidden'); attempt.frame.inert = false
    if (old) {
      old.frame.className = 'platform-frame platform-frame-retiring'
      old.frame.setAttribute('aria-hidden', 'true'); old.frame.inert = true
    }
    if (!attempt.options.pop) this.history(attempt, attempt.options.replace === true)
    this.active = attempt; this.candidate = null; this.retiring = old
    this.window.document.title = platformTitle(attempt.service.label, this.config.branding)
    delete this.root.dataset.platformPreparing; delete this.root.dataset.platformPreparingKey
    this.root.dataset.platformActive = attempt.service.key
    this.root.dataset.platformReady = 'true'
    this.send(attempt, 'resume')
    this.send(attempt, 'committed')
    attempt.frame.focus()
    // This delay retires the already covered screen; it is not the readiness test.
    this.window.requestAnimationFrame(() => this.window.requestAnimationFrame(() => {
      if (old && this.retiring === old) this.retire(old)
    }))
  }
  retire(attempt) {
    if (attempt.retireTimer) return
    attempt.retireTimer = this.window.setTimeout(() => this.finishRetire(attempt), 1000)
    this.send(attempt, 'retire')
  }
  finishRetire(attempt) {
    if (this.retiring !== attempt) return
    this.window.clearTimeout(attempt.retireTimer)
    attempt.frame.remove(); this.retiring = null
    const next = this.afterRetire; this.afterRetire = null
    if (next) this.prepare(next.target, next.options)
  }
  fail(attempt, message) {
    if (this.candidate !== attempt) return
    this.cancel(); this.onError(message)
  }
  popstate() {
    const index = this.window.history.state?.platformIndex
    if (!Number.isInteger(index)) return
    if (this.popAction && this.popAction.index === index) {
      const action = this.popAction; this.popAction = null; this.index = index; action.run(); return
    }
    const delta = index - this.index
    if (!delta) return
    const target = this.window.location.href
    this.popAction = { kind: 'restore', index: this.index, run: () => this.navigate(target, { pop: true, index, delta }) }
    this.window.history.go(-delta)
  }
  dispose() {
    this.window.clearTimeout(this.retiring?.retireTimer)
    this.cancel(); this.active?.frame.remove(); this.retiring?.frame.remove()
    this.root.dataset.platformReady = 'false'; delete this.root.dataset.platformActive
    this.window.removeEventListener('message', this.receive); this.window.removeEventListener('popstate', this.pop)
  }
}
