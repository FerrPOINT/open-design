import {
  useEffect,
  useState,
  useSyncExternalStore,
  type ReactNode,
} from "react";
import {
  setPlatformQueryClient,
  type PlatformQueryClient,
} from "./query-client";

export interface PlatformQueryScope {
  getSnapshot(): number | undefined;
  subscribe(listener: () => void): () => void;
}

export interface PlatformQuerySessionProps<
  T extends PlatformQueryClient & { clear(): void },
> {
  scope: PlatformQueryScope;
  createClient(): T;
  children(client: T): ReactNode;
}

/** Cache and local forms share a product-owned, monotonic authorization revision. */
export function PlatformQuerySession<
  T extends PlatformQueryClient & { clear(): void },
>(props: PlatformQuerySessionProps<T>) {
  const version = useSyncExternalStore(
    props.scope.subscribe,
    props.scope.getSnapshot,
    props.scope.getSnapshot,
  );
  return <QuerySession key={version} {...props} version={version} />;
}

function QuerySession<T extends PlatformQueryClient & { clear(): void }>({
  scope,
  version,
  createClient,
  children,
}: PlatformQuerySessionProps<T> & { version: number | undefined }) {
  const [client] = useState(createClient);
  setPlatformQueryClient(client);
  useEffect(() => {
    const clearPrevious = () => {
      if (scope.getSnapshot() !== version) client.clear();
    };
    clearPrevious();
    return scope.subscribe(clearPrevious);
  }, [client, scope, version]);
  return <>{children(client)}</>;
}

/** Read retries never apply to writes, authorization failures or validation errors. */
export const platformQueryDefaults = {
  queries: {
    retry: (failureCount: number, error: unknown) => {
      if (failureCount >= 4) return false;
      const status = (error as { status?: number } | null | undefined)?.status;
      return status === undefined || status === 429 || status >= 500;
    },
    retryDelay: (attempt: number) => Math.min(1000 * 2 ** attempt, 10_000),
  },
  mutations: { retry: false },
} as const;
