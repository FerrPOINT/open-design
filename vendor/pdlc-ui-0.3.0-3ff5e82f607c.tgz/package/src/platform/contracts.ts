export interface PlatformService { key: string; label: string; origin: string; path: string }
export interface ProductReadiness { ready: boolean; error: string | null }
export interface PlatformProduct {
  serviceKey: string
  readonly portalOrigin: string
  readonly route: string
  readonly services: PlatformService[]
  readonly publicPath: string | null
  subscribe(listener: () => void): () => void
  readiness(status: ProductReadiness, predicate?: () => ProductReadiness): void
  addReadinessSource(source: () => ProductReadiness): () => void
  refreshReadiness(): void
  onCommitted(callback: () => void): () => void
  onRetire(callback: () => void): () => void
  reportRoute(path: string, replace?: boolean): void
  requestNavigation(url: string, options?: { replace?: boolean }): void
  recheckAuthorization(): void
  setNavigator(handler: (url: string, options?: { replace?: boolean }) => void): void
  navigate(url: string, options?: { replace?: boolean }): void
  addLeaveGuard(guard: () => Promise<boolean> | boolean, cancel?: () => void): () => void
  endingSession(url: string): void
  requireLogin(route: string): void
  dispose(): void
}

export interface PlatformConfig { authOrigin: string; services: PlatformService[]; branding?: { product_short_name?: string }; protocol?: 'sdlc.platform.v1' | 'pdlc.platform.v1' }
