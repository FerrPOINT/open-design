// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** Observe the host's pending target; this indicator never controls readiness. */
/** @param {HTMLElement} root @param {HTMLElement} indicator @param {{delayMs?: number}} [options] */
export function connectLoadingIndicator(root: HTMLElement, indicator: HTMLElement, { delayMs }?: {
    delayMs?: number;
}): () => void;
