// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** @param {unknown} value */
export function isPlatformProtocol(value: unknown): value is "sdlc.platform.v1" | "pdlc.platform.v1";
/** Transport immutable namespace references without guessing a destination ID. */
/** @param {string} value @param {string} search */
export function transportNamespaceLocation(value: string, search: string): string;
/** @param {string} value @param {string} origin */
export function routePath(value: string, origin: string): string;
/** @returns {import("./contracts").PlatformProduct | null} */
export function getPlatformProduct(): import("./contracts").PlatformProduct | null;
/** @param { {serviceKey: string, portalOrigin?: string, window?: Window} } options @returns {import("./contracts").PlatformProduct | null} */
export function connectPlatformProduct({ serviceKey, portalOrigin, window: target }: {
    serviceKey: string;
    portalOrigin?: string;
    window?: Window;
}): import("./contracts").PlatformProduct | null;
/** @param {string} url @param { {replace?: boolean} } [options] */
export function platformNavigate(url: string, options?: {
    replace?: boolean;
}): void;
export function platformReload(): void;
/** @param {string} [portalOrigin] */
export function capturePlatformReturn(portalOrigin?: string): void;
/** @param {string} [portalOrigin] */
export function finishPlatformLogin(portalOrigin?: string): boolean;
export const PLATFORM_PROTOCOL: "sdlc.platform.v1";
export const PDLC_PLATFORM_PROTOCOL: "pdlc.platform.v1";
export type { PlatformService, ProductReadiness, PlatformProduct } from './contracts';
