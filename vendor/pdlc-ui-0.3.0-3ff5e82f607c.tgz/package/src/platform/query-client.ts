interface QueryLike {
  isActive(): boolean;
  state: { status: string; error?: unknown };
}

export interface PlatformQueryClient {
  getQueryCache(): {
    getAll(): QueryLike[];
    subscribe(listener: () => void): () => void;
  };
  isFetching(): number;
  clear?(): void;
}

let client: PlatformQueryClient | null = null;

export function setPlatformQueryClient(value: PlatformQueryClient) {
  client = value;
}

export function getPlatformQueryClient() {
  return client;
}
