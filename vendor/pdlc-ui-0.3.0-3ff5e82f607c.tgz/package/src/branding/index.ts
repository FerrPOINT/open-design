import "./branding.css";

export { BrandingEditor as BrandDesignEditor } from "./editor";
export { BrandingPreview as BrandDesignPreview } from "./preview";
export { BrandingMark } from "./mark";
export { BrandingPresentationProvider } from "./context";
export {
  createBrandDocument,
  validateBrand,
  referencedAssets,
  flattenDocument,
} from "./model";
export {
  normalizeBranding,
  brandingWireSnapshot,
  type BrandingWireDocument,
} from "./normalize";
export type {
  BrandDesignDocument,
  BrandMark,
  BrandTheme,
  BrandAsset,
  MarkVariant,
} from "./model";

export { BrandingWorkspaceLayout } from "./workspace-layout";

export {
  defaultDesign,
  brandingPresets,
  resolveBrandingTokens,
  createBrandingRuntime,
} from "../lib/branding-runtime.js";
export type { BrandingDesign } from "../lib/branding-runtime.js";

export { BrandingScope } from "../lib/branding-scope";
