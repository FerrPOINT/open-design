import {
  cloneElement,
  useId,
  useState,
  type ReactElement,
  type ReactNode,
} from "react";
import {
  Image,
  Info,
  Link,
  Palette,
  Search,
  Shapes,
  Type,
  Upload,
  X,
} from "lucide-react";
import { Button, Input, Select, Checkbox, FormField } from "../ui";
import { brandingPresets } from "../lib/branding-runtime.js";
import { brandIcons, BrandingMark } from "./mark";
import { BrandingProfilePicker } from "./profile-picker";
import {
  isHex,
  palettes,
  radiusLimits,
  radiusNames,
  radiusPresets,
  themeNames,
  themes,
  variantNames,
  type BrandDesignDocument,
  type BrandMark,
  type BrandTheme,
  type MarkVariant,
  type RadiusKey,
} from "./model";

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactElement<{ id?: string }>;
}) {
  const generated = useId();
  const id = children.props.id ?? generated;
  return (
    <div className="base-brand-field">
      <label htmlFor={id}>{label}</label>
      {cloneElement(children, { id })}
    </div>
  );
}
function ColorField({
  label,
  value,
  disabled,
  onChange,
}: {
  label: string;
  value: string;
  disabled: boolean;
  onChange: (value: string) => void;
}) {
  return (
    <div className="base-brand-field">
      <span>{label}</span>
      <div className="base-brand-color">
        <Input
          type="color"
          aria-label={`${label}: выбрать цвет`}
          disabled={disabled}
          value={isHex(value) ? value : "#ffffff"}
          onChange={(e) => onChange(e.target.value)}
        />
        <Input
          aria-label={`${label}: HEX`}
          value={value}
          disabled={disabled}
          spellCheck={false}
          aria-invalid={!isHex(value)}
          onChange={(e) => onChange(e.target.value)}
        />
      </div>
    </div>
  );
}
function Block({
  title,
  icon,
  children,
}: {
  title: string;
  icon: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="base-brand-block">
      <h2>
        {icon}
        {title}
      </h2>
      {children}
    </section>
  );
}
export function BrandingEditor({
  value,
  onChange: requestChange,
  disabled = false,
  variant,
  onVariantChange,
  colorTheme,
  onColorThemeChange,
  onUpload,
  uploadError,
  uploading = false,
  uploadDisabledReason,
  assetUrls,
}: {
  value: BrandDesignDocument;
  onChange: (value: BrandDesignDocument) => void;
  disabled?: boolean;
  variant: MarkVariant;
  onVariantChange: (value: MarkVariant) => void;
  colorTheme: BrandTheme;
  onColorThemeChange: (value: BrandTheme) => void;
  onUpload: (target: MarkVariant | "favicon", file: File) => void;
  uploadError: string;
  uploading?: boolean;
  uploadDisabledReason?: string;
  assetUrls?: ReadonlyMap<string, string>;
}) {
  const onChange = (next: BrandDesignDocument) => {
    if (!disabled) requestChange(next);
  };
  const [query, setQuery] = useState("");
  const id = useId();
  const design = value.design;
  const ownMark = design.marks[variant];
  const mark = ownMark ?? design.marks.common;
  const markDisabled = disabled || !ownMark;
  const updateDesign = (patch: Partial<typeof design>) =>
    onChange({ ...value, design: { ...design, ...patch } });
  const updateMark = (patch: Partial<BrandMark>) =>
    updateDesign({
      marks: { ...design.marks, [variant]: { ...mark, ...patch } },
    });
  const updateLegacyUrl = (key: "logo_url" | "favicon_url", url: string) => {
    const next = { ...value, [key]: url || null };
    if (key === "logo_url") {
      const marks = { ...design.marks };
      let changed = false;
      for (const variant of ["common", "light", "dark"] as const) {
        const current = marks[variant];
        if (current?.image?.id !== "legacy-logo") continue;
        changed = true;
        marks[variant] = {
          ...current,
          kind: url ? current.kind : "letters",
          image: url ? { ...current.image, url } : null,
        };
      }
      if (changed) next.design = { ...design, marks };
    } else if (design.favicon.image?.id === "legacy-favicon") {
      next.design = {
        ...design,
        favicon: {
          ...design.favicon,
          mode: url ? design.favicon.mode : "auto",
          image: url ? { ...design.favicon.image, url } : null,
        },
      };
    }
    onChange(next);
  };
  const uploadField = (
    target: MarkVariant | "favicon",
    currentName: string | undefined,
    blocked: boolean,
  ) => (
    <div className="base-brand-upload">
      <label className="base-brand-file">
        <Upload size={16} />
        <span>
          {currentName ? "Заменить изображение" : "Загрузить изображение"}
        </span>
        <input
          type="file"
          aria-label={
            target === "favicon"
              ? "Изображение favicon"
              : "Изображение логотипа"
          }
          disabled={blocked || uploading || !!uploadDisabledReason}
          accept="image/png,image/jpeg,image/webp"
          onChange={(e) => {
            const file = e.currentTarget.files?.[0];
            e.currentTarget.value = "";
            if (file) onUpload(target, file);
          }}
        />
      </label>
      {currentName && (
        <span className="base-brand-filename" title={currentName}>
          {currentName}
        </span>
      )}
      {currentName && (
        <Button
          type="button"
          size="icon"
          variant="ghost"
          disabled={blocked || uploading || !!uploadDisabledReason}
          title="Удалить изображение из формы"
          aria-label={
            target === "favicon" ? "Удалить favicon" : "Удалить изображение"
          }
          onClick={() =>
            target === "favicon"
              ? updateDesign({ favicon: { ...design.favicon, image: null } })
              : updateMark({ image: null })
          }
        >
          <X size={16} />
        </Button>
      )}
    </div>
  );
  return (
    <section className="base-brand-fields" aria-label="Параметры брендинга">
      <BrandingProfilePicker
        value={value}
        onChange={onChange}
        disabled={disabled}
      />
      <Block title="Название" icon={<Type size={18} />}>
        <Field label="Название платформы">
          <Input
            value={value.product_name}
            disabled={disabled}
            required
            onChange={(e) =>
              onChange({ ...value, product_name: e.target.value })
            }
          />
        </Field>
        <div className="base-brand-two">
          <Field label="Короткое название">
            <Input
              value={value.product_short_name}
              disabled={disabled}
              required
              onChange={(e) =>
                onChange({ ...value, product_short_name: e.target.value })
              }
            />
          </Field>
          <Field label="Начальная тема">
            <Select
              value={String(design.initial_theme)}
              disabled={disabled}
              onValueChange={(nextValue) =>
                updateDesign({ initial_theme: nextValue as BrandTheme })
              }
              options={[
                ...(themes.map((t) => ({
                  value: String(t),
                  label: String(themeNames[t]),
                })) ?? []),
              ]}
            />
          </Field>
        </div>
        <p className="base-brand-hint">
          Admin Panel · {value.product_name || "Платформа"}
        </p>
      </Block>
      <Block title="Типографика и плотность" icon={<Type size={18} />}>
        <div className="base-brand-two">
          {(
            [
              ["font_preset", "Шрифт"],
              ["type_scale", "Размер текста"],
              ["density", "Плотность"],
            ] as const
          ).map(([key, label]) => (
            <FormField key={key} id={`${id}-${key}`} label={label}>
              {(attrs) => (
                <Select
                  {...attrs}
                  disabled={disabled}
                  value={design[key]}
                  onValueChange={(next) =>
                    updateDesign({ [key]: next } as Partial<typeof design>)
                  }
                  options={brandingPresets[key].map((value) => ({
                    value,
                    label:
                      (
                        {
                          system: "Системный",
                          inter: "Inter",
                          "noto-sans": "Noto Sans",
                          standard: "Стандартный",
                          large: "Крупный",
                          compact: "Компактная",
                          comfortable: "Свободная",
                        } as Record<string, string>
                      )[value] ?? value,
                  }))}
                />
              )}
            </FormField>
          ))}
        </div>
      </Block>
      <Block title="Логотип" icon={<Shapes size={18} />}>
        {uploadDisabledReason && (
          <p className="base-brand-hint">{uploadDisabledReason}</p>
        )}
        <div
          className="base-brand-segments"
          role="group"
          aria-label="Вариант знака"
        >
          {(Object.keys(variantNames) as MarkVariant[]).map((v) => (
            <Button
              key={v}
              type="button"
              variant={v === variant ? "secondary" : "ghost"}
              aria-pressed={v === variant}
              onClick={() => onVariantChange(v)}
            >
              {variantNames[v]}
            </Button>
          ))}
        </div>
        {variant !== "common" && (
          <Checkbox
            label="Отдельный знак для этой темы"
            disabled={disabled}
            checked={!!ownMark}
            onCheckedChange={(checked) =>
              updateDesign({
                marks: {
                  ...design.marks,
                  [variant]: checked === true ? structuredClone(mark) : null,
                },
              })
            }
          />
        )}
        {!ownMark && (
          <p className="base-brand-hint">
            <Info size={14} />
            Наследуется общий знак
          </p>
        )}
        <div className="base-brand-mark-row">
          <BrandingMark
            document={value}
            assetUrls={assetUrls}
            theme={colorTheme}
            mark={mark}
            size={56}
          />
          <div
            className="base-brand-segments"
            role="group"
            aria-label="Тип логотипа"
          >
            {(
              [
                ["letters", "Буквы", Type],
                ["icon", "Иконка", Shapes],
                ["image", "Изображение", Image],
              ] as const
            ).map(([kind, name, Icon]) => (
              <Button
                key={kind}
                type="button"
                disabled={markDisabled}
                variant={mark.kind === kind ? "secondary" : "ghost"}
                aria-pressed={mark.kind === kind}
                onClick={() => updateMark({ kind })}
              >
                <Icon size={16} />
                {name}
              </Button>
            ))}
          </div>
        </div>
        {mark.kind === "letters" && (
          <div className="base-brand-two">
            <Field label="Количество символов">
              <Select
                value={String(mark.count)}
                disabled={markDisabled}
                onValueChange={(nextValue) => {
                  const count = Number(nextValue) as 1 | 2 | 4;
                  const lettersByCount = {
                    ...mark.lettersByCount,
                    [mark.count]: mark.letters,
                  };
                  updateMark({
                    count,
                    lettersByCount,
                    letters:
                      lettersByCount[count] ??
                      { 1: "P", 2: "PD", 4: "PDLC" }[count],
                  });
                }}
                options={[
                  ...([1, 2, 4].map((c) => ({
                    value: String(c),
                    label: String(c),
                  })) ?? []),
                ]}
              />
            </Field>
            <Field label="Символы знака">
              <Input
                value={mark.letters}
                disabled={markDisabled}
                spellCheck={false}
                onChange={(e) => updateMark({ letters: e.target.value })}
              />
            </Field>
          </div>
        )}
        {mark.kind === "icon" && (
          <>
            <div className="base-brand-search">
              <Search size={16} />
              <Input
                aria-label="Поиск иконки"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Название иконки"
              />
            </div>
            <div
              className="base-brand-icons"
              role="group"
              aria-label="Иконки платформы"
            >
              {brandIcons
                .filter((i) =>
                  `${i.name} ${i.id}`
                    .toLocaleLowerCase()
                    .includes(query.toLocaleLowerCase()),
                )
                .map(({ id, name, Icon }) => (
                  <Button
                    key={id}
                    type="button"
                    variant={mark.icon === id ? "secondary" : "ghost"}
                    size="icon"
                    aria-pressed={mark.icon === id}
                    title={name}
                    aria-label={name}
                    disabled={markDisabled}
                    onClick={() => updateMark({ icon: id })}
                  >
                    <Icon size={21} />
                  </Button>
                ))}
            </div>
            {!brandIcons.some((i) =>
              `${i.name} ${i.id}`
                .toLocaleLowerCase()
                .includes(query.toLocaleLowerCase()),
            ) && <p className="base-brand-hint">Иконки не найдены</p>}
          </>
        )}
        {mark.kind === "image" && (
          <>
            {uploadField(variant, mark.image?.name, markDisabled)}
            <Field label="Размещение изображения">
              <Select
                value={String(mark.fit)}
                disabled={markDisabled}
                onValueChange={(nextValue) =>
                  updateMark({ fit: nextValue as BrandMark["fit"] })
                }
                options={[
                  ...[
                    {
                      value: String("contain"),
                      label: String("Вписать целиком"),
                    },
                  ],
                  ...[
                    {
                      value: String("cover"),
                      label: String("Заполнить квадрат"),
                    },
                  ],
                ]}
              />
            </Field>
            <p className="base-brand-hint">
              PNG, JPEG или WebP · до 5 MiB · до 4096 px
            </p>
          </>
        )}
        <div className="base-brand-two">
          {mark.kind !== "image" && (
            <ColorField
              label="Цвет знака"
              value={mark.foreground}
              disabled={markDisabled}
              onChange={(foreground) => updateMark({ foreground })}
            />
          )}
          <ColorField
            label="Фон знака"
            value={mark.background}
            disabled={markDisabled}
            onChange={(background) => updateMark({ background })}
          />
        </div>
        <Field label="Форма знака">
          <Select
            disabled={markDisabled}
            value={String(mark.shape)}
            onValueChange={(nextValue) =>
              updateMark({ shape: nextValue as BrandMark["shape"] })
            }
            options={[
              ...[{ value: String("square"), label: String("Квадрат") }],
              ...[{ value: String("rounded"), label: String("Скруглённый") }],
              ...[{ value: String("circle"), label: String("Круг") }],
            ]}
          />
        </Field>
        <div className="base-brand-favicon">
          <BrandingMark
            document={value}
            theme={colorTheme}
            size={24}
            compact
            assetUrls={assetUrls}
          />
          <Field label="Favicon">
            <Select
              disabled={disabled}
              value={String(design.favicon.mode)}
              onValueChange={(nextValue) =>
                updateDesign({
                  favicon: {
                    ...design.favicon,
                    mode: nextValue as BrandDesignDocument["design"]["favicon"]["mode"],
                  },
                })
              }
              options={[
                ...[{ value: String("logo"), label: String("Как логотип") }],
                ...[{ value: String("auto"), label: String("Компактный") }],
                ...[
                  {
                    value: String("image"),
                    label: String("Отдельное изображение"),
                  },
                ],
              ]}
            />
          </Field>
        </div>
        {design.favicon.mode === "image" &&
          uploadField("favicon", design.favicon.image?.name, disabled)}
        {uploading && (
          <p role="status" className="base-brand-hint">
            Проверка изображения…
          </p>
        )}
        {uploadError && (
          <p role="alert" className="base-brand-error">
            {uploadError}
          </p>
        )}
      </Block>
      <Block title="Цвета" icon={<Palette size={18} />}>
        <div
          className="base-brand-segments"
          role="group"
          aria-label="Тема палитры"
        >
          {themes.map((t) => (
            <Button
              key={t}
              type="button"
              variant={colorTheme === t ? "secondary" : "ghost"}
              aria-pressed={colorTheme === t}
              onClick={() => onColorThemeChange(t)}
            >
              {themeNames[t]}
            </Button>
          ))}
        </div>
        <div
          className="base-brand-palettes"
          role="group"
          aria-label="Готовые палитры"
        >
          {Object.entries(palettes).map(([name, colors]) => (
            <Button
              variant="outline"
              key={name}
              type="button"
              title={`${name}: все три темы`}
              aria-label={`Палитра ${name}`}
              disabled={disabled}
              onClick={() => updateDesign({ colors: structuredClone(colors) })}
            >
              <span style={{ background: colors[colorTheme].primary }} />
              <span style={{ background: colors[colorTheme].accent }} />
              <small>{name}</small>
            </Button>
          ))}
        </div>
        <div className="base-brand-two">
          {(["primary", "accent"] as const).map((key) => (
            <ColorField
              key={key}
              label={
                key === "primary" ? "Цвет действий" : "Дополнительный акцент"
              }
              value={design.colors[colorTheme][key]}
              disabled={disabled}
              onChange={(color) =>
                updateDesign({
                  colors: {
                    ...design.colors,
                    [colorTheme]: {
                      ...design.colors[colorTheme],
                      [key]: color,
                    },
                  },
                })
              }
            />
          ))}
        </div>
      </Block>
      <Block title="Скругления" icon={<Shapes size={18} />}>
        <div
          className="base-brand-segments"
          role="group"
          aria-label="Пресеты скруглений"
        >
          {Object.entries(radiusPresets).map(([name, radii]) => (
            <Button
              key={name}
              type="button"
              variant={
                JSON.stringify(design.radii) === JSON.stringify(radii)
                  ? "secondary"
                  : "ghost"
              }
              aria-pressed={
                JSON.stringify(design.radii) === JSON.stringify(radii)
              }
              disabled={disabled}
              onClick={() => updateDesign({ radii: { ...radii } })}
            >
              {name}
            </Button>
          ))}
        </div>
        {(Object.keys(radiusLimits) as RadiusKey[]).map((key) => (
          <div className="base-brand-radius" key={key}>
            <label htmlFor={`${id}-${key}`}>{radiusNames[key]}</label>
            <input
              type="range"
              aria-label={`${radiusNames[key]}: шкала`}
              min={0}
              max={radiusLimits[key]}
              step={1}
              value={Number.isFinite(design.radii[key]) ? design.radii[key] : 0}
              disabled={disabled}
              onChange={(e) =>
                updateDesign({
                  radii: { ...design.radii, [key]: Number(e.target.value) },
                })
              }
            />
            <Input
              id={`${id}-${key}`}
              type="number"
              min={0}
              max={radiusLimits[key]}
              step={1}
              value={
                Number.isFinite(design.radii[key]) ? design.radii[key] : ""
              }
              disabled={disabled}
              onChange={(e) =>
                updateDesign({
                  radii: {
                    ...design.radii,
                    [key]: e.target.value === "" ? NaN : Number(e.target.value),
                  },
                })
              }
            />
            <span>px</span>
          </div>
        ))}
      </Block>
      <Block title="Совместимые настройки" icon={<Link size={18} />}>
        <p className="base-brand-hint">
          URL и общие цвета сохраняются для прежних клиентов. Для новых тем
          используйте разделы выше.
        </p>
        {(
          [
            ["logo_url", "URL логотипа"],
            ["favicon_url", "URL иконки вкладки"],
          ] as const
        ).map(([key, label]) => (
          <Field key={key} label={label}>
            <Input
              type="url"
              disabled={disabled}
              value={value[key] ?? ""}
              onChange={(event) => updateLegacyUrl(key, event.target.value)}
            />
          </Field>
        ))}
        <ColorField
          label="Основной цвет"
          value={value.primary_color}
          disabled={disabled}
          onChange={(primary_color) => onChange({ ...value, primary_color })}
        />
        <ColorField
          label="Акцентный цвет"
          value={value.accent_color}
          disabled={disabled}
          onChange={(accent_color) => onChange({ ...value, accent_color })}
        />
        <Field label="Оттенок поверхности">
          <Input
            disabled={disabled}
            value={value.surface_color ?? ""}
            onChange={(event) =>
              onChange({ ...value, surface_color: event.target.value || null })
            }
          />
        </Field>
      </Block>
      <Block title="Ссылки" icon={<Link size={18} />}>
        <Field label="URL поддержки">
          <Input
            type="url"
            value={value.support_url ?? ""}
            disabled={disabled}
            placeholder="https://"
            onChange={(e) =>
              onChange({ ...value, support_url: e.target.value || null })
            }
          />
        </Field>
        <Field label="Документация">
          <Input
            type="url"
            value={design.documentation_url}
            disabled={disabled}
            placeholder="https://"
            onChange={(e) =>
              updateDesign({ documentation_url: e.target.value })
            }
          />
        </Field>
      </Block>
    </section>
  );
}
