import { useState } from "react";
import {
  Activity,
  Box,
  CircleDot,
  Compass,
  Cpu,
  FlaskConical,
  Globe,
  Hexagon,
  Layers,
  Leaf,
  Network,
  Rocket,
  Shield,
  Sparkles,
  Terminal,
  Workflow,
} from "lucide-react";
import {
  effectiveMark,
  graphemes,
  contrast,
  validMonogram,
  type BrandDesignDocument,
  type BrandMark,
  type BrandTheme,
} from "./model";

export const brandIcons = [
  { id: "layers", name: "Слои", Icon: Layers },
  { id: "box", name: "Куб", Icon: Box },
  { id: "compass", name: "Компас", Icon: Compass },
  { id: "globe", name: "Глобус", Icon: Globe },
  { id: "hexagon", name: "Шестиугольник", Icon: Hexagon },
  { id: "network", name: "Сеть", Icon: Network },
  { id: "rocket", name: "Ракета", Icon: Rocket },
  { id: "shield", name: "Щит", Icon: Shield },
  { id: "terminal", name: "Терминал", Icon: Terminal },
  { id: "workflow", name: "Процессы", Icon: Workflow },
  { id: "cpu", name: "Процессор", Icon: Cpu },
  { id: "activity", name: "Пульс", Icon: Activity },
  { id: "leaf", name: "Лист", Icon: Leaf },
  { id: "sparkles", name: "Искры", Icon: Sparkles },
  { id: "circle-dot", name: "Центр", Icon: CircleDot },
  { id: "flask", name: "Колба", Icon: FlaskConical },
];
export function markLetters(document: BrandDesignDocument, mark: BrandMark) {
  return mark.kind === "letters" && validMonogram(mark)
    ? graphemes(mark.letters)
    : graphemes(
        (document.product_short_name || "Base").toUpperCase().padEnd(4, "B"),
      );
}
export function markCount(mark: BrandMark, compact: boolean, failed: boolean) {
  return failed || (compact && mark.count === 4) ? 1 : mark.count;
}
export function markFontSize(count: number, size: number) {
  return size * (count === 4 ? 0.36 : count === 2 ? 0.38 : 0.56);
}
export function fourLetterOffset(index: number, size: number) {
  return {
    x: size * 0.04 * (index % 2 === 0 ? 1 : -1),
    y: size * 0.04 * (index < 2 ? 1 : -1),
  };
}
export function BrandingMark({
  document,
  theme,
  size = 32,
  compact = false,
  mark: override,
  assetUrls,
}: {
  document: BrandDesignDocument;
  theme: BrandTheme;
  size?: number;
  compact?: boolean;
  mark?: BrandMark;
  assetUrls?: ReadonlyMap<string, string>;
}) {
  const mark = override ?? effectiveMark(document, theme);
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  const asset =
    compact && document.design.favicon.mode === "image"
      ? document.design.favicon.image
      : mark.kind === "image"
        ? mark.image
        : null;
  const src =
    asset && assetUrls?.has(asset.id)
      ? assetUrls.get(asset.id)
      : compact && document.design.favicon.mode === "image"
        ? document.design.favicon.image?.url
        : mark.kind === "image"
          ? mark.image?.url
          : null;
  const failed = !!src && failedUrl === src;
  const safe = contrast(mark.foreground, mark.background) >= 4.5;
  const letters = markLetters(document, mark);
  const count = markCount(
    mark,
    compact && document.design.favicon.mode !== "logo",
    failed || (mark.kind === "image" && !src),
  );
  const Icon = brandIcons.find((icon) => icon.id === mark.icon)?.Icon ?? Layers;
  return (
    <span
      className="base-brand-mark"
      role="img"
      aria-label={compact ? "Favicon платформы" : "Знак платформы"}
      style={{
        width: size,
        height: size,
        display: "inline-flex",
        flexShrink: 0,
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
        fontWeight: 700,
        lineHeight: 1,
        letterSpacing: 0,
        borderRadius:
          mark.shape === "circle"
            ? "50%"
            : mark.shape === "square"
              ? 0
              : document.design.radii.mark,
        background: safe ? mark.background : "#2563eb",
        color: safe ? mark.foreground : "#ffffff",
        fontSize: markFontSize(count, size),
      }}
    >
      {src && !failed ? (
        <img
          alt=""
          src={src}
          style={{ objectFit: mark.fit, width: "100%", height: "100%" }}
          onError={() => setFailedUrl(src)}
        />
      ) : mark.kind === "icon" &&
        !failed &&
        !(compact && document.design.favicon.mode === "image") ? (
        <Icon size={size * 0.6} aria-hidden="true" />
      ) : (
        <span
          className={count === 4 ? "base-brand-letters-four" : ""}
          style={
            count === 4
              ? {
                  display: "grid",
                  width: "100%",
                  height: "100%",
                  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
                  gridTemplateRows: "repeat(2, minmax(0, 1fr))",
                  gap: 0,
                  textAlign: "center",
                }
              : undefined
          }
        >
          {count === 4
            ? letters.slice(0, count).map((letter, index) => (
                <span
                  key={index}
                  style={{
                    display: "flex",
                    minWidth: 0,
                    minHeight: 0,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <span
                    style={{
                      display: "inline-block",
                      transform: `translate(${fourLetterOffset(index, size).x}px, ${fourLetterOffset(index, size).y}px)`,
                    }}
                  >
                    {letter}
                  </span>
                </span>
              ))
            : letters.slice(0, count).join("")}
        </span>
      )}
    </span>
  );
}
