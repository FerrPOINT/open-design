import { platformTitle } from "../lib/platform-title.js";
import { resolveBrandingTokens } from "../lib/branding-runtime.js";
import { useEffect } from "react";
import { useBrandingPresentation } from "./context";
export {
  BrandingPresentationProvider,
  useBrandingPresentation,
} from "./context";
import { brandingFavicon } from "../lib/branding-marks.js";
export { brandingFavicon } from "../lib/branding-marks.js";
import type { BrandDesignDocument, BrandTheme } from "./model";

export function brandingTokens(
  document: BrandDesignDocument,
  theme: BrandTheme,
) {
  return resolveBrandingTokens(document, theme);
}
export function BrandingDocumentStyle() {
  const presentation = useBrandingPresentation();
  useEffect(() => {
    if (!presentation) return;
    const root = document.documentElement;
    const tokens = brandingTokens(presentation.document, presentation.theme);
    const old = Object.keys(tokens).map(
      (key) => [key, root.style.getPropertyValue(key)] as const,
    );
    const scope = root.getAttribute("data-brand-scope");
    root.setAttribute("data-brand-scope", "");
    for (const [key, value] of Object.entries(tokens))
      root.style.setProperty(key, value);
    return () => {
      for (const [key, value] of old) {
        if (value) root.style.setProperty(key, value);
        else root.style.removeProperty(key);
      }
      if (scope === null) root.removeAttribute("data-brand-scope");
      else root.setAttribute("data-brand-scope", scope);
    };
  }, [presentation]);
  return null;
}

export function BrandingDocumentHead({
  serviceName,
  manageFavicon = true,
}: {
  serviceName: string;
  manageFavicon?: boolean;
}) {
  const presentation = useBrandingPresentation();
  useEffect(() => {
    if (!presentation) return;
    const previousTitle = document.title;
    document.title = platformTitle(serviceName,presentation.document);
    if (!manageFavicon)
      return () => {
        document.title = previousTitle;
      };
    const existing =
      document.querySelector<HTMLLinkElement>('link[rel="icon"]');
    const link = existing ?? document.createElement("link");
    const oldHref = link.getAttribute("href"),
      oldType = link.getAttribute("type");
    link.rel = "icon";
    let active = true;
    link.type = "image/png";
    void brandingFavicon(presentation.document, presentation.theme)
      .then((url) => {
        if (active && url) link.href = url;
      })
      .catch(() => {
        /* Keep last favicon if canvas is unavailable. */
      });
    if (!existing) document.head.appendChild(link);
    return () => {
      active = false;
      document.title = previousTitle;
      if (!existing) link.remove();
      else {
        if (oldHref === null) link.removeAttribute("href");
        else link.setAttribute("href", oldHref);
        if (oldType === null) link.removeAttribute("type");
        else link.setAttribute("type", oldType);
      }
    };
  }, [presentation, serviceName, manageFavicon]);
  return null;
}
