import { BrandingPreview as ControlsPreview } from "../ui/branding-editor";
import { BrandingPresentationProvider } from "./context";
import type { BrandDesignDocument, BrandTheme } from "./model";
export function BrandingPreview({
  document,
  theme,
  assetUrls,
}: {
  document: BrandDesignDocument;
  theme: BrandTheme;
  assetUrls?: ReadonlyMap<string, string>;
}) {
  return (
    <BrandingPresentationProvider document={document} theme={theme}>
      <ControlsPreview value={document} theme={theme} assetUrls={assetUrls} />
    </BrandingPresentationProvider>
  );
}
