import { useEffect, useRef, type ReactNode } from "react";

/** In-flow page navigation and a single bottom-docked action set. */
export function BrandingWorkspaceLayout({
  navigation,
  actions,
  status,
  children,
}: {
  navigation: ReactNode;
  actions?: ReactNode;
  status?: ReactNode;
  children: ReactNode;
}) {
  const root = useRef<HTMLDivElement>(null);
  const toolbar = useRef<HTMLDivElement>(null);
  const dock = useRef<HTMLDivElement>(null);
  const content = useRef<HTMLDivElement>(null);
  const hasActions = Boolean(actions);

  useEffect(() => {
    const element = root.current;
    if (!element) return;
    let frame = 0;
    const documentStyle = document.documentElement.style;
    const previousOffset = documentStyle.getPropertyValue(
      "--base-fixed-actions-offset",
    );
    const measurePreview = () => {
      const preview = element.querySelector<HTMLElement>(
        ".base-brand-editor-aside",
      );
      if (!preview) return;
      const header =
        parseFloat(
          getComputedStyle(element).getPropertyValue("--shell-header-height"),
        ) || 0;
      const viewport = window.visualViewport;
      const viewportBottom = viewport
        ? viewport.height + viewport.offsetTop
        : window.innerHeight;
      const actions = dock.current;
      const bottom =
        actions && getComputedStyle(actions).position === "fixed"
          ? Math.min(viewportBottom, actions.getBoundingClientRect().top)
          : viewportBottom;
      const top = Math.max(header + 16, preview.getBoundingClientRect().top);
      element.style.setProperty(
        "--base-preview-max-height",
        `${Math.max(0, bottom - top - 16)}px`,
      );
    };
    const measure = () => {
      element.style.setProperty(
        "--base-toolbar-height",
        `${toolbar.current?.getBoundingClientRect().height ?? 0}px`,
      );
      const height = dock.current?.getBoundingClientRect().height ?? 0;
      element.style.setProperty("--base-actions-height", `${height}px`);
      const bounds = (
        element.closest("main") ?? element
      ).getBoundingClientRect();
      element.style.setProperty(
        "--base-actions-left",
        `${Math.max(0, bounds.left)}px`,
      );
      element.style.setProperty(
        "--base-actions-right",
        `${Math.max(0, innerWidth - bounds.right)}px`,
      );
      const viewport = window.visualViewport;
      const inset = viewport
        ? Math.max(0, window.innerHeight - viewport.height - viewport.offsetTop)
        : 0;
      element.style.setProperty("--base-keyboard-inset", `${inset}px`);
      if (hasActions)
        documentStyle.setProperty(
          "--base-fixed-actions-offset",
          `${height + inset}px`,
        );
      measurePreview();
    };
    const reveal = () => {
      const target = document.activeElement;
      if (
        !(target instanceof HTMLElement) ||
        !content.current?.contains(target)
      )
        return;
      const rect = target.getBoundingClientRect();
      const top =
        parseFloat(
          getComputedStyle(element).getPropertyValue("--shell-header-height"),
        ) || 0;
      const actionRect = dock.current?.getBoundingClientRect();
      const bottom =
        actionRect && getComputedStyle(dock.current!).position === "fixed"
          ? actionRect.top
          : window.innerHeight;
      if (rect.top < top + 8 || rect.bottom > bottom - 8)
        target.scrollIntoView?.({ block: "center", behavior: "instant" });
    };
    const schedule = () => {
      measure();
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(reveal);
    };
    const observer =
      typeof ResizeObserver === "undefined"
        ? null
        : new ResizeObserver(schedule);
    if (toolbar.current) observer?.observe(toolbar.current);
    if (dock.current) observer?.observe(dock.current);
    const body = content.current;
    const viewport = window.visualViewport;
    body?.addEventListener("focusin", schedule);
    window.addEventListener("resize", schedule);
    window.addEventListener("scroll", measurePreview, { passive: true });
    viewport?.addEventListener("resize", schedule);
    viewport?.addEventListener("scroll", schedule);
    measure();
    return () => {
      observer?.disconnect();
      cancelAnimationFrame(frame);
      body?.removeEventListener("focusin", schedule);
      window.removeEventListener("resize", schedule);
      window.removeEventListener("scroll", measurePreview);
      viewport?.removeEventListener("resize", schedule);
      viewport?.removeEventListener("scroll", schedule);
      if (hasActions) {
        if (previousOffset)
          documentStyle.setProperty(
            "--base-fixed-actions-offset",
            previousOffset,
          );
        else documentStyle.removeProperty("--base-fixed-actions-offset");
      }
    };
  }, [hasActions]);

  return (
    <div
      ref={root}
      className={`base-sticky-page${actions ? " base-sticky-page-with-actions" : ""}`}
    >
      <div ref={toolbar} className="base-page-toolbar">
        <div className="base-page-navigation">{navigation}</div>
      </div>
      <div ref={content} className="base-sticky-page-content">
        {children}
      </div>
      {actions && (
        <div
          ref={dock}
          className="base-page-dock"
          role="region"
          aria-label="Действия редактора"
        >
          {status && (
            <div className="base-page-action-status" role="status">
              {status}
            </div>
          )}
          <div className="base-page-action-buttons">{actions}</div>
        </div>
      )}
    </div>
  );
}
