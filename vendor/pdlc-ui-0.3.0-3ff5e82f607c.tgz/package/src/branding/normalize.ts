import {
  defaultDesign,
  resolveBrandingTokens,
  normalizeBranding as normalizeRuntimeBranding,
} from "../lib/branding-runtime.js";
import {
  createBrandDocument,
  graphemes,
  readableText,
  validMonogram,
  validateBrand,
  type BrandDesignDocument,
  type BrandMark,
} from "./model";

export type BrandingWireDocument = Omit<BrandDesignDocument, "design"> & {
  design?: BrandDesignDocument["design"] | null;
};

function record(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
/** Reject unrecognized versions before applying tokens or replacing the valid cache. */
export function normalizeBranding(
  payload: unknown,
): BrandDesignDocument | null {
  const presetDocument = normalizeRuntimeBranding(payload);
  if (!presetDocument) return null;
  const value = presetDocument;
  const normalized = createBrandDocument();
  Object.assign(normalized, {
    product_name: value.product_name,
    product_short_name: value.product_short_name,
    primary_color: value.primary_color,
    accent_color: value.accent_color,
    logo_url: value.logo_url || null,
    favicon_url: value.favicon_url || null,
    support_url: value.support_url || null,
    surface_color: value.surface_color ?? null,
  });
  if (!record(payload) || payload.design == null) {
    const common = normalized.design.marks.common;
    const letters =
      graphemes(value.product_short_name.toUpperCase())
        .filter((letter) =>
          validMonogram({ ...common, count: 1, letters: letter }),
        )
        .slice(0, 2)
        .join("") || "B";
    common.letters = letters;
    common.count = graphemes(letters).length === 1 ? 1 : 2;
    common.background = value.primary_color;
    common.foreground = readableText(value.primary_color);
    if (value.logo_url) {
      common.kind = "image";
      common.image = {
        id: "legacy-logo",
        url: String(value.logo_url),
        name: "Logo",
      };
    }
    if (value.favicon_url)
      normalized.design.favicon = {
        mode: "image",
        image: {
          id: "legacy-favicon",
          url: String(value.favicon_url),
          name: "Favicon",
        },
      };
    // Materialize the existing resolved appearance only for the editing snapshot.
    // Historical wire documents and hashes are never rewritten.
    for (const theme of ["dark", "gray", "light"] as const) {
      const tokens = resolveBrandingTokens(value, theme);
      normalized.design.colors[theme] = {
        primary: tokens["--color-accent"],
        accent: tokens["--color-highlight"],
      };
    }
    const tokens = resolveBrandingTokens(value, "dark");
    normalized.design.radii = {
      control: parseInt(tokens["--base-radius"]),
      menu: parseInt(tokens["--base-radius-menu"]),
      dialog: parseInt(tokens["--base-radius-dialog"]),
      card: parseInt(tokens["--base-radius-card"]),
      mark: parseInt(tokens["--radius-sm"]),
    };
    normalized.design = {
      ...normalized.design,
      font_preset: value.design!.font_preset,
      type_scale: value.design!.type_scale,
      density: value.design!.density,
      radius: value.design!.radius,
    };
    return normalized;
  }
  if (record(value.design) && !Object.hasOwn(value.design, "marks")) {
    const flat = { ...value };
    delete flat.design;
    const legacy = normalizeBranding(flat);
    if (!legacy) return null;
    const tokens = resolveBrandingTokens(value, "dark");
    return {
      ...legacy,
      design: {
        ...legacy.design,
        radii: {
          control: parseInt(tokens["--base-radius"]),
          menu: parseInt(tokens["--base-radius-menu"]),
          dialog: parseInt(tokens["--base-radius-dialog"]),
          card: parseInt(tokens["--base-radius-card"]),
          mark: parseInt(tokens["--radius-sm"]),
        },
        font_preset: presetDocument.design!.font_preset,
        type_scale: presetDocument.design!.type_scale,
        density: presetDocument.design!.density,
        radius: presetDocument.design!.radius,
      },
    };
  }
  const design = value.design;
  // Whitelist persistent fields; editor-only lettersByCount is never sent to runtime.
  const cleanMark = (v: BrandMark | null) =>
    v && {
      kind: v.kind,
      count: v.count,
      letters: v.letters,
      icon: v.icon,
      foreground: v.foreground,
      background: v.background,
      shape: v.shape,
      fit: v.fit,
      image: v.image && {
        id: v.image.id,
        url: v.image.url,
        name: v.image.name,
      },
    };
  const typed = design as unknown as BrandDesignDocument["design"];
  for (const image of [
    typed.marks.common.image,
    typed.marks.light?.image,
    typed.marks.dark?.image,
    typed.favicon.image,
  ]) {
    if (image?.id === "legacy-logo" && image.url !== value.logo_url)
      return null;
    if (image?.id === "legacy-favicon" && image.url !== value.favicon_url)
      return null;
  }
  normalized.design = {
    ...defaultDesign,
    font_preset:
      presetDocument.design?.font_preset ?? defaultDesign.font_preset,
    type_scale: presetDocument.design?.type_scale ?? defaultDesign.type_scale,
    density: presetDocument.design?.density ?? defaultDesign.density,
    radius: presetDocument.design?.radius ?? defaultDesign.radius,
    version: 1,
    marks: {
      common: cleanMark(typed.marks.common)!,
      light: cleanMark(typed.marks.light),
      dark: cleanMark(typed.marks.dark),
    },
    favicon: {
      mode: typed.favicon.mode,
      image: typed.favicon.image && {
        id: typed.favicon.image.id,
        url: typed.favicon.image.url,
        name: typed.favicon.image.name,
      },
    },
    colors: Object.fromEntries(
      (["dark", "gray", "light"] as const).map((theme) => {
        const colors = typed.colors[theme];
        return [theme, { primary: colors.primary, accent: colors.accent }];
      }),
    ) as typeof typed.colors,
    radii: {
      control: typed.radii.control,
      menu: typed.radii.menu,
      dialog: typed.radii.dialog,
      card: typed.radii.card,
      mark: typed.radii.mark,
    },
    documentation_url: typed.documentation_url,
    initial_theme: typed.initial_theme,
  };
  return validateBrand(normalized).length ? null : normalized;
}

export function brandingWireSnapshot(
  value: BrandDesignDocument,
): BrandingWireDocument {
  const clean = structuredClone(value);
  for (const mark of Object.values(clean.design.marks))
    if (mark) delete mark.lettersByCount;
  return clean;
}
