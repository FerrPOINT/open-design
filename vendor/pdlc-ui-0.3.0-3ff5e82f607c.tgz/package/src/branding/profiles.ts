import {
  createBrandDocument,
  flattenDocument,
  palettes,
  radiusPresets,
  type BrandDesignDocument,
} from "./model";

export type ProfileGroup = "colors" | "radii" | "mark";
export const profileGroups: ProfileGroup[] = ["colors", "radii", "mark"];
export const profileGroupNames = {
  colors: "Цвета",
  radii: "Скругления",
  mark: "Оформление знака",
};
export const brandProfiles = [
  {
    id: "strict",
    name: "Строгий",
    radii: radiusPresets.Строго,
    shape: "square",
  },
  { id: "base", name: "Base", radii: radiusPresets.Base, shape: "rounded" },
  { id: "soft", name: "Мягкий", radii: radiusPresets.Мягко, shape: "rounded" },
] as const;
export type ProfileId = (typeof brandProfiles)[number]["id"];

export function applyBrandProfile(
  document: BrandDesignDocument,
  id: ProfileId,
  groups: readonly ProfileGroup[],
) {
  const profile = brandProfiles.find((p) => p.id === id)!;
  const next = structuredClone(document);
  if (groups.includes("colors"))
    next.design.colors = structuredClone(palettes.Синий);
  if (groups.includes("radii")) next.design.radii = { ...profile.radii };
  if (groups.includes("mark")) {
    const defaults = createBrandDocument().design.marks.common;
    for (const mark of Object.values(next.design.marks))
      if (mark) {
        mark.shape = profile.shape;
        mark.foreground = defaults.foreground;
        mark.background = defaults.background;
      }
  }
  return next;
}
export function profileDifferences(
  before: BrandDesignDocument,
  after: BrandDesignDocument,
) {
  const left = flattenDocument(before),
    right = flattenDocument(after);
  return Object.keys(right)
    .filter((key) => left[key] !== right[key])
    .map((key) => ({ key, before: left[key], after: right[key] }));
}
export function matchingBrandProfile(document: BrandDesignDocument) {
  return (
    brandProfiles.find(
      (p) =>
        !profileDifferences(
          document,
          applyBrandProfile(document, p.id, profileGroups),
        ).length,
    )?.name ?? "Пользовательский"
  );
}
