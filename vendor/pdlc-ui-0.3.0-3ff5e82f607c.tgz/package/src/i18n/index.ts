import en from './locales/en.json'
import ru from './locales/ru.json'

export const pdlcLocales = { en, ru } as const
export type PdlcLocale = keyof typeof pdlcLocales
/** @deprecated Use pdlcLocales. Both names reference the same locale data. */
export const sdlcLocales = pdlcLocales
/** @deprecated Use PdlcLocale. */
export type SdlcLocale = PdlcLocale
