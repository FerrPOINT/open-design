import { BrandingEditor as ExpandedBrandingEditor } from "../branding/editor";
import {
  createBrandDocument,
  type BrandDesignDocument,
  type MarkVariant,
} from "../branding/model";
import { BrandingMark } from "../branding/mark";
import {
  useMemo,
  useId,
  useState,
  useSyncExternalStore,
  type ReactNode,
} from "react";
import type { PlatformBranding } from "../lib/platform-branding";
import { Input } from "./input";
import { FormField } from "./page-patterns";
import { Fieldset } from "./fieldset";
import { defaultBranding } from "../lib/platform-branding";
import { BrandingScope } from "../lib/branding-scope";
import { normalizeBranding } from "../lib/branding-runtime.js";
import type { Theme } from "../lib/theme-types";
import { Button } from "./button";
import { Badge } from "./badge";
import { Disclosure } from "./disclosure";
import { ResourceList, ResourceListRow } from "./resource-list";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Textarea } from "./textarea";
import { Select } from "./select";
import { Checkbox, RadioGroup, Switch } from "./check-controls";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "./table";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "./dialog";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "./dropdown-menu";
import { PlatformHeader } from "./platform-header";
import { SidebarItem } from "./sidebar-item";
import { Toaster, toast } from "./notifications";

export interface BrandingEditorProps {
  /** Controlled presentation document. Persistence and authorization belong to the caller. */
  value: PlatformBranding;
  onChange: (value: PlatformBranding) => void;
  /** Locks every field while saving, viewing without permission, or retrying a saved revision. */
  disabled?: boolean;
}

function subscribeTheme(notify: () => void) {
  const observer = new MutationObserver(notify);
  observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["data-theme"],
  });
  return () => observer.disconnect();
}
function currentTheme(): Theme {
  const value = document.documentElement.dataset.theme;
  return value === "light" || value === "gray" ? value : "dark";
}

/** Actual Base controls inside a local presentation scope; no runtime publication or preference writes. */
export function BrandingPreview({
  value,
  theme: selectedTheme,
  assetUrls,
}: {
  value: PlatformBranding;
  theme?: Theme;
  assetUrls?: ReadonlyMap<string, string>;
}) {
  const id = useId();
  const storedTheme = useSyncExternalStore(
    subscribeTheme,
    currentTheme,
    () => "dark" as Theme,
  );
  const theme = selectedTheme ?? storedTheme;
  const candidate = useMemo(() => normalizeBranding(value), [value]);
  const [lastConfirmed, setConfirmed] = useState(
    () => candidate ?? normalizeBranding(defaultBranding)!,
  );
  const confirmed = candidate ?? lastConfirmed;
  if (candidate && candidate !== lastConfirmed) setConfirmed(candidate);
  const [checked, setChecked] = useState(true);
  const [enabled, setEnabled] = useState(false);
  const [selection, setSelection] = useState("one");
  const valid = candidate !== null;
  return (
    <section
      aria-label="Предпросмотр брендинга"
      className="base-branding-preview"
    >
      <h2>Предпросмотр на компонентах Base</h2>
      {!valid && (
        <p role="status">
          Показана последняя корректная настройка. Завершите ввод полей.
        </p>
      )}
      <BrandingScope value={confirmed} theme={theme}>
        <PlatformHeader
          currentServiceKey="branding-preview"
          serviceSwitcher={false}
          leading={
            <span className="base-branding-identity">
              <BrandingMark
                document={
                  {
                    ...createBrandDocument(),
                    ...confirmed,
                    design: {
                      ...createBrandDocument().design,
                      ...confirmed.design,
                    },
                  } as BrandDesignDocument
                }
                theme={theme}
                size={28}
                assetUrls={assetUrls}
              />
              <span>{confirmed.product_short_name}</span>
            </span>
          }
          actions={
            <Button size="sm" variant="secondary" disabled>
              Аккаунт
            </Button>
          }
        />
        <div className="base-branding-navigation">
          <SidebarItem active>Обзор</SidebarItem>
          <SidebarItem>Настройки</SidebarItem>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>{confirmed.product_name}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="base-page-stack">
              <div className="base-page-actions">
                <Button
                  type="button"
                  onClick={() =>
                    toast.success("Локальное уведомление", { toasterId: id })
                  }
                >
                  Действие
                </Button>
                <Button type="button" variant="outline">
                  Вторичное
                </Button>
                <Button type="button" disabled>
                  Недоступно
                </Button>
                <Button type="button" variant="link">
                  Ссылка
                </Button>
                <Button type="button" variant="destructive">
                  Опасное действие
                </Button>
              </div>
              <Fieldset legend="Поля формы" className="base-page-stack">
                <FormField id={id + "name"} label="Название">
                  {(attrs) => (
                    <Input {...attrs} defaultValue="Пример приложения" />
                  )}
                </FormField>
                <FormField
                  id={id + "error"}
                  label="Проверка поля"
                  hint={
                    <span className="text-danger">
                      Пример сообщения об ошибке
                    </span>
                  }
                >
                  {(attrs) => (
                    <Input
                      {...attrs}
                      aria-invalid
                      defaultValue="Неверное значение"
                    />
                  )}
                </FormField>
              </Fieldset>
              <Textarea
                aria-label="Описание примера"
                defaultValue="Настоящие компоненты с общими tokens"
              />
              <Checkbox
                label="Выбранный пункт"
                checked={checked}
                onCheckedChange={(value) => setChecked(value === true)}
              />
              <Switch
                label="Включить режим"
                checked={enabled}
                onCheckedChange={setEnabled}
              />
              <RadioGroup
                label="Вид просмотра"
                value={selection}
                onValueChange={setSelection}
                options={[
                  { value: "one", label: "Первый" },
                  { value: "two", label: "Второй" },
                ]}
              />
              <Select
                aria-label="Категория примера"
                options={[
                  { value: "one", label: "Первый вариант" },
                  { value: "two", label: "Второй вариант" },
                ]}
                value={selection}
                onValueChange={setSelection}
              />
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Объект</TableHead>
                    <TableHead>Состояние</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>Компонент Base</TableCell>
                    <TableCell>Готов</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
              <div
                className="base-page-actions"
                aria-label="Смысловые состояния"
              >
                <Badge tone="success">Готово</Badge>
                <Badge tone="warning">Внимание</Badge>
                <Badge tone="danger">Ошибка</Badge>
              </div>
              <ResourceList variant="bordered" aria-label="Список примера">
                <ResourceListRow>Строка с общей плотностью</ResourceListRow>
              </ResourceList>
              <Disclosure summary="Дополнительные сведения">
                Текст, отступы и поверхности используют тот же брендинг.
              </Disclosure>
              <div className="base-page-actions">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button type="button" variant="outline">
                      Меню примера
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem>Локальное действие</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button type="button" variant="outline">
                      Диалог примера
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogTitle>Диалог Base</DialogTitle>
                    <DialogDescription>
                      Тема, шрифт и геометрия наследуются от предпросмотра.
                    </DialogDescription>
                    <Input aria-label="Поле диалога" />
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>
        <Toaster id={id} theme={theme === "light" ? "light" : "dark"} />
      </BrandingScope>
      <p className="text-text-muted">
        Черновик не публикуется и не меняет оформление страницы редактора.
      </p>
    </section>
  );
}

/** Shared Admin/dictionary form. The caller owns the document and any save/publish workflow. */
export function BrandingEditor({
  value,
  onChange,
  disabled = false,
}: BrandingEditorProps) {
  const [variant, setVariant] = useState<MarkVariant>("common");
  const [theme, setTheme] = useState<Theme>("dark");
  const defaults = createBrandDocument();
  const document = {
    ...defaults,
    ...value,
    design: { ...defaults.design, ...value.design },
  } as BrandDesignDocument;
  return (
    <div className="base-brand-editor-layout">
      <ExpandedBrandingEditor
        value={document}
        onChange={(next) => {
          if (disabled) return;
          if (next.design === document.design) {
            const flat: PlatformBranding = { ...next };
            delete flat.design;
            onChange(
              value.design === undefined
                ? flat
                : { ...flat, design: value.design },
            );
          } else onChange(next);
        }}
        disabled={disabled}
        variant={variant}
        onVariantChange={setVariant}
        colorTheme={theme}
        onColorThemeChange={setTheme}
        onUpload={() => undefined}
        uploadError=""
        uploadDisabledReason="Загрузка изображений доступна в Admin Panel."
      />
      <BrandingPreview value={value} theme={theme} />
    </div>
  );
}

export interface BrandingSettingsProps extends BrandingEditorProps {
  /** Application-specific actions; authorization and publication stay with the caller. */
  actions?: ReactNode;
  /** Override only for another workflow, such as a local dictionary demonstration. */
  description?: string;
  /** Loading, errors and revision notices supplied by the document owner. */
  children?: ReactNode;
}

/** Complete shared section, including heading, actions, status placement and editor geometry. */
export function BrandingSettings({
  actions,
  description = "Название, логотип, цвета, встроенный шрифт и геометрия платформы. Произвольный CSS не допускается.",
  children,
  ...editor
}: BrandingSettingsProps) {
  return (
    <div className="space-y-6" data-base-branding-settings>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0 flex-1 basis-64">
          <h1 className="base-page-title font-semibold">Брендинг платформы</h1>
          <p className="mt-1 text-sm text-text-muted">{description}</p>
        </div>
        {actions && (
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            {actions}
          </div>
        )}
      </div>
      {children}
      <BrandingEditor {...editor} />
    </div>
  );
}
