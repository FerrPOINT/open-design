import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cn } from "../lib/utils";

export interface ResourceListProps extends React.HTMLAttributes<HTMLDivElement> {
  asChild?: boolean;
  variant?: "plain" | "bordered";
  density?: "normal" | "comfortable";
}

export interface ResourceListRowProps extends React.HTMLAttributes<HTMLDivElement> {
  asChild?: boolean;
  interactive?: boolean;
}

/** Styling only: consumers retain native list structure and content layout. */
export const ResourceList = React.forwardRef<HTMLDivElement, ResourceListProps>(
  (
    {
      asChild = false,
      variant = "plain",
      density = "normal",
      className,
      ...props
    },
    ref,
  ) => {
    const Component = asChild ? Slot : "div";
    return (
      <Component
        {...props}
        ref={ref}
        className={cn("base-resource-list", className)}
        data-variant={variant}
        data-density={density}
      />
    );
  },
);
ResourceList.displayName = "ResourceList";

/** Interactive appearance never supplies routing, roles or keyboard handlers. */
export const ResourceListRow = React.forwardRef<
  HTMLDivElement,
  ResourceListRowProps
>(({ asChild = false, interactive = false, className, ...props }, ref) => {
  const Component = asChild ? Slot : "div";
  return (
    <Component
      {...props}
      ref={ref}
      className={cn("base-resource-list-row", className)}
      data-interactive={interactive ? "true" : undefined}
    />
  );
});
ResourceListRow.displayName = "ResourceListRow";

/** One native action per row; the consumer owns selection, data and the callback. */
export const ResourceListButton = React.forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement>
>(({ type = "button", className, ...props }, ref) => (
  <button
    {...props}
    ref={ref}
    type={type}
    className={cn("base-resource-list-row", className)}
    data-interactive="true"
  />
));
ResourceListButton.displayName = "ResourceListButton";
