import { memo } from 'react'
import { createAvatar, type Style } from '@dicebear/core'
import * as micah from '@dicebear/micah'
import { UserRound } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { cn } from '../lib/utils'

export interface UserAvatarProps {
  name?: string | null
  userId?: string | null
  size?: 'sm' | 'md'
}

const sizeClasses = { sm: 'h-6 w-6', md: 'h-8 w-8' }
const micahStyle: Style<micah.Options> = {
  create: micah.create,
  meta: micah.meta,
  schema: micah.schema,
}

function UserAvatarView({ name, userId, size = 'sm' }: UserAvatarProps) {
  const { t } = useTranslation()
  const seed = userId || name
  const className = cn(sizeClasses[size], 'shrink-0 rounded-full')
  if (!seed) {
    return (
      <span
        role="img"
        aria-label={t('common.unassigned')}
        className={cn(
          className,
          'flex items-center justify-center bg-surface-raised text-text-muted',
        )}
      >
        <UserRound className="h-3.5 w-3.5" aria-hidden="true" />
      </span>
    )
  }
  const source = createAvatar(micahStyle, {
    backgroundColor: ['e2e8f0'],
    radius: 50,
    seed,
    size: 64,
  }).toDataUri()
  return <img alt={name || t('common.user')} className={className} src={source} />
}

export const UserAvatar = memo(UserAvatarView)
