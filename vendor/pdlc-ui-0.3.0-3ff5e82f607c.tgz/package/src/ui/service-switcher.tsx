import { useApplicationAccess } from '../auth/application-access'
import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  useSyncExternalStore,
  type ReactNode,
} from "react";
import {
  Check,
  ChevronDown,
  GitBranch,
  LayoutDashboard,
  LayoutGrid,
  ListChecks,
  Network,
  Workflow,
  type LucideIcon,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./dropdown-menu";
import { getPlatformProduct } from '../platform/bridge.js'
import { transportNamespaceLocation } from '../lib/namespace-location'

/**
 * Public runtime service catalog served by the Base Admin Panel
 * (`GET /api/v1/runtime/services`). Only active services with approved
 * declarations appear here.
 *
 * Catalog v1.1 adds `ui_url` (null for API-only services) and `health`
 * (healthy | unreachable | unknown).
 */
export interface CatalogService {
  key: string;
  label: string;
  url: string;
  /** Frontend URL; null for API-only services — switchers skip them. */
  ui_url: string | null;
  /** Last background health probe outcome; missing values degrade to unknown. */
  health: "healthy" | "unreachable" | "unknown";
  capabilities: string[];
  contract_version: string;
}

/** Compiled-in display fallback; its origins do not authorize navigation. */
export const defaultServices: CatalogService[] = [
  {
    key: "admin-panel",
    label: "Admin Panel",
    url: "http://localhost:7772",
    ui_url: "http://localhost:7772",
    health: "unknown",
    capabilities: ["health.read"],
    contract_version: "1.0.0",
  },
  {
    key: "ci-cd",
    label: "CI/CD",
    url: "http://localhost:7712",
    ui_url: "http://localhost:7712",
    health: "unknown",
    capabilities: ["health.read"],
    contract_version: "1.0.0",
  },
  {
    key: "task-tracker",
    label: "Task Tracker",
    url: "http://localhost:7722",
    ui_url: "http://localhost:7722",
    health: "unknown",
    capabilities: ["health.read"],
    contract_version: "1.0.0",
  },
  {
    key: "wiki",
    label: "Wiki",
    url: "http://localhost:7732",
    ui_url: "http://localhost:7732",
    health: "unknown",
    capabilities: ["health.read"],
    contract_version: "1.0.0",
  },
  {
    key: "fleet-control",
    label: "Fleet Control",
    url: "http://localhost:7742",
    ui_url: "http://localhost:7742",
    health: "unknown",
    capabilities: ["health.read"],
    contract_version: "1.0.0",
  },
  {
    key: "project-workflow",
    label: "Project Workflow",
    url: "http://localhost:7752",
    ui_url: "http://localhost:7752",
    health: "unknown",
    capabilities: ["health.read"],
    contract_version: "1.0.0",
  },
];

export type PlatformServicesSource =
  "runtime" | "fallback-unreachable" | "fallback-empty" | "fallback-invalid";

export interface PlatformServicesState {
  /** Validated runtime destinations; empty until a catalog is available. */
  services: CatalogService[];
  source: PlatformServicesSource;
}

const PlatformServicesContext = createContext<PlatformServicesState>({
  services: [],
  source: "fallback-unreachable",
});

const serviceOrder = new Map(
  defaultServices.map((service, index) => [service.key, index]),
);

function sortServices(services: CatalogService[]) {
  return [...services].sort((left, right) => {
    const leftOrder = serviceOrder.get(left.key) ?? Number.MAX_SAFE_INTEGER;
    const rightOrder = serviceOrder.get(right.key) ?? Number.MAX_SAFE_INTEGER;
    return leftOrder - rightOrder || left.key.localeCompare(right.key);
  });
}

function parseHealth(raw: unknown): CatalogService["health"] {
  return raw === "healthy" || raw === "unreachable" ? raw : "unknown";
}

function isServiceUrl(value: unknown): value is string {
  if (typeof value !== "string" || !/^https?:\/\//.test(value)) return false;
  try {
    const url = new URL(value);
    return url.hostname !== "" && url.username === "" && url.password === "";
  } catch {
    return false;
  }
}

function parseCatalog(payload: unknown): CatalogService[] | null {
  if (typeof payload !== "object" || payload === null) return null;
  const doc = payload as { services?: unknown };
  if (!Array.isArray(doc.services)) return null;
  const out: CatalogService[] = [];
  const keys = new Set<string>();
  for (const raw of doc.services) {
    if (typeof raw !== "object" || raw === null) return null;
    const s = raw as Record<string, unknown>;
    if (
      typeof s.key !== "string" ||
      s.key.length === 0 ||
      keys.has(s.key) ||
      typeof s.label !== "string" ||
      !isServiceUrl(s.url)
    ) {
      return null;
    }
    keys.add(s.key);
    // Catalog v1.0 entries (no ui_url) keep the url as the UI target so the
    // switcher degrades gracefully against an older Admin Panel.
    const hasUiUrl = Object.hasOwn(s, "ui_url");
    if (hasUiUrl && s.ui_url !== null && !isServiceUrl(s.ui_url)) {
      return null;
    }
    if (
      s.capabilities !== undefined &&
      (!Array.isArray(s.capabilities) ||
        !s.capabilities.every((capability) => typeof capability === "string"))
    ) {
      return null;
    }
    const uiUrl = hasUiUrl ? (s.ui_url as string | null) : s.url;
    out.push({
      key: s.key,
      label: s.label,
      url: s.url,
      ui_url: uiUrl,
      health: parseHealth(s.health),
      capabilities: Array.isArray(s.capabilities)
        ? (s.capabilities as string[])
        : [],
      contract_version:
        typeof s.contract_version === "string" ? s.contract_version : "",
    });
  }
  return sortServices(out);
}

export function PlatformServicesProvider({
  catalogUrl,
  children,
}: {
  /** Admin Panel runtime catalog endpoint; null keeps display-only defaults. */
  catalogUrl: string | null;
  children: ReactNode;
}) {
  const [state, setState] = useState<PlatformServicesState>({
    services: [],
    source: "fallback-unreachable",
  });

  useEffect(() => {
    if (!catalogUrl) return;
    let cancelled = false;
    const load = async () => {
      try {
        const response = await fetch(catalogUrl, { cache: "no-store" });
        if (!response.ok) {
          if (!cancelled)
            setState({
              services: [],
              source: "fallback-unreachable",
            });
          return;
        }
        let payload: unknown;
        try {
          payload = await response.json();
        } catch {
          if (!cancelled)
            setState({ services: [], source: "fallback-invalid" });
          return;
        }
        const catalog = parseCatalog(payload);
        if (cancelled) return;
        if (catalog === null) {
          setState({ services: [], source: "fallback-invalid" });
        } else if (catalog.length === 0) {
          setState({ services: [], source: "fallback-empty" });
        } else {
          setState({ services: catalog, source: "runtime" });
        }
      } catch {
        if (!cancelled)
          setState({
            services: [],
            source: "fallback-unreachable",
          });
      }
    };
    void load();
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") void load();
    }, 60_000);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [catalogUrl]);

  const value = useMemo(() => state, [state]);
  return (
    <PlatformServicesContext.Provider value={value}>
      {children}
    </PlatformServicesContext.Provider>
  );
}

export function usePlatformServices(): PlatformServicesState {
  return useContext(PlatformServicesContext);
}

function healthDotClass(health: CatalogService["health"]): string {
  switch (health) {
    case "healthy":
      return "bg-emerald-500";
    case "unreachable":
      return "bg-red-500";
    default:
      return "bg-amber-500";
  }
}

const healthLabel: Record<CatalogService["health"], string> = {
  healthy: "Работает",
  unreachable: "Недоступен",
  unknown: "Состояние неизвестно",
};

const serviceIcons: Record<string, LucideIcon> = {
  "admin-panel": LayoutDashboard,
  "ci-cd": GitBranch,
  "task-tracker": ListChecks,
  wiki: LayoutGrid,
  "fleet-control": Network,
  "project-workflow": Workflow,
};

export function getSwitcherServices(
  services: CatalogService[],
): CatalogService[] {
  return sortServices(services.filter((service) => service.ui_url !== null));
}

/**
 * Cross-product navigation. Renders the OTHER UI services from the runtime
 * catalog as plain links — regular navigation, no tokens in URLs; the
 * central auth session carries over via silent refresh.
 *
 * Click to open (not hover), Escape to close, arrow-key navigation,
 * per-service health dot; API-only services (ui_url null) are skipped.
 * Compiled defaults are display-only until runtime or host configuration
 * supplies this workspace's destinations, independently of service health.
 */
export function ServiceSwitcher({
  currentKey,
  showCurrentLabel = false,
}: {
  currentKey: string;
  showCurrentLabel?: boolean;
}) {
  const { services, source } = usePlatformServices();
  const access = useApplicationAccess()
  const product = getPlatformProduct()
  const configuredServices = useSyncExternalStore(
    listener => product?.subscribe(listener) ?? (() => {}),
    () => product?.services ?? null,
    () => null,
  )
  const [open, setOpen] = useState(false)
  const configuredCatalog = configuredServices?.map(service => ({
    ...service, url: service.origin, ui_url: service.origin, health: 'unknown' as const,
    capabilities: [], contract_version: '',
  }))
  const catalog = source === 'runtime' ? services : configuredCatalog?.length ? configuredCatalog : defaultServices
  const navigationConfigured = source === 'runtime' || Boolean(configuredCatalog?.length)
  const availableServices = getSwitcherServices(configuredServices?.length ? catalog.filter(service => configuredServices.some(item => item.key === service.key)) : catalog);
  const uiServices = access ? availableServices.filter(service => access.permits([service.key])) : availableServices
  const currentService = showCurrentLabel ? uiServices.find((service) => service.key === currentKey) : undefined;

  if (uiServices.length === 0) return null;

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={
            currentService
              ? `Открыть список сервисов: ${currentService.label}`
              : "Открыть список сервисов"
          }
          title={currentService?.label}
          className="flex min-h-10 min-w-10 items-center gap-2 rounded-md px-2.5 text-sm text-text-secondary transition-colors hover:bg-surface-raised hover:text-text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-focus"
        >
          <LayoutGrid className="h-4 w-4" aria-hidden />
          <span className="service-switcher-label">
            {currentService?.label ?? "Сервисы"}
          </span>
          <ChevronDown className="hidden h-3.5 w-3.5 sm:block" aria-hidden />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        sideOffset={6}
        aria-label="Переключение сервисов"
        className="w-72 border-border-strong bg-popover text-popover-foreground shadow-xl"
      >
        {uiServices.map((service) => {
          const product = getPlatformProduct()
          const configured = product?.services.find(item => item.key === service.key)
          const search = product ? new URL(product.route, window.location.origin).search : window.location.search
          const target = transportNamespaceLocation(configured?.origin ?? service.ui_url ?? service.url, search)
          const targetUrl = new URL(target)
          const href = configured && product ? product.portalOrigin + configured.path.slice(0, -1) + targetUrl.pathname + targetUrl.search + targetUrl.hash : target
          const Icon = serviceIcons[service.key] ?? LayoutGrid;
          const isCurrent = service.key === currentKey;
          const content = (
            <>
              <Icon className="h-4 w-4 shrink-0 text-text-muted" aria-hidden />
              <span className="min-w-0 flex-1 truncate">{service.label}</span>
              <span
                role="img"
                className={`h-2 w-2 shrink-0 rounded-full ${healthDotClass(service.health)}`}
                title={healthLabel[service.health]}
                aria-label={healthLabel[service.health]}
              />
              {isCurrent && (
                <Check
                  className="h-4 w-4 shrink-0 text-accent"
                  aria-label="Текущий сервис"
                />
              )}
            </>
          );
          return isCurrent || !navigationConfigured ? (
            <DropdownMenuItem
              key={service.key}
              disabled
              title={!isCurrent && !navigationConfigured ? "Адрес сервиса не подтверждён каталогом" : undefined}
              className={`gap-2.5 py-2.5${isCurrent ? " opacity-100" : ""}`}
            >
              {content}
            </DropdownMenuItem>
          ) : (
            <DropdownMenuItem
              key={service.key}
              asChild
              className="gap-2.5 py-2.5"
            >
              <a href={href} onClick={event => {
                const product = getPlatformProduct()
                if (!product || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return
                event.preventDefault()
                setOpen(false)
                product.requestNavigation(target)
              }}>{content}</a>
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

// re-export for convenience in app shells
export { Link as SwitcherLink } from "react-router";
