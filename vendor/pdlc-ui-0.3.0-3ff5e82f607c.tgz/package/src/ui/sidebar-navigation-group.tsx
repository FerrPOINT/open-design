import { useId, useState, type ElementType, type ReactNode } from "react";
import { ChevronRight, Settings2 } from "lucide-react";
import { SidebarItem } from "./sidebar-item";

/** A route change opens its group; a manual fold lasts until the next route change. */
export function useSidebarDisclosure(activeRoute: string | null) {
  const [state, setState] = useState({
    route: activeRoute,
    open: Boolean(activeRoute),
  });
  if (state.route !== activeRoute)
    setState({ route: activeRoute, open: Boolean(activeRoute) });
  return {
    open: state.route === activeRoute ? state.open : Boolean(activeRoute),
    onOpenChange: (open: boolean) => setState({ route: activeRoute, open }),
  };
}

export function SidebarNavigationGroup({
  label,
  icon: Icon = Settings2,
  active = false,
  compact = false,
  open,
  onOpenChange,
  children,
}: {
  label: string;
  icon?: ElementType;
  active?: boolean;
  compact?: boolean | "responsive";
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
}) {
  const id = useId();
  return (
    <section
      aria-label={label}
      data-compact={compact}
      className="base-sidebar-list mt-3 border-t border-border pt-3"
    >
      <SidebarItem
        kind="group"
        active={active}
        compact={compact}
        aria-label={label}
        aria-expanded={open}
        aria-controls={id}
        title={label}
        onClick={() => onOpenChange(!open)}
      >
        <Icon aria-hidden />
        <span className="base-sidebar-item-label">{label}</span>
        {compact !== true && (
          <ChevronRight
            aria-hidden
            className={`${open ? "ml-auto rotate-90" : "ml-auto"}${compact === "responsive" ? " hidden xl:block" : ""}`}
          />
        )}
      </SidebarItem>
      <div
        id={id}
        hidden={!open}
        className="base-sidebar-list"
        data-nested={compact !== true}
      >
        {children}
      </div>
    </section>
  );
}
