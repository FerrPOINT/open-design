import type { HTMLAttributes, ReactNode } from "react";
import { cn } from "../lib/utils";

export type DescriptionItemProps = HTMLAttributes<HTMLDivElement> & {
  label: ReactNode;
  children: ReactNode;
  layout?: "stacked" | "inline";
  technical?: boolean;
};

/** Render inside a product-owned dl; data formatting and empty values belong to the caller. */
export function DescriptionItem({
  label,
  children,
  layout = "stacked",
  technical = false,
  className,
  ...props
}: DescriptionItemProps) {
  return (
    <div
      {...props}
      className={cn("base-description-item", className)}
      data-layout={layout}
    >
      <dt>{label}</dt>
      <dd data-technical={technical || undefined}>{children}</dd>
    </div>
  );
}
