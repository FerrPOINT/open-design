import {
  useLayoutEffect,
  useRef,
  useState,
  type ReactNode,
  type RefObject,
} from "react";
import { useTranslation } from "react-i18next";
import { Button } from "./button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./dialog";
import { ConfirmDialog } from "./async-states";
import { PendingForm, type PendingFormProps } from "./page-patterns";
import { useUiLabels } from "./labels";

export interface FormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  children: ReactNode;
  actions?: ReactNode;
  dirty?: boolean;
  pending?: boolean;
  error?: string | null;
  onSubmit: NonNullable<PendingFormProps["onSubmit"]>;
  returnFocusRef?: RefObject<HTMLElement | null>;
  fallbackFocusRef?: RefObject<HTMLElement | null>;
}

export function FormDialog({
  open,
  onOpenChange,
  title,
  children,
  actions,
  dirty = false,
  pending = false,
  error,
  onSubmit,
  returnFocusRef,
  fallbackFocusRef,
}: FormDialogProps) {
  const labels = useUiLabels();
  const { t } = useTranslation();
  const [discardOpen, setDiscardOpen] = useState(false);
  const [wasOpen, setWasOpen] = useState(open);
  const [submitting, setSubmitting] = useState(false);
  const locked = useRef(false);
  const initiator = useRef<HTMLElement | null>(null);
  const busy = pending || submitting;

  if (wasOpen !== open) {
    setWasOpen(open);
    setDiscardOpen(false);
  }

  useLayoutEffect(() => {
    if (!open) return;
    if (
      document.activeElement instanceof HTMLElement &&
      document.activeElement !== document.body
    )
      initiator.current = document.activeElement;
  }, [open]);

  function requestClose(next: boolean) {
    if (next) {
      onOpenChange(true);
      return;
    }
    if (pending || locked.current) return;
    if (dirty) setDiscardOpen(true);
    else onOpenChange(false);
  }

  return (
    <>
      <Dialog open={open} onOpenChange={requestClose}>
        <DialogContent
          closeDisabled={busy}
          aria-describedby={undefined}
          onKeyDown={(event) => {
            // Radix's tabbable scan does not account for the disabled parent fieldset.
            if (busy && event.key === "Tab" && event.target === event.currentTarget)
              event.preventDefault();
          }}
          onCloseAutoFocus={(event) => {
            const target = [
              returnFocusRef?.current,
              initiator.current,
              fallbackFocusRef?.current,
            ].find(
              (element) =>
                element?.isConnected &&
                !element.matches(":disabled,[hidden],[inert]") &&
                !element.closest("[hidden],[inert]"),
            );
            if (target) {
              event.preventDefault();
              target.focus();
            }
          }}
        >
          <DialogHeader className="pr-12">
            <DialogTitle className="break-words">{title}</DialogTitle>
          </DialogHeader>
          <PendingForm
            pending={busy}
            onSubmit={(event) => {
              event.preventDefault();
              locked.current = true;
              const release = () => {
                locked.current = false;
                setSubmitting(false);
              };
              try {
                const result = onSubmit(event);
                if (result) {
                  setSubmitting(true);
                  return Promise.resolve(result).finally(release);
                }
                queueMicrotask(release);
              } catch (error) {
                release();
                throw error;
              }
            }}
          >
            {error && (
              <p role="alert" className="break-words text-sm text-danger">
                {error}
              </p>
            )}
            {children}
            <div className="base-page-actions justify-end">
              <Button
                type="button"
                variant="secondary"
                onClick={() => requestClose(false)}
              >
                {t("common.cancel")}
              </Button>
              {actions}
            </div>
          </PendingForm>
        </DialogContent>
      </Dialog>
      <ConfirmDialog
        open={open && discardOpen}
        onOpenChange={setDiscardOpen}
        title={labels.leaveTitle}
        description={labels.leaveMessage}
        isPending={busy}
        closeOnConfirm
        onConfirm={() => {
          setDiscardOpen(false);
          onOpenChange(false);
        }}
      />
    </>
  );
}
