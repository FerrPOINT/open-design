import { useTranslation } from 'react-i18next'

const messages = {
  ru: {
    ssoCompleting: 'Завершаем вход…', ssoCallbackError: 'Не удалось завершить вход. Повторите попытку.', ssoRetry: 'Повторить вход',
    loginTitle: 'Вход в платформу', loginSignIn: 'Войти через SSO',
    loginPending: 'Открываем вход…', loginUnavailable: 'Вход временно недоступен. Повторите попытку.',
    expandSidebar: 'Развернуть меню', collapseSidebar: 'Свернуть меню',
    navigation: 'Основная навигация', openNavigation: 'Открыть навигацию',
    account: 'Аккаунт', logout: 'Выйти', close: 'Закрыть',
    notifications: 'Уведомления', closeNotification: 'Закрыть уведомление',
    theme: 'Тема', themeLight: 'Светлая', themeDark: 'Тёмная', themeGray: 'Серая',
    notFound: 'Объект не найден', notFoundMessage: 'Объект удалён или адрес указан неверно.',
    denied: 'Нет доступа', deniedMessage: 'Недостаточно прав для просмотра этого раздела.',
    readError: 'Не удалось загрузить данные.', readPartialError: 'Не удалось обновить данные. Показано последнее подтверждённое состояние.',
    leaveTitle: 'Покинуть страницу?', leaveMessage: 'Несохранённые изменения будут потеряны. Сохраните черновик или подтвердите переход.',
    leaveStay: 'Остаться', leaveConfirm: 'Покинуть',
    chooseOne: 'Выберите значение', chooseMany: 'Выберите значения', chooseAtLeastOne: 'Выберите хотя бы одно значение.',
    requiredField: 'Обязательное поле', noneSelected: 'Ничего не выбрано', selectedValues: 'Выбрано', unavailableValue: 'недоступно',
    selectUnavailable: 'Выбранное значение недоступно', selectDescription: 'Найдите и выберите значение.',
    search: 'Поиск', searchPlaceholder: 'Поиск…', retry: 'Повторить', loading: 'Загрузка…',
    noResults: 'Ничего не найдено.', noOptions: 'Нет доступных вариантов.',
    of: 'из', options: 'вариантов', previous: 'Назад', next: 'Далее', page: 'Страница', noRecords: 'Нет записей',
    code: 'Код', diff: 'Изменения кода', copy: 'Копировать', copied: 'Скопировано', copyFailed: 'Не удалось скопировать. Выделите значение и скопируйте вручную.',
  },
  en: {
    ssoCompleting: 'Finishing sign in…', ssoCallbackError: 'Could not finish signing in. Try again.', ssoRetry: 'Try signing in again',
    loginTitle: 'Sign in to the platform', loginSignIn: 'Sign in with SSO',
    loginPending: 'Opening sign in…', loginUnavailable: 'Sign in is temporarily unavailable. Try again.',
    expandSidebar: 'Expand sidebar', collapseSidebar: 'Collapse sidebar',
    navigation: 'Main navigation', openNavigation: 'Open navigation',
    account: 'Account', logout: 'Log out', close: 'Close',
    notifications: 'Notifications', closeNotification: 'Dismiss notification',
    theme: 'Theme', themeLight: 'Light', themeDark: 'Dark', themeGray: 'Gray',
    notFound: 'Object not found', notFoundMessage: 'The object was removed or the address is invalid.',
    denied: 'Access denied', deniedMessage: 'You do not have permission to view this section.',
    readError: 'Could not load data.', readPartialError: 'Could not refresh data. Showing the last confirmed state.',
    leaveTitle: 'Leave this page?', leaveMessage: 'Unsaved changes will be lost. Save your draft or confirm navigation.',
    leaveStay: 'Stay', leaveConfirm: 'Leave',
    chooseOne: 'Select a value', chooseMany: 'Select values', chooseAtLeastOne: 'Select at least one value.',
    requiredField: 'Required field', noneSelected: 'Nothing selected', selectedValues: 'Selected', unavailableValue: 'unavailable',
    selectUnavailable: 'Selected value is unavailable', selectDescription: 'Search for and select a value.',
    search: 'Search', searchPlaceholder: 'Search…', retry: 'Retry', loading: 'Loading…',
    noResults: 'No results found.', noOptions: 'No available options.',
    of: 'of', options: 'options', previous: 'Previous', next: 'Next', page: 'Page', noRecords: 'No records',
    code: 'Code', diff: 'Code changes', copy: 'Copy', copied: 'Copied', copyFailed: 'Could not copy. Select the value and copy it manually.',
  },
} as const

export function useUiLabels() {
  const { t, i18n } = useTranslation()
  const defaults = i18n?.language?.startsWith('en') ? messages.en : messages.ru
  return Object.fromEntries(Object.entries(defaults).map(([key, value]) => [key, t(`baseUi.${key}`, { defaultValue: value })])) as Record<keyof typeof messages.ru, string>
}
