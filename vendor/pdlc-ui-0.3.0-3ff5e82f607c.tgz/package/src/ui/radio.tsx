import { forwardRef, type InputHTMLAttributes } from "react";
/** Single native group part for rich product option compositions; prefer RadioGroup for plain options. */
export const Radio = forwardRef<
  HTMLInputElement,
  Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "onChange"> & {
    onCheckedChange?: (checked: boolean) => void;
  }
>(function Radio({ onCheckedChange, className, ...props }, ref) {
  return (
    <span
      className={
        className ? "base-check-field " + className : "base-check-field"
      }
    >
      <input
        {...props}
        ref={ref}
        type="radio"
        className="base-check-input"
        onChange={(event) => {
          if (event.currentTarget.checked) onCheckedChange?.(true);
        }}
      />
      <span aria-hidden className="base-radio-indicator" />
    </span>
  );
});
