import { cn } from "../lib/utils";

/** Product supplies its canonical display key; names and list order never choose the avatar. */
export function ProjectAvatar({
  projectKey,
  size = "sm",
}: {
  projectKey: string;
  size?: "xs" | "sm" | "md";
}) {
  const key = projectKey.trim().toUpperCase();
  const colors = ["accent", "emerald", "amber", "rose"];
  const color = key ? colors[key.charCodeAt(0) % colors.length] : "neutral";
  return (
    <span
      aria-hidden="true"
      data-project-avatar={key}
      data-color={color}
      data-size={size}
      className={cn("base-project-avatar")}
    >
      {Array.from(key).slice(0, 2).join("") || "?"}
    </span>
  );
}
