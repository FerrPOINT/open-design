import { forwardRef, useId, type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../lib/utils";
import { Card, CardContent } from "./card";
import { ResourceStateView, type ResourceState } from "./page-patterns";

export interface MetricProps extends Omit<
  HTMLAttributes<HTMLDivElement>,
  "children"
> {
  label: ReactNode;
  value: ReactNode;
  description?: ReactNode;
  icon?: ReactNode;
  appearance?: "card" | "inline";
  tone?: "default" | "info" | "success" | "warning" | "danger";
  state?: ResourceState;
}

/** Product code formats values and selects the read state; a missing value is never converted to zero. */
export const Metric = forwardRef<HTMLDivElement, MetricProps>(function Metric(
  {
    label,
    value,
    description,
    icon,
    appearance = "card",
    tone = "default",
    state,
    className,
    ...props
  },
  ref,
) {
  const labelId = useId();
  const inline = appearance === "inline";
  const hasDescription =
    description != null &&
    typeof description !== "boolean" &&
    description !== "";
  const hasIcon = icon != null && typeof icon !== "boolean" && icon !== "";
  const showsData =
    !state || state.kind === "ready" || state.kind === "partial-error";
  const content = (
    <div className="base-metric-body">
      {hasIcon && (
        <span className="base-metric-icon" aria-hidden>
          {icon}
        </span>
      )}
      <div className="base-metric-copy">
        <dl className="base-metric-definition">
          <dt id={labelId} className="base-metric-label">
            {label}
          </dt>
          <dd aria-labelledby={labelId} className="base-metric-value">
            {showsData && value}
            {state && state.kind !== "ready" && (
              <div className="base-metric-state">
                <ResourceStateView state={state} />
              </div>
            )}
          </dd>
        </dl>
        {hasDescription && showsData && (
          <p className="base-metric-description">{description}</p>
        )}
      </div>
    </div>
  );
  if (inline)
    return (
      <div
        {...props}
        role={props.role ?? "group"}
        aria-labelledby={
          props["aria-labelledby"] ??
          (props["aria-label"] ? undefined : labelId)
        }
        ref={ref}
        className={cn("base-metric", className)}
        data-appearance={appearance}
        data-tone={tone}
        aria-busy={state?.kind === "loading" || undefined}
      >
        {content}
      </div>
    );
  return (
    <Card
      {...props}
      role={props.role ?? "group"}
      aria-labelledby={
        props["aria-labelledby"] ?? (props["aria-label"] ? undefined : labelId)
      }
      ref={ref}
      className={cn("base-metric", className)}
      data-appearance={appearance}
      data-tone={tone}
      aria-busy={state?.kind === "loading" || undefined}
    >
      <CardContent>{content}</CardContent>
    </Card>
  );
});
