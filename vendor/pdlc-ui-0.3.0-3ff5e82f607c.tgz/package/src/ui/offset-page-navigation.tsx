import { PageNavigation } from './page-navigation'
import { useUiLabels } from './labels'

export interface OffsetPageNavigationProps {
  offset: number
  limit: number
  total: number
  onOffsetChange: (offset: number) => void
  label: string
  pending?: boolean
  className?: string
}

/** Offset/limit presentation only; requests, filters and URL changes belong to the owner. */
export function OffsetPageNavigation({
  offset, limit, total, onOffsetChange, label, pending = false, className,
}: OffsetPageNavigationProps) {
  const labels = useUiLabels()
  // A valid offset need not be divisible by limit; previous still returns toward zero.
  const page = Math.ceil(offset / limit) + 1
  return (
    <PageNavigation
      page={page}
      hasNext={offset + limit < total}
      onPageChange={(next) => onOffsetChange(next < page ? Math.max(0, offset - limit) : offset + limit)}
      label={label}
      pending={pending}
      className={className}
      summary={offset < total ? `${offset + 1}–${Math.min(offset + limit, total)} ${labels.of} ${total}` : labels.noRecords}
    />
  )
}
