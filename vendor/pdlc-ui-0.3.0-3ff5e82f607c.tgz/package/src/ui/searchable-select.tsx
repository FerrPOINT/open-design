import { useState, type AriaAttributes } from 'react'
import { ChevronDown, Check } from 'lucide-react'
import { Button } from './button'
import { Input } from './input'
import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogTrigger } from './dialog'
import { useUiLabels } from './labels'

import type { ChoiceOption } from './choice-types'
export interface SearchableSelectProps extends Pick<AriaAttributes, 'aria-invalid' | 'aria-describedby'> {
  id?: string; label: string; value: string; selectedLabel?: string; placeholder: string;
  options: ChoiceOption[]; search: string; onSearch: (search: string) => void;
  offset: number; pageSize: number; total: number; onPage: (offset: number) => void;
  onChange: (value: string) => void; loading?: boolean; error?: string;
  onRetry?: () => void; disabled?: boolean; allowEmpty?: boolean;
}

/** A paged choice dialog uses native buttons and Radix focus management, not a second form. */
export function SearchableSelect({ id, label, value, selectedLabel, placeholder, options,
  search, onSearch, offset, pageSize, total, onPage, onChange, loading, error,
  onRetry, disabled, allowEmpty = true, ...accessibility }: SearchableSelectProps) {
  const [open, setOpen] = useState(false)
  const labels = useUiLabels()
  const selected = selectedLabel ?? options.find(option => option.value === value)?.label
  function choose(next: string) { onChange(next); setOpen(false) }
  return <Dialog open={open} onOpenChange={setOpen}>
    <DialogTrigger asChild>
      <Button {...accessibility} id={id} type="button" variant="outline" disabled={disabled}
        aria-label={`${label}: ${value ? selected ?? labels.selectUnavailable : placeholder}`}
        title={value ? selected ?? labels.selectUnavailable : placeholder}
        className="base-choice-trigger">
        <span className="base-choice-summary">{value ? selected ?? labels.selectUnavailable : placeholder}</span>
        <ChevronDown aria-hidden className="h-4 w-4 shrink-0" />
      </Button>
    </DialogTrigger>
    <DialogContent>
      <DialogTitle>{label}</DialogTitle>
      <DialogDescription>{labels.selectDescription}</DialogDescription>
      <Input type="search" aria-label={`${labels.search}: ${label}`} placeholder={labels.searchPlaceholder} value={search}
        onChange={event => onSearch(event.target.value)}
        onKeyDown={event => { if (event.key === 'Enter') event.preventDefault() }} />
      <div className="max-h-[45dvh] space-y-1 overflow-y-auto" aria-busy={loading || undefined}>
        {allowEmpty && <Button type="button" variant="ghost" className="base-choice-option w-full"
          onClick={() => choose('')}>{!value && <Check aria-hidden className="h-4 w-4" />}{placeholder}</Button>}
        {error ? <div role="alert" className="space-y-2"><p>{error}</p>
          {onRetry && <Button type="button" variant="outline" onClick={onRetry}>{labels.retry}</Button>}</div>
          : loading ? <p role="status">{labels.loading}</p>
            : options.length ? options.map(option => <Button key={option.value} type="button"
              variant="ghost" className="base-choice-option w-full" disabled={option.disabled}
              aria-pressed={option.value === value} onClick={() => choose(option.value)}>
              {option.value === value && <Check aria-hidden className="h-4 w-4 shrink-0" />}{option.label}
            </Button>) : <p role="status">{search ? labels.noResults : labels.noOptions}</p>}
      </div>
      {!loading && !error && <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-text-muted">{total ? `${offset + 1}–${Math.min(offset + options.length, total)} ${labels.of} ${total}` : `0 ${labels.options}`}</p>
        {total > pageSize && <div className="flex gap-2">
          <Button type="button" variant="outline" disabled={loading || !offset} onClick={() => onPage(Math.max(0, offset - pageSize))}>{labels.previous}</Button>
          <Button type="button" variant="outline" disabled={loading || offset + pageSize >= total} onClick={() => onPage(offset + pageSize)}>{labels.next}</Button>
        </div>}
      </div>}
    </DialogContent>
  </Dialog>
}
