import * as React from "react";
import { useComposedRefs } from "@radix-ui/react-compose-refs";
import { Search, X } from "lucide-react";
import { cn } from "../lib/utils";
import { InputWithAction } from "./input-with-action";

/** Native search field; the consumer owns the query, debounce, requests and clear action. */
export interface SearchInputProps extends Omit<
  React.ComponentPropsWithoutRef<typeof InputWithAction>,
  "type" | "action" | "containerClassName"
> {
  /** Layout of the whole field, without overriding the shared input geometry. */
  containerClassName?: string;
  /** Present only when the owner offers a clear action; never synthesizes a change event. */
  clear?: { label: string; onClear: () => void };
}

/** The forwarded ref always points to the native input, not the adornment wrapper. */
export const SearchInput = React.forwardRef<HTMLInputElement, SearchInputProps>(
  (
    { containerClassName, className, clear, disabled, readOnly, ...props },
    forwardedRef,
  ) => {
    const input = React.useRef<HTMLInputElement>(null);
    const ref = useComposedRefs(input, forwardedRef);
    return (
      <span
        className={cn("base-search-input", containerClassName)}
        data-clearable={clear ? "true" : undefined}
      >
        <Search
          className="base-search-input-icon"
          aria-hidden="true"
          focusable="false"
        />
        <InputWithAction
          {...props}
          ref={ref}
          type="search"
          disabled={disabled}
          readOnly={readOnly}
          className={className}
          action={
            clear
              ? {
                  label: clear.label,
                  icon: <X aria-hidden="true" focusable="false" />,
                  disabled: readOnly,
                  onAction: () => {
                    clear.onClear();
                    if (input.current?.isConnected) input.current.focus();
                  },
                }
              : undefined
          }
        />
      </span>
    );
  },
);
SearchInput.displayName = "SearchInput";
