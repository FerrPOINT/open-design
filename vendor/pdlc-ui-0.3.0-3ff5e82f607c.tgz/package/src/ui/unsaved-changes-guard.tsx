import { useCallback, type RefObject } from 'react'
import { useBeforeUnload, useBlocker, type BlockerFunction } from 'react-router'
import { ConfirmDialog } from './async-states'
import { useUiLabels } from './labels'
import { usePlatformLeaveGuard } from '../platform/index'

export function UnsavedChangesGuard({ when, title, description, shouldBlockNavigation, returnFocusRef, fallbackFocusRef }: { when: boolean; title?: string; description?: string; shouldBlockNavigation?: BlockerFunction; returnFocusRef?: RefObject<HTMLElement | null>; fallbackFocusRef?: RefObject<HTMLElement | null> }) {
  const blocker = useBlocker(shouldBlockNavigation ? args => when && shouldBlockNavigation(args) : when)
  const labels = useUiLabels()
  const platform = usePlatformLeaveGuard(when)
  useBeforeUnload(useCallback(event => {
    if (!when) return
    event.preventDefault()
    event.returnValue = ''
  }, [when]))
  return <ConfirmDialog open={platform.blocked || blocker.state === 'blocked'} onOpenChange={open => { if (!open) { platform.cancel(); if (blocker.state === 'blocked') blocker.reset() } }} title={title ?? labels.leaveTitle} description={description ?? labels.leaveMessage} returnFocusRef={returnFocusRef} fallbackFocusRef={fallbackFocusRef} cancelLabel={labels.leaveStay} confirmLabel={labels.leaveConfirm} onConfirm={() => { if (platform.blocked) platform.confirm(); else if (blocker.state === 'blocked') blocker.proceed() }} />
}
