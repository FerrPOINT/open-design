import { forwardRef, useEffect, useId, useState } from "react";
import * as Primitive from "@radix-ui/react-select";
import * as Menu from "@radix-ui/react-dropdown-menu";
import { useComposedRefs } from "@radix-ui/react-compose-refs";
import { Check, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "../lib/utils";
import { useUiLabels } from "./labels";
import {
  ChoiceFormBridge,
  useChoiceState,
  useChoiceTheme,
  useChoiceTab,
  useChoiceDisabled,
  useChoiceValidation,
  type ChoiceFieldProps,
} from "./choice-field";
export type { ChoiceOption } from "./choice-types";

export interface SelectProps extends ChoiceFieldProps {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
}

export const Select = forwardRef<HTMLButtonElement, SelectProps>(
  function Select(
    {
      options,
      value,
      defaultValue = "",
      onValueChange,
      name,
      form,
      required,
      disabled,
      placeholder,
      className,
      ...props
    },
    ref,
  ) {
    const ui = useUiLabels();
    const state = useChoiceState(value, defaultValue);
    const presentationForm = useId();
    const [trigger, setTrigger] = useState<HTMLButtonElement | null>(null);
    const composedRef = useComposedRefs(ref, setTrigger);
    const fieldDisabled = useChoiceDisabled(trigger, disabled);
    const validation = useChoiceValidation(
      [state.value],
      required,
      fieldDisabled,
    );
    const [open, setOpen] = useState(false);
    useEffect(() => {
      if (fieldDisabled) setOpen(false);
    }, [fieldDisabled]);
    const theme = useChoiceTheme(trigger, open);
    const tab = useChoiceTab(trigger, () => setOpen(false));
    const selected = options.find((option) => option.value === state.value);
    const label =
      selected?.label ??
      (state.value
        ? `${state.value} — ${ui.unavailableValue}`
        : (placeholder ?? ui.chooseOne));
    return (
      <>
        {/* Isolate Radix reset/bubble handling; ChoiceFormBridge is the sole form owner. */}
        <Primitive.Root
          form={presentationForm}
          value={state.value}
          open={open}
          onOpenChange={setOpen}
          disabled={fieldDisabled}
          onValueChange={(next) => {
            const option = options.find((option) => option.value === next);
            if (
              fieldDisabled ||
              !option ||
              option.disabled ||
              option.value === state.value
            )
              return;
            state.change(option.value);
            onValueChange?.(option.value);
          }}
        >
          <Primitive.Trigger
            form={form}
            data-value={state.value}
            {...props}
            id={props.id ?? `${presentationForm}-trigger`}
            ref={composedRef}
            className={cn("base-control base-choice-trigger", className)}
            aria-required={required || undefined}
            aria-invalid={
              validation.invalid || props["aria-invalid"] || undefined
            }
            aria-describedby={
              [
                props["aria-describedby"],
                validation.invalid ? validation.errorId : undefined,
              ]
                .filter(Boolean)
                .join(" ") || undefined
            }
            title={props.title ?? label}
          >
            <Primitive.Value
              className="base-choice-summary"
              placeholder={label}
            >
              {label}
            </Primitive.Value>
            <Primitive.Icon asChild>
              <ChevronDown size={16} aria-hidden="true" />
            </Primitive.Icon>
          </Primitive.Trigger>
          <Primitive.Portal container={trigger?.ownerDocument.body}>
            <Primitive.Content
              aria-labelledby={trigger?.id}
              onKeyDown={tab.onKeyDown}
              onCloseAutoFocus={tab.onCloseAutoFocus}
              style={theme}
              className="base-choice-panel"
              position="popper"
              sideOffset={4}
              collisionPadding={8}
            >
              <Primitive.ScrollUpButton className="base-choice-scroll">
                <ChevronUp size={16} />
              </Primitive.ScrollUpButton>
              <Primitive.Viewport className="base-choice-viewport">
                {options.map((option) => (
                  <Primitive.Item
                    key={option.value}
                    value={option.value}
                    data-value={option.value}
                    disabled={option.disabled}
                    className="base-choice-option"
                  >
                    <Primitive.ItemIndicator className="base-choice-indicator">
                      <Check size={16} />
                    </Primitive.ItemIndicator>
                    <Primitive.ItemText>{option.label}</Primitive.ItemText>
                  </Primitive.Item>
                ))}
                {!options.length && (
                  <div className="base-choice-empty">{ui.noOptions}</div>
                )}
              </Primitive.Viewport>
              <Primitive.ScrollDownButton className="base-choice-scroll">
                <ChevronDown size={16} />
              </Primitive.ScrollDownButton>
            </Primitive.Content>
          </Primitive.Portal>
        </Primitive.Root>
        <ChoiceFormBridge
          values={[state.value]}
          resetValues={[state.resetValue]}
          options={options}
          name={name}
          form={form}
          required={required}
          disabled={fieldDisabled}
          trigger={trigger}
          onReset={() => {
            state.reset();
            validation.reset();
          }}
          onInvalid={validation.onInvalid}
        />
        {validation.invalid && (
          <span
            id={validation.errorId}
            role="alert"
            className="block text-sm text-danger"
          >
            {validation.message}
          </span>
        )}
      </>
    );
  },
);

export interface MultiSelectProps extends ChoiceFieldProps {
  value?: readonly string[];
  defaultValue?: readonly string[];
  onValueChange?: (values: string[]) => void;
}

export const MultiSelect = forwardRef<HTMLButtonElement, MultiSelectProps>(
  function MultiSelect(
    {
      options,
      value,
      defaultValue = [],
      onValueChange,
      name,
      form,
      required,
      disabled,
      placeholder,
      className,
      ...props
    },
    ref,
  ) {
    const ui = useUiLabels();
    const selectionId = useId();
    const state = useChoiceState<readonly string[]>(value, defaultValue);
    const requiredId = useId();
    const [trigger, setTrigger] = useState<HTMLButtonElement | null>(null);
    const composedRef = useComposedRefs(ref, setTrigger);
    const fieldDisabled = useChoiceDisabled(trigger, disabled);
    const validation = useChoiceValidation(
      state.value,
      required,
      fieldDisabled,
      true,
    );
    const [open, setOpen] = useState(false);
    useEffect(() => {
      if (fieldDisabled) setOpen(false);
    }, [fieldDisabled]);
    const theme = useChoiceTheme(trigger, open);
    const tab = useChoiceTab(trigger, () => setOpen(false));
    const labels = state.value.map(
      (value) =>
        options.find((option) => option.value === value)?.label ??
        `${value} — ${ui.unavailableValue}`,
    );
    const label = labels.length
      ? labels.slice(0, 2).join(", ") +
        (labels.length > 2 ? ` +${labels.length - 2}` : "")
      : (placeholder ?? ui.chooseMany);
    return (
      <>
        {required && (
          <span id={requiredId} aria-hidden="true" className="sr-only">
            {ui.requiredField}
          </span>
        )}
        <span id={selectionId} aria-hidden="true" className="sr-only">
          {labels.length
            ? `${ui.selectedValues}: ${labels.join(", ")}`
            : ui.noneSelected}
        </span>
        <Menu.Root open={open} onOpenChange={setOpen} modal={false}>
          <Menu.Trigger asChild>
            <button
              {...props}
              form={form}
              type="button"
              ref={composedRef}
              disabled={fieldDisabled}
              aria-invalid={
                validation.invalid || props["aria-invalid"] || undefined
              }
              aria-describedby={
                [
                  props["aria-describedby"],
                  selectionId,
                  required ? requiredId : undefined,
                  validation.invalid ? validation.errorId : undefined,
                ]
                  .filter(Boolean)
                  .join(" ") || undefined
              }
              title={props.title ?? labels.join(", ")}
              className={cn("base-control base-choice-trigger", className)}
            >
              <span className="base-choice-summary">{label}</span>
              <ChevronDown size={16} aria-hidden="true" />
            </button>
          </Menu.Trigger>
          <Menu.Portal container={trigger?.ownerDocument.body}>
            <Menu.Content
              aria-labelledby={trigger?.id}
              style={theme}
              className="base-choice-panel base-choice-multiple"
              sideOffset={4}
              collisionPadding={8}
              onCloseAutoFocus={tab.onCloseAutoFocus}
              onKeyDown={tab.onKeyDown}
            >
              {options.map((option) => (
                <Menu.CheckboxItem
                  data-value={option.value}
                  key={option.value}
                  checked={state.value.includes(option.value)}
                  disabled={option.disabled}
                  className="base-choice-option"
                  onSelect={(event) => event.preventDefault()}
                  onCheckedChange={() => {
                    if (fieldDisabled) return;
                    const selected = new Set(state.value);
                    if (selected.has(option.value))
                      selected.delete(option.value);
                    else selected.add(option.value);
                    const next = [
                      ...options
                        .map((item) => item.value)
                        .filter((value) => selected.has(value)),
                      ...state.value.filter(
                        (value) =>
                          selected.has(value) &&
                          !options.some((item) => item.value === value),
                      ),
                    ];
                    state.change(next);
                    onValueChange?.([...next]);
                  }}
                >
                  <Menu.ItemIndicator className="base-choice-indicator">
                    <Check size={16} />
                  </Menu.ItemIndicator>
                  {option.label}
                </Menu.CheckboxItem>
              ))}
              {!options.length && (
                <div className="base-choice-empty">{ui.noOptions}</div>
              )}
            </Menu.Content>
          </Menu.Portal>
        </Menu.Root>
        <ChoiceFormBridge
          multiple
          values={state.value}
          resetValues={state.resetValue}
          options={options}
          name={name}
          form={form}
          required={required}
          disabled={fieldDisabled}
          trigger={trigger}
          onReset={() => {
            state.reset();
            validation.reset();
          }}
          onInvalid={validation.onInvalid}
        />
        {validation.invalid && (
          <span
            id={validation.errorId}
            role="alert"
            className="block text-sm text-danger"
          >
            {validation.message}
          </span>
        )}
      </>
    );
  },
);
