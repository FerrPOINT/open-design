import { usePlatformBranding } from "../lib/platform-branding";
import { BrandingMark } from "../branding/mark";
import { normalizeBranding } from "../branding/normalize";
import { useBrandingPresentation } from "../branding/context";

/**
 * Shared renderer for normalized runtime and isolated controlled presentation.
 */
export function PlatformMark({
  size = "md",
  withName = true,
}: {
  size?: "sm" | "md" | "shell";
  withName?: boolean;
}) {
  const { branding } = usePlatformBranding();
  const presentation = useBrandingPresentation();
  const document = presentation?.document ?? normalizeBranding(branding)!;
  const nameSize = size === "sm" ? "text-xs" : "text-sm";
  return (
    <span className="flex items-center gap-2">
      <span className={size === "shell" ? "base-shell-mark" : undefined}>
        <BrandingMark
          document={document}
          theme={presentation?.theme ?? "dark"}
          size={size === "shell" ? 40 : size === "sm" ? 20 : 24}
        />
      </span>
      {withName && (
        <span className={nameSize + " font-semibold text-text-primary"}>
          {document.product_name}
        </span>
      )}
    </span>
  );
}
