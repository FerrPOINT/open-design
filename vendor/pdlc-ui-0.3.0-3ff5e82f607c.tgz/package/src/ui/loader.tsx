import type { ComponentProps } from 'react'
import { cn } from '../lib/utils'

export interface LoaderProps extends ComponentProps<'span'> {
  size?: 'sm' | 'md' | 'lg'
}

/** Static pending marker for existing consumers. Switch animation belongs to the host. */
export function Loader({ size = 'md', className, ...props }: LoaderProps) {
  const labelled = Boolean(props['aria-label'])
  return (
    <span role={labelled ? 'status' : undefined} aria-hidden={labelled ? undefined : true}
      className={cn('base-pending-status', `base-pending-${size}`, className)} {...props}>
      …
    </span>
  )
}
