import { Toaster as SonnerToaster, toast as sonnerToast } from "sonner";
import type { ToasterProps } from "sonner";
import { useBrandingStyle } from "../lib/branding-scope";
import { useOptionalTheme } from "../lib/theme";
import { useUiLabels } from "./labels";
import { CircleAlert, CircleCheck, TriangleAlert, X } from "lucide-react";
import "./toaster.css";
/** Stable public facade; callers never depend on the notification engine package. */
export const toast: typeof sonnerToast = Object.assign(
  (...args: Parameters<typeof sonnerToast>) => sonnerToast(...args),
  sonnerToast,
);
/** One notification implementation; theme and geometry are inherited from Base tokens. */
export function Toaster({ style, toastOptions, ...props }: ToasterProps) {
  const branding = useBrandingStyle();
  const theme = useOptionalTheme()?.theme ?? "dark";
  const labels = useUiLabels();
  return (
    <SonnerToaster
      className="base-toaster"
      theme={theme === "light" ? "light" : "dark"}
      position="bottom-right"
      expand
      visibleToasts={3}
      offset="var(--shell-page-gutter)"
      mobileOffset="var(--shell-page-gutter)"
      containerAriaLabel={labels.notifications}
      customAriaLabel={labels.notifications}
      icons={{
        close: <X size={16} aria-hidden="true" />,
        success: <CircleCheck size={20} aria-hidden="true" />,
        error: <CircleAlert size={20} aria-hidden="true" />,
        warning: <TriangleAlert size={20} aria-hidden="true" />,
      }}
      closeButton
      {...props}
      style={{ ...branding, ...style }}
      toastOptions={{
        closeButtonAriaLabel: labels.closeNotification,
        ...toastOptions,
      }}
    />
  );
}
