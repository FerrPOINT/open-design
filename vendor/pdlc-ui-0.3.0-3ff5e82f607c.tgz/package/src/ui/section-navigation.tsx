import { Slot } from "@radix-ui/react-slot";
import type { ComponentProps } from "react";
import { cn } from "../lib/utils";

export function SectionNavigation({
  className,
  orientation = "horizontal",
  ...props
}: ComponentProps<"nav"> & { orientation?: "horizontal" | "vertical" }) {
  return (
    <nav
      {...props}
      data-orientation={orientation}
      className={cn("base-section-navigation", className)}
    />
  );
}

/** The consumer supplies its router link; Base owns the selected/focus affordance. */
export function SectionNavigationItem({
  active,
  asChild = false,
  className,
  "aria-current": current,
  ...props
}: ComponentProps<"a"> & { active?: boolean; asChild?: boolean }) {
  const Comp = asChild ? Slot : "a";
  return (
    <Comp
      {...props}
      aria-current={current ?? (active ? "page" : undefined)}
      className={cn("base-section-navigation-item base-control", className)}
    />
  );
}
