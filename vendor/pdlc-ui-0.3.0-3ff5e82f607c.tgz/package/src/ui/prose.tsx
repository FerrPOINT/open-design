import type { ComponentProps } from "react";
import { cn } from "../lib/utils";

export type ProseProps = ComponentProps<"div"> & {
  compact?: boolean;
  preserveLineBreaks?: boolean;
};

/** Visual styles only: parsing, HTML sanitization and link policy remain with the caller. */
export function Prose({
  compact = false,
  preserveLineBreaks = false,
  className,
  ...props
}: ProseProps) {
  return (
    <div
      {...props}
      className={cn("base-prose", className)}
      data-compact={compact || undefined}
      data-preserve-line-breaks={preserveLineBreaks || undefined}
    />
  );
}
