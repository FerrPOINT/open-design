// Generated global contract; implementation is checked against theme-types.
export type { Theme } from './theme-types';
import './theme-types';
