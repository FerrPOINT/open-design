import { useEffect, useRef, useState } from "react";
import { writeClipboardText } from "./clipboard-runtime.js";

/** User-activated clipboard write; no network, persistence, automatic retry or fallback. */
export function useClipboard(
  value: string,
  options: {
    writeText?: (value: string) => Promise<void>;
    onCopied?: () => void;
    onCopyError?: (error: unknown) => void;
  } = {},
) {
  const [pending, setPending] = useState(false);
  const [result, setResult] = useState<{
    value: string;
    status: "copied" | "error";
  }>();
  const busy = useRef(false);
  const mounted = useRef(false);
  const scope = useRef(0);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      scope.current += 1;
    };
  }, []);
  useEffect(() => {
    scope.current += 1;
  }, [value]);

  async function copy() {
    if (busy.current) return false;
    busy.current = true;
    setPending(true);
    setResult(undefined);
    const operationScope = scope.current;
    let failed = false;
    let failure: unknown;
    try {
      await (options.writeText || writeClipboardText)(value);
    } catch (error) {
      failed = true;
      failure = error;
    } finally {
      busy.current = false;
      if (mounted.current) setPending(false);
    }
    // A late result must not acknowledge a different resource or a closed secret dialog.
    if (!mounted.current || scope.current !== operationScope) return false;
    setResult({ value, status: failed ? "error" : "copied" });
    if (failed) options.onCopyError?.(failure);
    else options.onCopied?.();
    return !failed;
  }

  return {
    copy,
    pending,
    status: result?.value === value ? result.status : ("idle" as const),
  };
}
