// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** Enhance one native backing control. Domain data and handlers remain with the caller.
 * @param {HTMLSelectElement} control
 * @param {ChoiceConfig} [config]
 * @returns {ChoiceController}
 */
export function initChoice(control: HTMLSelectElement, config?: ChoiceConfig): ChoiceController;
/** Refresh after programmatic value/options/disabled changes; never emits input/change.
 * @param {HTMLSelectElement} control */
export function refreshChoice(control: HTMLSelectElement): void;
/** Remove an enhancement and restore its native fallback.
 * @param {HTMLSelectElement} control */
export function destroyChoice(control: HTMLSelectElement): void;
export type ChoiceConfig = {
    appearance?: "default" | "icons";
    renderOption?: (option: HTMLOptionElement, mode: "value" | "option") => Node;
};
export type ChoiceController = {
    refresh: () => void;
    destroy: () => void;
};
