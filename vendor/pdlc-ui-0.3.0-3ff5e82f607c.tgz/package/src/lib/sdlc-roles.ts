/** Canonical platform presentation; product API identifiers are adapted by the owner. */
export const sdlcRoleCatalog = [
  { value: 'project_manager', label: 'Project Manager' },
  { value: 'analyst', label: 'Analyst' },
  { value: 'architect', label: 'Architect' },
  { value: 'developer', label: 'Developer' },
  { value: 'reviewer', label: 'Reviewer' },
  { value: 'tester', label: 'Tester' },
  { value: 'devops', label: 'DevOps' },
] as const
export type SdlcPresentationRole = typeof sdlcRoleCatalog[number]['value']
export function sdlcPresentationRoleLabel(role?: string | null) {
  return sdlcRoleCatalog.find(item => item.value === role)?.label ?? '—'
}
