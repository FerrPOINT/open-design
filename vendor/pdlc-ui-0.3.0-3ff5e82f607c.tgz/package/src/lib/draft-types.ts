export interface DraftTicket { readonly revision: number }
export interface DraftTracker {
  edit(): number
  beginSave(): DraftTicket
  finishSave(ticket: DraftTicket, outcome: 'saved' | 'failed' | 'unknown'): void
  reconcile(ticket: DraftTicket, saved: boolean): void
  readonly dirty: boolean
  readonly pending: boolean
  readonly uncertain: boolean
}
