export type Theme = "dark" | "gray" | "light";

declare global {
  interface Window {
    PdlcThemePreference: Window["SdlcThemePreference"];
    SdlcThemePreference: {
      read: (legacyKey?: string, fallback?: Theme) => Theme;
      set: (theme: Theme, legacyKey?: string) => void;
      subscribe: (listener: () => void) => () => void;
    };
  }
}
