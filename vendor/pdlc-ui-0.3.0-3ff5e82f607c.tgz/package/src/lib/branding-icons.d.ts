// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
export const brandingIcons: {
    layers: string;
    box: string;
    compass: string;
    globe: string;
    hexagon: string;
    network: string;
    rocket: string;
    shield: string;
    terminal: string;
    workflow: string;
    cpu: string;
    activity: string;
    leaf: string;
    sparkles: string;
    "circle-dot": string;
    flask: string;
};
