// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/**
 * Resolve context providers from the consuming application, including workspace peers.
 * @returns {string[]}
 */
export function createUiProviderDedupe(): string[];
/** Resolve UI chunks from actual module IDs, without product-owned Radix copies. */
/** @param {Record<string, readonly string[]>} [groups] @returns {(id: string) => string | undefined} */
export function createUiManualChunks(groups?: Record<string, readonly string[]>): (id: string) => string | undefined;
/** Emit the complete font notices beside bundled assets; CSS preprocessors may remove comments.
 * @returns {{name: string, apply: 'build', generateBundle: (this: {emitFile: (asset: {type: 'asset', fileName: string, source: string}) => unknown}) => void}}
 */
export function createUiFontAssetsPlugin(): {
    name: string;
    apply: "build";
    generateBundle: (this: {
        emitFile: (asset: {
            type: "asset";
            fileName: string;
            source: string;
        }) => unknown;
    }) => void;
};
