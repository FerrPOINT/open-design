import { useCallback, useEffect, useState } from 'react'
import {
  parseNamespaceLocation,
  type NamespaceLocation,
} from './namespace-location'

/** Navigation scope is independent of the resource currently open in the tab. */
export function projectNavigationScope(
  search: string,
  pathRef?: NamespaceLocation | null,
) {
  const params = new URLSearchParams(search)
  const queryRef = parseNamespaceLocation(search)
  const supplied =
    params.has('namespace_id') || params.has('registry_instance_id')
  const scopes = params.getAll('project_scope')
  const malformed =
    (supplied && !queryRef) ||
    scopes.length > 1 ||
    (scopes.length === 1 && scopes[0] !== 'all') ||
    Boolean(
      pathRef &&
      queryRef &&
      projectIdentity(pathRef) !== projectIdentity(queryRef),
    )
  const ref = pathRef ?? queryRef
  return { ref, malformed, all: !malformed && (scopes[0] === 'all' || !ref) }
}

export const projectIdentity = (ref: NamespaceLocation) =>
  `${ref.registry_instance_id}/${ref.namespace_id}`

export function sortProjectNavigation<T>(
  items: readonly T[],
  name: (item: T) => string,
  identity: (item: T) => string,
): T[] {
  return [...items].sort(
    (a, b) =>
      name(a).localeCompare(name(b), 'ru', {
        numeric: true,
        sensitivity: 'base',
      }) || identity(a).localeCompare(identity(b)),
  )
}

/** Existing product storage keys are retained; unavailable storage is optional. */
export function useProjectDisclosures(storageKey: string) {
  const [collapsed, setCollapsed] = useState<string[]>(() => {
    try {
      const stored: unknown = JSON.parse(
        localStorage.getItem(storageKey) ?? '[]',
      )
      return Array.isArray(stored)
        ? stored.filter((id): id is string => typeof id === 'string')
        : []
    } catch {
      return []
    }
  })
  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(collapsed))
    } catch {
      /* Optional preference storage. */
    }
  }, [collapsed, storageKey])
  const toggle = useCallback(
    (id: string) =>
      setCollapsed((current) =>
        current.includes(id)
          ? current.filter((value) => value !== id)
          : [...current, id],
      ),
    [],
  )
  return { collapsed, toggle }
}
