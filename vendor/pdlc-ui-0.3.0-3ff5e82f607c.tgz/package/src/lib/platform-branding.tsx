import { useEffect } from "react";
import "../branding/branding.css";
import { normalizeBranding } from "../branding/normalize";
import { BrandingPresentationProvider } from "../branding/context";
import { BrandingDocumentHead } from "../branding/presentation";
import { useOptionalTheme } from "./theme";
import {
  createContext,
  useContext,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  createBrandingRuntime,
  defaultBranding,
  type Branding,
} from "./branding-runtime.js";
export type PlatformBranding = Branding;
export interface PlatformBrandingDocument {
  revision: number;
  updated_at: string;
  branding: PlatformBranding;
}
export { defaultBranding } from "./branding-runtime.js";
interface PlatformBrandingState {
  branding: PlatformBranding;
  revision: number | null;
  source: "runtime" | "cache" | "defaults";
}
interface PlatformBrandingContextValue extends PlatformBrandingState {
  refresh: () => void;
  applyPublished: (
    document: PlatformBrandingDocument,
    etag?: string,
  ) => boolean;
}
const PlatformBrandingContext = createContext<PlatformBrandingContextValue>({
  branding: defaultBranding,
  revision: null,
  source: "defaults",
  refresh: () => undefined,
  applyPublished: () => false,
});
/** React is an adapter to the same document-scoped runtime used by SSR and host. */
export function PlatformProvider({
  configUrl,
  getAccessToken,
  serviceName,
  children,
}: {
  configUrl: string | null;
  getAccessToken?: () => string | null | undefined;
  serviceName?: string;
  children: ReactNode;
}) {
  const [state, setState] = useState<PlatformBrandingState>({
    branding: defaultBranding,
    revision: null,
    source: "defaults",
  });
  const token = useRef(getAccessToken);
  useLayoutEffect(() => {
    token.current = getAccessToken;
  }, [getAccessToken]);
  const runtime = useRef<ReturnType<typeof createBrandingRuntime> | null>(null);
  useLayoutEffect(() => {
    const reader = createBrandingRuntime({
      root: document.documentElement,
      configUrl,
      defaults: defaultBranding,
      getAccessToken: () => token.current?.(),
      onChange: (next) => {
        setState(next);
      },
    });
    runtime.current = reader;
    return () => {
      runtime.current = null;
      reader.dispose();
    };
  }, [configUrl]);
  const value = useMemo(
    () => ({
      ...state,
      applyPublished: (document: PlatformBrandingDocument, etag?: string) =>
        runtime.current?.applyPublished(document, etag) ?? false,
      refresh: () => {
        void runtime.current?.refresh();
      },
    }),
    [state],
  );
  return (
    <PlatformBrandingContext.Provider value={value}>
      <RuntimePresentation branding={state.branding} serviceName={serviceName} confirmed={state.revision !== null}>
        {children}
      </RuntimePresentation>
    </PlatformBrandingContext.Provider>
  );
}
function RuntimePresentation({
  confirmed,
  branding,
  serviceName,
  children,
}: {
  branding: PlatformBranding;
  confirmed: boolean;
  serviceName?: string;
  children: ReactNode;
}) {
  const theme = useOptionalTheme();
  const normalized = useMemo(() => normalizeBranding(branding), [branding]);
  const initial = branding.design?.initial_theme ?? null;
  const setDefault = theme?.setPlatformDefault;
  useEffect(() => {
    setDefault?.(initial);
    return () => setDefault?.(null);
  }, [initial, setDefault]);
  const [fallbackService] = useState(() =>
    typeof document === "undefined"
      ? "Base"
      : document.title.split(/ — | · /)[0] || "Base",
  );
  // Keep the provider topology stable: first publication must not remount consumers or lose forms.
  return (
    <BrandingPresentationProvider
      document={normalized ?? normalizeBranding(defaultBranding)!}
      theme={theme?.theme ?? initial ?? "dark"}
    >
      {confirmed && (
        <BrandingDocumentHead
          serviceName={serviceName ?? fallbackService}
          manageFavicon={false}
        />
      )}
      {children}
    </BrandingPresentationProvider>
  );
}

export function usePlatformBranding(): PlatformBrandingContextValue {
  return useContext(PlatformBrandingContext);
}
