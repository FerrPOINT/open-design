import { useMemo, useSyncExternalStore, type RefObject } from "react";

interface SessionCommand<T> extends RefObject<T | null> {
  readonly command: T | null;
  capture(next: T): T;
  clear(): void;
}

function createSessionCommandStore<T>(key: string) {
  const storageKey = `pdlc:command:${key}`;
  const raw = window.sessionStorage.getItem(storageKey);
  let value: T | null = raw === null ? null : (JSON.parse(raw) as T);
  const listeners = new Set<() => void>();
  const notify = () => listeners.forEach((listener) => listener());
  return {
    getSnapshot: () => value,
    subscribe(listener: () => void) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    capture(next: T): T {
      if (value === null) {
        const serialized = JSON.stringify(next);
        window.sessionStorage.setItem(storageKey, serialized);
        value = JSON.parse(serialized) as T;
        notify();
      }
      return value;
    },
    clear() {
      window.sessionStorage.removeItem(storageKey);
      value = null;
      notify();
    },
  };
}

/** Per-tab journal: persist before sending and clear only after owner readback. No credentials. */
export function useSessionCommand<T>(key: string): SessionCommand<T> {
  const store = useMemo(() => createSessionCommandStore<T>(key), [key]);
  const command = useSyncExternalStore(store.subscribe, store.getSnapshot);
  return {
    command,
    capture: store.capture,
    clear: store.clear,
    // Compatibility for existing callers; new views render the reactive command snapshot.
    get current() {
      return store.getSnapshot();
    },
    set current(next: T | null) {
      if (next === null) store.clear();
      else store.capture(next);
    },
  };
}
