// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** Tracks acknowledgements, not requests: an old response cannot clean a newer edit. */
/** @param {() => void} [onChange] @returns {import("./draft-types").DraftTracker} */
export function createDraftTracker(onChange?: () => void): import("./draft-types").DraftTracker;
export type { DraftTicket, DraftTracker } from './draft-types';
