// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
export function effectiveMark(document: any, theme: any): any;
export function markLetters(document: any, mark: any): string[];
export function markCount(mark: any, compact: any, failed: any): any;
export function markFontSize(count: any, size: any): number;
export function fourLetterOffset(index: any, size: any): {
    x: number;
    y: number;
};
export function brandingFavicon(brand: any, theme: any): Promise<string>;
/** Render only validated mark fields; SVG nodes come from the pinned icon table. */
export function paintBrandingMark(element: any, branding: any, theme: any): void;
