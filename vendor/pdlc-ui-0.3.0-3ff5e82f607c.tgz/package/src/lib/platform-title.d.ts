// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** @param {string} serviceLabel @param { {product_short_name?: string}} [branding] */
export function platformTitle(serviceLabel: string, branding?: {
    product_short_name?: string;
}): string;
export const DEFAULT_PLATFORM_NAME: "PDLC";
