/** Version-independent transport of immutable cross-service context in each tab's URL. */
export interface NamespaceLocation {
  registry_instance_id: string;
  namespace_id: string;
}
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function parseNamespaceLocation(
  search: string,
): NamespaceLocation | null {
  const params = new URLSearchParams(search);
  if (
    params.getAll("registry_instance_id").length !== 1 ||
    params.getAll("namespace_id").length !== 1
  )
    return null;
  const registry = params.get("registry_instance_id");
  const namespace = params.get("namespace_id");
  return registry &&
    namespace &&
    uuid.test(registry) &&
    uuid.test(namespace) &&
    ![registry, namespace].includes("00000000-0000-0000-0000-000000000000")
    ? {
        registry_instance_id: registry.toLowerCase(),
        namespace_id: namespace.toLowerCase(),
      }
    : null;
}
export function withNamespaceLocation(
  url: string,
  context: NamespaceLocation | null,
  navigationSearch?: string,
): string {
  const target = new URL(url, "https://relative.invalid");
  if (navigationSearch !== undefined) {
    const source = new URLSearchParams(navigationSearch);
    target.searchParams.delete("project_scope");
    for (const value of source.getAll("project_scope"))
      target.searchParams.append("project_scope", value);
    if (
      !source.has("project_scope") &&
      !source.has("namespace_id") &&
      !source.has("registry_instance_id")
    )
      target.searchParams.set("project_scope", "all");
  }
  for (const key of ["registry_instance_id", "namespace_id"])
    target.searchParams.delete(key);
  if (context) {
    target.searchParams.set(
      "registry_instance_id",
      context.registry_instance_id,
    );
    target.searchParams.set("namespace_id", context.namespace_id);
  }
  return /^https?:\/\//.test(url)
    ? target.href
    : target.pathname + target.search + target.hash;
}

export { transportNamespaceLocation } from '../platform/bridge.js'
