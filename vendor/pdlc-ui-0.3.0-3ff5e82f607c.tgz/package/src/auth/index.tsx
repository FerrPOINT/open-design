// Shared auth store factory + route guard for Base fleet frontends.
//
// Access tokens stay in memory. The product restores the central HttpOnly
// browser session with authorization-code PKCE before showing a login route.
// Persisted profile fields are display preferences, not proof of authentication.
//
// Usage in a service:
//
//   export const useAuthStore = createAuthStore({ storageKey: 'task-tracker-auth' })
//   export function RequireAuth() {
//     return <SharedRequireAuth store={useAuthStore} refresh={refreshAccessToken} />
//   }
//
// Services with extra fields (fleet-control roles/permissions) extend the
// store via zustand's slice pattern instead of forking this file.

import { useEffect, useState } from 'react'
import { Navigate, Outlet, useLocation } from 'react-router'
import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { isSsoLoginRequired, isSsoNavigationInterruption } from './sso'
import { getPlatformProduct } from '../platform/bridge.js'
import { ErrorState, LoadingState } from '../ui/async-states'
import { PlatformRoute } from '../platform/index'
import { ApplicationAccessProvider, RequireApplicationAccess, ApplicationAccessDenied } from './application-access'
import { ApplicationAccessError } from './application-access-runtime.js'
export { useSsoEntry } from './sso-entry'

export interface AuthProfile {
  userId: string | null
  email: string | null
  username: string | null
  displayName: string | null
}

export interface AuthState extends AuthProfile {
  token: string | null
  /** In-memory fence for late profile responses; never persisted. */
  authVersion?: number
  setAuth: (payload: {
    token: string
    userId: string
    email: string
    username?: string
    displayName?: string
  }) => void
  setUser: (payload: {
    userId?: string
    email?: string
    username?: string
    displayName?: string
  }) => void
  logout: () => void
}

export interface CreateAuthStoreOptions {
  /** localStorage key for the persisted profile (NOT the token). */
  storageKey: string
  /** Keys of other services' stores to purge on read (legacy migrations). */
  legacyKeys?: string[]
}

function readStoredProfile(options: CreateAuthStoreOptions): AuthProfile {
  try {
    for (const legacy of options.legacyKeys ?? []) {
      localStorage.removeItem(legacy)
    }
    const raw = localStorage.getItem(options.storageKey)
    if (!raw) return emptyProfile()
    const parsed = JSON.parse(raw)
    const state = parsed.state ?? parsed
    if (state && typeof state === "object" && "token" in state) {
      const safeState = { ...state }
      delete safeState.token
      localStorage.setItem(
        options.storageKey,
        JSON.stringify(parsed.state ? { ...parsed, state: safeState } : safeState),
      )
    }
    return {
      userId: state.userId ?? state.user_id ?? null,
      email: state.email ?? null,
      username: state.username ?? null,
      displayName: state.displayName ?? state.display_name ?? null,
    }
  } catch {
    try {
      localStorage.removeItem(options.storageKey)
    } catch {
      // Browser storage may be unavailable.
    }
    return emptyProfile()
  }
}

function emptyProfile(): AuthProfile {
  return { userId: null, email: null, username: null, displayName: null }
}



/**
 * Typed hook of the store created by [`createAuthStore`]: a zustand store
 * bound hook. Written structurally so consumers don't need to resolve
 * zustand's own conditional types through a file dependency.
 */
export interface ServiceAuthStore {
  <T>(selector: (state: AuthState) => T): T
  (): AuthState
  getState(): AuthState
  setState(
    partial: Partial<AuthState> | ((state: AuthState) => Partial<AuthState>),
    replace?: boolean,
  ): void
  subscribe(listener: (state: AuthState, prevState: AuthState) => void): () => void
}

/** Creates the fleet-standard auth store (token in memory only). */
export function createAuthStore(options: CreateAuthStoreOptions) {
  const initial = readStoredProfile(options)

  return create<AuthState>()(
    persist(
      (set) => ({
        token: null,
        authVersion: 0,
        userId: initial.userId,
        email: initial.email,
        username: initial.username,
        displayName: initial.displayName,
        setAuth: (payload) =>
          set((state) => ({
            authVersion: (state.authVersion ?? 0) + 1,
            token: payload.token,
            userId: payload.userId,
            email: payload.email,
            username: payload.username ?? null,
            displayName: payload.displayName ?? null,
          })),
        setUser: (payload) =>
          set((state) => ({
            userId: payload.userId ?? state.userId,
            email: payload.email ?? state.email,
            username: payload.username ?? state.username,
            displayName: payload.displayName ?? state.displayName,
          })),
        logout: () => {
          set(state => ({ token: null, authVersion: (state.authVersion ?? 0) + 1, ...emptyProfile() }))
        },
      }),
      {
        name: options.storageKey,
        merge: (persistedState, currentState) => {
          const persisted = (persistedState ?? {}) as Partial<AuthState>
          return {
            ...currentState,
            // Never hydrate the token from disk.
            token: null,
            userId: persisted.userId ?? currentState.userId,
            email: persisted.email ?? currentState.email,
            username: persisted.username ?? currentState.username,
            displayName: persisted.displayName ?? currentState.displayName,
          }
        },
        partialize: (state) => ({
          userId: state.userId,
          email: state.email,
          username: state.username,
          displayName: state.displayName,
        }),
      },
    ),
  )
}

type AnyAuthStore = {
  <T>(selector: (s: AuthState) => T): T
} & {
  getState: () => AuthState
}

export interface RequireAuthProps {
  /** The service auth store hook (created by createAuthStore). */
  store: AnyAuthStore
  /** Attempts the silent refresh once before redirecting. Omit to redirect immediately. */
  refresh?: () => Promise<unknown>
  publicPaths?: string[]
  application?: { issuer: string; key: string }
}

/** Fleet-standard route guard: one silent refresh, then /login. */
export function RequireAuth({
  store,
  refresh,
  publicPaths = ['/login', '/register'],
  application,
}: RequireAuthProps) {
  const token = store((s) => s.token)
  const location = useLocation()
  const isPublicPath = publicPaths.includes(location.pathname)
  const [refreshChecked, setRefreshChecked] = useState(!refresh)
  const [error, setError] = useState<string | null>(null)
  const [forbidden, setForbidden] = useState(false)

  useEffect(() => {
    if (token || isPublicPath || refreshChecked) return

    let active = true
    void refresh?.().then(() => {
      if (active) { setForbidden(false); setError(null); setRefreshChecked(true) }
    }).catch(caught => {
      if (!active || isSsoNavigationInterruption(caught)) return
      if (caught instanceof ApplicationAccessError && caught.status === 403) setForbidden(true)
      if (!isSsoLoginRequired(caught)) setError(caught instanceof Error ? caught.message : 'Не удалось проверить вход.')
      setRefreshChecked(true)
    })
    return () => {
      active = false
    }
  }, [isPublicPath, refreshChecked, refresh, token])

  useEffect(() => {
    if (error) getPlatformProduct()?.readiness({ ready: false, error })
  }, [error])
  useEffect(() => {
    if (!token && !isPublicPath && refreshChecked && !error) getPlatformProduct()?.requireLogin(location.pathname + location.search + location.hash)
  }, [token, isPublicPath, refreshChecked, error, location])

  if (!token && forbidden) return <PlatformRoute><ApplicationAccessDenied onRetry={() => {setForbidden(false);setError(null);setRefreshChecked(false)}} /></PlatformRoute>
  if (!token && error) return <ErrorState message={error} onRetry={() => { setError(null); setRefreshChecked(false) }} />

  if (!token && !isPublicPath && refreshChecked) {
    if (getPlatformProduct()) {
      return null
    }
    return <Navigate to="/login" state={{ from: location }} replace />
  }

  if (!token && !isPublicPath) return <LoadingState />

  if (token && application && !isPublicPath) return <ApplicationAccessProvider issuer={application.issuer} token={token} onSessionExpired={() => {
    const product = getPlatformProduct()
    if (product) product.recheckAuthorization()
    else {setRefreshChecked(false);store.getState().logout()}
  }}><RequireApplicationAccess application={application.key}><Outlet /></RequireApplicationAccess></ApplicationAccessProvider>
  return <Outlet />
}

export * from './application-access-runtime.js'

export * from './application-access'
