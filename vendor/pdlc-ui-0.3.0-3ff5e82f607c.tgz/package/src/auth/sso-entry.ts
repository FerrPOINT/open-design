import { useCallback, useEffect, useRef, useState } from 'react'
import { beginSso, isSsoNavigationInterruption, type SsoConfig } from './sso'
import { useUiLabels } from '../ui/labels'

/** Product auth adapters supply identity and return paths; Base owns the SSO interaction. */
export function useSsoEntry({ config, returnTo, autoStart }: { config: SsoConfig; returnTo: string; autoStart: boolean }) {
  const labels = useUiLabels()
  const [pending, setPending] = useState(autoStart)
  const [error, setError] = useState<string | null>(null)
  const inFlight = useRef(false)
  const started = useRef('')
  const context = useRef('')
  const generation = useRef(0)
  const mounted = useRef(false)
  useEffect(() => { mounted.current = true; return () => { mounted.current = false } }, [])
  const start = useCallback((interactive: boolean) => {
    if (inFlight.current) return
    inFlight.current = true
    const attempt = ++generation.current
    setPending(true); setError(null)
    const navigation = interactive ? beginSso(config, returnTo, { interactive: true }) : beginSso(config, returnTo)
    void navigation.then(
      () => { if (mounted.current && attempt === generation.current) { inFlight.current = false; setPending(false) } },
      cause => {
        if (!mounted.current || attempt !== generation.current) return
        inFlight.current = false; setPending(false)
        setError(isSsoNavigationInterruption(cause) ? null : labels.loginUnavailable)
      },
    )
  }, [config, returnTo, labels.loginUnavailable])
  useEffect(() => {
    const key = JSON.stringify([config.issuer, config.clientId, returnTo])
    if (context.current !== key) {
      context.current = key
      generation.current++
      inFlight.current = false
      setError(null)
      setPending(false)
    }
    if (!autoStart) {
      if (started.current) { generation.current++; inFlight.current = false; setPending(false); setError(null) }
      started.current = ''; return
    }
    if (started.current === key) return
    started.current = key
    start(false)
  }, [autoStart, config.issuer, config.clientId, returnTo, start])
  return { pending, error, signIn: () => start(true) }
}
