import {
  createContext,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useCallback,
  useRef,
  useState,
  useSyncExternalStore,
  Fragment,
  type ReactNode,
} from "react";
import { useStore } from "zustand";
import { createStore } from "zustand/vanilla";
import { Button } from "../ui/button";
import { TextLink } from "../ui/text-link";
import { EmptyState, ErrorState, LoadingState } from "../ui/async-states";
import { clearPlatformPrivateQueries, PlatformRoute } from "../platform/index";
import { getPlatformProduct } from "../platform/bridge.js";
import {
  applicationAccessBoundary,
  ApplicationAccessError,
  browserTokenIdentity,
  loadApplicationAccess,
  permitsApplication,
  type ConfirmedApplicationAccess,
} from "./application-access-runtime.js";

type AccessStatus =
  "loading" | "active" | "unavailable" | "signed-out" | "denied";
interface AccessState {
  scope: string;
  access: ConfirmedApplicationAccess | null;
  status: AccessStatus;
  error: string | null;
}
interface AccessContextValue {
  status: AccessStatus;
  access: ConfirmedApplicationAccess | null;
  error: string | null;
  retry: () => void;
  permits: (
    applications: readonly string[],
    administrative?: boolean,
  ) => boolean;
}
const AccessContext = createContext<AccessContextValue | null>(null);

/** React observes the monotonic deadline even when a background timer is delayed. */
function useAccessFreshness(deadline: number | undefined) {
  const subscribe = useCallback(
    (changed: () => void) => {
      if (deadline === undefined) return () => {};
      const timer = setTimeout(
        changed,
        Math.max(0, deadline - performance.now()),
      );
      return () => clearTimeout(timer);
    },
    [deadline],
  );
  const snapshot = useCallback(
    () => deadline !== undefined && deadline > performance.now(),
    [deadline],
  );
  return useSyncExternalStore(subscribe, snapshot, () => false);
}
export function useApplicationAccess() {
  return useContext(AccessContext);
}

/** One owner read/clock for the mounted product; no permissions are persisted. */
export function ApplicationAccessProvider({
  issuer,
  token,
  children,
  onBoundaryChange,
  onSessionExpired,
}: {
  issuer: string;
  token: string | null;
  children: ReactNode;
  onBoundaryChange?: () => void;
  onSessionExpired?: () => void;
}) {
  const identity = useMemo(
    () => (token ? browserTokenIdentity(token) : null),
    [token],
  );
  const scope = JSON.stringify([issuer, identity?.subject ?? null]);
  // Owner responses and cache retirement form one external lifecycle. Keep the
  // confirmed snapshot and its accepted boundary local to this mounted provider.
  const [store] = useState(() =>
    createStore<{
      state: AccessState;
      accepted: string;
    }>(() => ({
      state: { scope, access: null, status: "loading", error: null },
      accepted: JSON.stringify([scope, "closed"]),
    })),
  );
  const { state, accepted } = useStore(store);
  const setState = useCallback(
    (state: AccessState) => store.setState({ state }),
    [store],
  );
  const latest = useRef<{
    scope: string;
    access: ConfirmedApplicationAccess | null;
    denied: boolean;
  }>({ scope, access: null, denied: false });
  const callbacks = useRef({ onBoundaryChange, onSessionExpired });
  useLayoutEffect(() => {
    callbacks.current = { onBoundaryChange, onSessionExpired };
  }, [onBoundaryChange, onSessionExpired]);
  const [nonce, setNonce] = useState(0);
  const retry = () => setNonce((value) => value + 1);
  useEffect(() => {
    let active = true;
    let refreshing = false;
    let refreshTimer: ReturnType<typeof setTimeout> | undefined;
    let expiryTimer: ReturnType<typeof setTimeout> | undefined;
    const requests = new Set<AbortController>();
    const current = () =>
      latest.current.scope === scope &&
      !latest.current.denied &&
      latest.current.access &&
      latest.current.access.deadline > performance.now() &&
      identity
        ? latest.current.access
        : null;
    const expire = () => {
      if (active)
        setState({
          scope,
          access: null,
          status: "unavailable",
          error: "Не удалось подтвердить актуальные права. Повторите проверку.",
        });
    };
    function arm(
      access: ConfirmedApplicationAccess,
      retryAfter?: number | null,
    ) {
      clearTimeout(refreshTimer);
      clearTimeout(expiryTimer);
      // The confirmed monotonic deadline already intersects owner/token expiry.
      const remaining = access.deadline - performance.now();
      expiryTimer = setTimeout(expire, Math.max(0, remaining));
      const delay =
        retryAfter === null
          ? null
          : (retryAfter ?? Math.min(30000, remaining - 1000));
      if (delay !== null && delay > 0 && delay < remaining)
        refreshTimer = setTimeout(() => void refresh(), delay);
    }
    async function refresh() {
      if (!token || !identity || !active || refreshing) return;
      refreshing = true;
      const controller = new AbortController();
      requests.add(controller);
      try {
        const access = await loadApplicationAccess(
          issuer,
          token,
          identity.subject,
          identity.expiresAt,
          controller.signal,
        );
        if (!active) return;
        const previous =
          latest.current.scope === scope ? latest.current.access : null;
        if (previous && access.decision.revision < previous.decision.revision) {
          const confirmed = current();
          if (confirmed) arm(confirmed, 5000);
          else expire();
          return;
        }
        latest.current = { scope, access, denied: false };
        setState({ scope, access, status: "active", error: null });
        arm(access);
      } catch (error) {
        if (!active) return;
        const confirmed = current();
        if (error instanceof ApplicationAccessError && error.status === 401) {
          setState({
            scope,
            access: null,
            status: "unavailable",
            error: "Не удалось подтвердить сессию.",
          });
          latest.current.denied = true;
          callbacks.current.onSessionExpired?.();
        } else if (
          error instanceof ApplicationAccessError &&
          error.status === 403
        ) {
          latest.current.denied = true;
          clearTimeout(refreshTimer);
          clearTimeout(expiryTimer);
          setState({ scope, access: null, status: "denied", error: null });
        } else if (
          confirmed &&
          error instanceof ApplicationAccessError &&
          error.status >= 400 &&
          error.status < 500
        ) {
          // Preserve only the original confirmation; client errors do not auto-retry.
          arm(confirmed, null);
        } else if (confirmed) {
          // An outage does not renew the old proof; its expiry timer stays armed.
          arm(confirmed, 5000);
        } else {
          setState({
            scope,
            access: null,
            status: "unavailable",
            error: "Не удалось проверить доступ к приложениям.",
          });
        }
      } finally {
        requests.delete(controller);
        refreshing = false;
      }
    }
    if (latest.current.scope !== scope)
      latest.current = { scope, access: null, denied: false };
    const previous = current();
    if (previous) arm(previous);
    else
      setState({
        scope,
        access: null,
        status: token ? "loading" : "signed-out",
        error: null,
      });
    if (token && !identity)
      setState({
        scope,
        access: null,
        status: "unavailable",
        error: "Не удалось подтвердить сессию.",
      });
    else void refresh();
    const focus = () => {
      if (!current()) expire();
      void refresh();
    };
    const visible = () => {
      if (document.visibilityState === "visible") focus();
    };
    const restored = (event: PageTransitionEvent) => {
      if (!event.persisted || !active) return;
      // A frozen page must re-confirm before restoring private content. Discard
      // pre-freeze requests even if they finish before React runs effect cleanup.
      active = false;
      clearTimeout(refreshTimer);
      clearTimeout(expiryTimer);
      for (const request of requests) request.abort();
      latest.current.denied = true;
      clearPlatformPrivateQueries();
      setState({ scope, access: null, status: "loading", error: null });
      setNonce((value) => value + 1);
    };
    window.addEventListener("pageshow", restored);
    window.addEventListener("focus", focus);
    document.addEventListener("visibilitychange", visible);
    return () => {
      active = false;
      clearTimeout(refreshTimer);
      clearTimeout(expiryTimer);
      for (const request of requests) request.abort();
      window.removeEventListener("focus", focus);
      window.removeEventListener("pageshow", restored);
      document.removeEventListener("visibilitychange", visible);
    };
  }, [issuer, token, identity, scope, nonce, setState]);
  const fresh = useAccessFreshness(state.access?.deadline);
  const access =
    state.scope === scope && token && identity && state.access && fresh
      ? state.access
      : null;
  const boundary = access
    ? applicationAccessBoundary(access)
    : JSON.stringify([scope, "closed"]);
  useLayoutEffect(() => {
    if (accepted === boundary) return;
    clearPlatformPrivateQueries();
    callbacks.current.onBoundaryChange?.();
    store.setState({ accepted: boundary });
  }, [accepted, boundary, store]);
  const settled = accepted === boundary;
  const value: AccessContextValue = {
    access: settled ? access : null,
    status:
      !settled || state.scope !== scope
        ? "loading"
        : state.status === "active" && !access
          ? "unavailable"
          : state.status,
    error: state.error,
    retry,
    permits: (applications, administrative = false) =>
      settled && permitsApplication(access, applications, administrative),
  };
  return (
    <AccessContext.Provider value={value}>
      <Fragment key={boundary}>
        {settled ? children : <LoadingState />}
      </Fragment>
    </AccessContext.Provider>
  );
}

export function ApplicationAccessDenied({
  administrative = false,
  onRetry,
}: {
  administrative?: boolean;
  onRetry?: () => void;
}) {
  const product = getPlatformProduct();
  const account = product?.services.find(
    (service) => service.key === "admin-panel",
  );
  return (
    <EmptyState
      message="Нет доступа"
      description={
        administrative
          ? "Этот раздел доступен администратору."
          : "Для работы с приложением обратитесь к администратору."
      }
      action={
        <div className="flex items-center gap-3">
          {onRetry && (
            <Button type="button" variant="outline" onClick={onRetry}>
              Проверить доступ
            </Button>
          )}
          {account && product && (
            <TextLink href={product.portalOrigin + account.path + "tokens"}>
              Личный аккаунт
            </TextLink>
          )}
        </div>
      }
    />
  );
}
export function RequireApplicationAccess({
  application,
  children,
}: {
  application: string;
  children: ReactNode;
}) {
  const access = useApplicationAccess();
  if (!access || access.status === "loading") return <LoadingState />;
  if (access.status === "unavailable" || access.status === "signed-out")
    return (
      <ErrorState
        message={access.error ?? "Не удалось проверить доступ."}
        onRetry={access.retry}
      />
    );
  if (access.status === "denied" || !access.permits([application]))
    return (
      <PlatformRoute>
        <ApplicationAccessDenied onRetry={access.retry} />
      </PlatformRoute>
    );
  return children;
}
export function RequireAdministrator({ children }: { children: ReactNode }) {
  const access = useApplicationAccess();
  if (!access || access.status === "loading") return <LoadingState />;
  return access.permits([], true) ? (
    children
  ) : (
    <ApplicationAccessDenied administrative />
  );
}
