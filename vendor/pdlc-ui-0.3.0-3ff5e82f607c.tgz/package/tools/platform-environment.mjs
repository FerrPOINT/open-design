/** Resolve canonical build/QA configuration without exposing values in errors. */
/** @param {string} suffix @param {Record<string, string | undefined>} [environment] */
export function platformEnv(suffix, environment = process.env) {
  const canonical = environment["PDLC_" + suffix];
  const legacy = environment["SDLC_" + suffix];
  if (canonical !== undefined && legacy !== undefined && canonical !== legacy)
    throw new Error("Conflicting PDLC/SDLC environment aliases: " + suffix);
  return canonical ?? legacy;
}
