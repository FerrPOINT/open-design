// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/** Resolve canonical build/QA configuration without exposing values in errors. */
/** @param {string} suffix @param {Record<string, string | undefined>} [environment] */
export function platformEnv(suffix: string, environment?: Record<string, string | undefined>): string;
