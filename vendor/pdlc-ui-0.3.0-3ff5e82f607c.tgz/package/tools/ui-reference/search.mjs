/**
 * Search the generated index without loading component cards. Also used by the catalog.
 * @param {Array<{component: string, exports: string[], keywords: string[], description: string, group: string, storyId: string, importPath?: string, kind?: string, topic?: string}>} index
 * @param {string} query
 * @param {number} limit
 * @param {{kind?: string, group?: string, topic?: string}} filters
 */
export function search(index, query, limit = 3, filters = {}) {
  if (
    filters.kind &&
    ![
      "component",
      "api",
      "mechanism",
      "hook",
      "function",
      "class",
      "type",
      "constant",
    ].includes(filters.kind)
  )
    throw new Error("Unknown export kind.");
  /** @param {string} value */
  const normalize = (value) =>
    value.normalize("NFKC").toLocaleLowerCase("ru").replaceAll("ё", "е");
  const needle = normalize(query.trim());
  if (!needle) return [];
  const words = needle.split(/[^\p{L}\p{N}_]+/u).filter(Boolean);
  if (!words.length) return [];
  return index
    .filter((entry) => {
      const kind = entry.kind ?? "component";
      return (
        (!filters.group || filters.group === entry.group) &&
        (!filters.topic || filters.topic === entry.topic) &&
        (!filters.kind ||
          (filters.kind === "api"
            ? kind !== "component"
            : filters.kind === "mechanism"
              ? ["hook", "function", "class"].includes(kind)
              : filters.kind === kind))
      );
    })
    .flatMap((entry) => {
      const exact = entry.exports.find((name) => normalize(name) === needle);
      const names = normalize(entry.exports.join(" "));
      const tags = normalize(entry.keywords.join(" "));
      const text = normalize(`${entry.description} ${entry.group}`);
      if (
        !exact &&
        !words.every((word) => `${names} ${tags} ${text}`.includes(word))
      )
        return [];
      const score = exact
        ? 1000
        : (tags.includes(needle) ? 100 : 0) +
          words.reduce(
            (sum, word) =>
              sum + (names.includes(word) ? 20 : tags.includes(word) ? 10 : 1),
            0,
          );
      return [
        {
          name: exact ?? entry.component,
          family: entry.component,
          ...(entry.importPath
            ? { address: `${entry.importPath}#${exact ?? entry.component}` }
            : {}),
          description: entry.description,
          storyId: entry.storyId,
          score,
          reason: exact
            ? "Точное имя экспорта"
            : tags.includes(needle)
              ? "Совпадение с задачей"
              : "Совпадение по словам запроса",
        },
      ];
    })
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name, "en"))
    .slice(0, limit);
}
