// Generated from checked JavaScript/JSDoc by runtime-declarations.mjs.
/**
 * Search the generated index without loading component cards. Also used by the catalog.
 * @param {Array<{component: string, exports: string[], keywords: string[], description: string, group: string, storyId: string, importPath?: string, kind?: string, topic?: string}>} index
 * @param {string} query
 * @param {number} limit
 * @param {{kind?: string, group?: string, topic?: string}} filters
 */
export function search(index: Array<{
    component: string;
    exports: string[];
    keywords: string[];
    description: string;
    group: string;
    storyId: string;
    importPath?: string;
    kind?: string;
    topic?: string;
}>, query: string, limit?: number, filters?: {
    kind?: string;
    group?: string;
    topic?: string;
}): {
    description: string;
    storyId: string;
    score: number;
    reason: string;
    address?: string;
    name: string;
    family: string;
}[];
