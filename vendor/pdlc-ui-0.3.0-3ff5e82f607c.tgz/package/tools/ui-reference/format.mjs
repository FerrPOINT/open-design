function bullet(values) {
  return values.length ? values.map((value) => `- ${value}`).join("\n") : "—";
}

export function section(card, name = "summary") {
  const shared = {
    name: card.name,
    family: card.family,
    kind: card.kind ?? "component",
  };
  if (name === "all") return card;
  if (name === "props")
    return {
      ...shared,
      props: card.props.filter((prop) => !prop.inherited),
      inheritedPropCount: card.props.filter((prop) => prop.inherited).length,
      definitions: card.definitions,
      ...(card.returns ? { returns: card.returns } : {}),
      ...(card.documentation ? { documentation: card.documentation } : {}),
      ...(["type", "constant"].includes(card.kind)
        ? { definition: card.definition, documentation: card.documentation }
        : {}),
    };
  if (name === "setup")
    return {
      ...shared,
      import: card.import,
      setup: card.setup,
      constraints: card.constraints,
      ssr: card.ssr,
    };
  if (name === "usage")
    return {
      ...shared,
      examples: card.examples,
      related: card.related,
      storyId: card.storyId,
      guide: card.guide,
    };
  if (name !== "summary")
    throw new Error(
      `Unknown section: ${name}. Available: props, setup, usage, all.`,
    );
  return {
    ...shared,
    description: card.description,
    import: card.import,
    setup: card.setup,
    required: card.props
      .filter((prop) => prop.required)
      .map(({ name, type }) => ({ name, type })),
    constraints: card.constraints,
    ...(card.kind && card.kind !== "component"
      ? { signature: card.signature.slice(0, 1200), guide: card.guide }
      : {}),
    examples: card.examples.map(({ id, description }) => ({ id, description })),
  };
}

export function formatCard(card, name = "summary") {
  const value = section(card, name);
  const lines = [
    `${value.name}${value.family !== value.name ? ` (${value.family})` : ""}`,
  ];
  if (value.description) lines.push(value.description);
  if (value.import) lines.push(value.import);
  if (value.signature) lines.push(`Контракт: ${value.signature}`);
  if (value.guide) lines.push(`Руководство: ${value.guide}`);
  if (name === "summary" && ["type", "constant"].includes(value.kind))
    lines.push(`Полный контракт: pdlc-ui show ${value.name} --section props.`);
  if (value.returns) lines.push(`Результат: ${value.returns}`);
  if (value.definition) lines.push(`Определение:\n${value.definition}`);
  if (value.documentation) lines.push(value.documentation);
  if (value.setup) lines.push("Подключение:\n" + bullet(value.setup));
  if (value.required)
    lines.push(
      "Обязательные параметры:\n" +
        bullet(value.required.map((prop) => `${prop.name}: ${prop.type}`)),
    );
  if (value.constraints)
    lines.push("Ограничения:\n" + bullet(value.constraints));
  if (value.props) {
    const props =
      name === "all"
        ? value.props
        : value.props.filter((prop) => !prop.inherited);
    lines.push(
      "Параметры:\n" +
        bullet(
          props.map(
            (prop) =>
              `${prop.name}${prop.required ? "" : "?"}: ${prop.type}${"default" in prop ? ` = ${prop.default}` : ""}${prop.description ? ` — ${prop.description}` : ""}`,
          ),
        ),
    );
    if (value.inheritedPropCount)
      lines.push(
        `Наследуемые DOM/Radix параметры: ${value.inheritedPropCount}. Полный контракт: show ${value.name} --section all.`,
      );
    if (Object.keys(value.definitions ?? {}).length)
      lines.push(
        "Типы Base:\n" + Object.values(value.definitions).join("\n\n"),
      );
  }
  if (value.examples)
    lines.push(
      "Примеры:\n" +
        bullet(
          value.examples.map(
            (example) => `${example.id}: ${example.description}`,
          ),
        ),
    );
  if ("ssr" in value)
    lines.push(
      value.ssr
        ? `SSR: ${value.ssr.source} :: ${value.ssr.macro}; ${value.ssr.exportCommand}`
        : "SSR: прямого аналога нет.",
    );
  if (value.related?.length)
    lines.push(`См. также: ${value.related.join(", ")}`);
  if (value.storyId) lines.push(`Story: ${value.storyId}`);
  return lines.join("\n\n");
}

export function formatSearch(results) {
  return results.length
    ? results
        .map(
          (result) =>
            `${result.name} — ${result.description}\n  ${result.reason}; pdlc-ui show ${result.address ? `'${result.address}'` : result.name}`,
        )
        .join("\n")
    : "Ничего не найдено. Измените запрос или укажите публичное имя компонента.";
}
