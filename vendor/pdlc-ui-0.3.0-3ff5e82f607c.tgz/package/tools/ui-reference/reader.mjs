import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

export const uiRoot = path.resolve(
  fileURLToPath(new URL("../../", import.meta.url)),
);
const root = path.join(uiRoot, "reference");
export const readText = (file) =>
  fs.readFileSync(file, "utf8").replaceAll("\r\n", "\n");
const digest = (content) =>
  crypto.createHash("sha256").update(content).digest("hex");

/** pnpm pack rewrites publishing metadata; compare the installed package contract. */
export function sourceContent(relative, text) {
  if (/\.woff2$/.test(relative)) return text;
  if (Buffer.isBuffer(text)) text = text.toString("utf8");
  if (relative !== "package.json") return text.replaceAll("\r\n", "\n");
  const pkg = JSON.parse(text);
  return JSON.stringify(
    Object.fromEntries(
      [
        "name",
        "version",
        "type",
        "main",
        "exports",
        "bin",
        "dependencies",
        "peerDependencies",
      ].map((key) => [key, pkg[key]]),
    ),
  );
}

function referenceFile(relative) {
  const file = path.resolve(root, relative);
  if (!file.startsWith(root + path.sep))
    throw new Error("Invalid reference path.");
  return file;
}
export function manifest() {
  const result = JSON.parse(readText(referenceFile("manifest.json")));
  if (![1, 2].includes(result.schemaVersion))
    throw new Error(`Unsupported UI reference schema: ${result.schemaVersion}`);
  return result;
}
export function index() {
  manifest();
  return JSON.parse(readText(referenceFile("index.json")));
}
export function card(name) {
  const info = manifest();
  const file = referenceFile(resolveCardAddress(info, name));
  if (!fs.existsSync(file))
    throw new Error(`Unknown component: ${name}. Use pdlc-ui search <query>.`);
  const result = JSON.parse(readText(file));
  if (![1, 2].includes(result.schemaVersion))
    throw new Error(`Unsupported component schema: ${result.schemaVersion}`);
  return result;
}
export function resolveCardAddress(info, name) {
  if (info.schemaVersion === 1) {
    if (!/^[A-Z][A-Za-z0-9]*$/.test(name))
      throw new Error(
        "Component names are case-sensitive public export names.",
      );
    return `components/${name}.json`;
  }
  const entries = Object.entries(info.addresses ?? {});
  const candidates = name.includes("#")
    ? entries.filter(([qualified]) => qualified === name)
    : entries.filter(
        ([qualified]) =>
          qualified.slice(qualified.lastIndexOf("#") + 1) === name,
      );
  const files = [...new Set(candidates.map(([, file]) => file))];
  if (files.length > 1)
    throw new Error(
      `Ambiguous public name: ${name}. Use ${candidates.map(([qualified]) => qualified).join(", ")}`,
    );
  if (!files.length)
    throw new Error(
      `Unknown public export: ${name}. Use pdlc-ui search <query>.`,
    );
  return files[0];
}
export function example(name, id) {
  const info = card(name);
  const found = info.examples.find(
    (item) => item.id === (id ?? info.examples[0]?.id),
  );
  if (!found)
    throw new Error(
      `Unknown example: ${id}. Available: ${info.examples.map((item) => item.id).join(", ")}`,
    );
  return {
    component: name,
    id: found.id,
    setup: info.setup,
    code: readText(referenceFile(found.file)),
  };
}
export function recipe(id) {
  const found = manifest().recipes.find((item) => item.id === id);
  if (!found)
    throw new Error(
      `Unknown recipe: ${id}. Use pdlc-ui example recipes to list recipes.`,
    );
  return {
    recipe: id,
    setup: found.setup,
    code: readText(referenceFile(found.file)),
  };
}
export function check() {
  const info = manifest();
  const errors = [];
  for (const [relative, expected] of Object.entries(info.files)) {
    const file = referenceFile(relative);
    if (!fs.existsSync(file) || digest(readText(file)) !== expected)
      errors.push(`Changed reference: ${relative}`);
  }
  // Authoring inputs live in a sibling application, outside the published UI package.
  const authoringRoot = path.resolve(uiRoot, "../../components-dictionary");
  const authoring = fs.existsSync(path.join(authoringRoot, "src/components"));
  const sourceFiles = Object.entries(info.sourceFiles);
  for (const [relative, expected] of sourceFiles) {
    const file = path.resolve(uiRoot, relative);
    if (!file.startsWith(uiRoot + path.sep))
      throw new Error("Invalid source path in manifest.");
    if (
      !fs.existsSync(file) ||
      digest(sourceContent(relative, fs.readFileSync(file))) !== expected
    )
      errors.push(`Changed UI input: ${relative}`);
  }
  const authoringFiles = authoring
    ? Object.entries(info.authoringFiles ?? {})
    : [];
  for (const [relative, expected] of authoringFiles) {
    const file = path.resolve(authoringRoot, relative);
    if (!file.startsWith(authoringRoot + path.sep))
      throw new Error("Invalid authoring path in manifest.");
    if (!fs.existsSync(file) || digest(readText(file)) !== expected)
      errors.push(`Changed dictionary input: ${relative}`);
  }
  if (errors.length) throw new Error(errors.join("\n"));
  return {
    ok: true,
    sourceScope: authoring ? "full" : "installed-ui",
    schemaVersion: info.schemaVersion,
    sourceFingerprint: info.sourceFingerprint,
    componentCount: info.componentCount,
    ...(info.schemaVersion === 2 ? { apiCount: info.apiCount } : {}),
    checkedFiles:
      Object.keys(info.files).length +
      sourceFiles.length +
      authoringFiles.length,
  };
}
