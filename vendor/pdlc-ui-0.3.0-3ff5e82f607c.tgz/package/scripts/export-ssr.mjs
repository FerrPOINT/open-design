import { readFileSync, mkdirSync, writeFileSync, readdirSync } from "node:fs";
import { resolve, dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createHash } from "node:crypto";
import postcss from "postcss";

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const sourceText = (path) =>
  readFileSync(path, "utf8").replaceAll("\r\n", "\n");
export function themeTokens() {
  const css = postcss.parse(ssrFiles()["base-ui.css"]);
  return (
    css.nodes
      .filter(
        (node) =>
          node.type === "rule" &&
          (node.selectors.includes(":root") ||
            node.selector.startsWith("[data-theme=")),
      )
      .map((node) => node.toString())
      .join("\n") + "\n"
  );
}
export function authThemeStyles() {
  return (
    themeTokens() +
    sourceText(join(packageRoot, "ssr/auth.css")) +
    sourceText(join(packageRoot, "src/ui/fonts.css")).replaceAll(
      "./fonts/",
      "/auth/ui-fonts/",
    )
  );
}
export function loaderStyles() {
  return sourceText(join(packageRoot, "ssr/loader.css"));
}
/** Source assets owned by the UI package; the platform application only assembles them. */
export function platformSources() {
  return Object.fromEntries(
    [
      ["bridge.js", "src/platform/bridge.js"],
      ["host.js", "src/platform/host.js"],
      ["loading.js", "src/platform/loading.js"],
      ["platform-title.js", "src/lib/platform-title.js"],
      ["theme-preference.js", "src/lib/theme-preference.js"],
    ].map(([name, file]) => [name, sourceText(join(packageRoot, file))]),
  );
}
export function ssrFiles() {
  const css = postcss.parse(sourceText(join(packageRoot, "src/ui/tokens.css")));
  css.walkAtRules("import", (rule) => {
    const asset = rule.params.replace(/["']/g, "");
    if (!["./design-tokens.css", "./fonts.css"].includes(asset))
      throw Error("Unknown Base CSS import: " + asset);
    rule.replaceWith(
      postcss.parse(sourceText(join(packageRoot, "src/ui", asset))).nodes,
    );
  });
  css.walkAtRules("theme", (node) => {
    node.replaceWith(
      postcss.rule({
        selector: ":root",
        nodes: node.nodes.map((child) => child.clone()),
      }),
    );
  });
  const files = {
    "base-ui.css":
      css.toString() + "\n" + sourceText(join(packageRoot, "ssr/legacy.css")),
    "base-ui.js": sourceText(join(packageRoot, "ssr/base-ui.js")),
    "theme-preference.js": sourceText(
      join(packageRoot, "src/lib/theme-preference.js"),
    ),
    "macros.html": sourceText(join(packageRoot, "ssr/macros.html")),
  };
  files["branding-colors.js"] = sourceText(
    join(packageRoot, "src/lib/branding-colors.js"),
  );
  files["branding-icons.js"] = sourceText(
    join(packageRoot, "src/lib/branding-icons.js"),
  );
  files["branding-marks.js"] = sourceText(
    join(packageRoot, "src/lib/branding-marks.js"),
  );
  files["branding-runtime.js"] = sourceText(
    join(packageRoot, "src/lib/branding-runtime.js"),
  );
  files["platform-title.js"] = sourceText(
    join(packageRoot, "src/lib/platform-title.js"),
  );
  files["branding-bootstrap.js"] =
    "(function(){\n" +
    files["platform-title.js"].replace(/^export /gm, "") +
    "\n" +
    files["branding-colors.js"].replace(/^export /gm, "") +
    "\nconst hex = isHex;\n" +
    files["branding-icons.js"].replace(/^export /gm, "") +
    "\n" +
    files["branding-marks.js"]
      .replace(/^import .*\n/gm, "")
      .replace(/^export /gm, "") +
    "\n" +
    files["branding-runtime.js"]
      .replace(/^import .*\n/gm, "")
      .replace(/^export /gm, "") +
    "\nwindow.PdlcBranding={createBrandingRuntime,resolveBrandingTokens,normalizeBranding,defaultBranding,defaultDesign};\n})();\n";
  files["choice-runtime.js"] = sourceText(
    join(packageRoot, "src/lib/choice-runtime.js"),
  );
  files["clipboard-runtime.js"] = sourceText(
    join(packageRoot, "src/lib/clipboard-runtime.js"),
  );
  files["textarea-runtime.js"] = sourceText(
    join(packageRoot, "src/lib/textarea-runtime.js"),
  );
  files["draft-state.js"] = sourceText(
    join(packageRoot, "src/lib/draft-state.js"),
  );
  files["platform-bridge.js"] = sourceText(
    join(packageRoot, "src/platform/bridge.js"),
  );
  files["platform-ssr.js"] = sourceText(
    join(packageRoot, "ssr/platform-ssr.js"),
  );
  files["platform-navigation.js"] = sourceText(
    join(packageRoot, "ssr/platform-navigation.js"),
  );
  // JavaScript is included verbatim by template engines; type comments are code too.
  for (const [name, content] of Object.entries(files)) {
    if (name.endsWith(".js") && /\{[\{%#]/.test(content))
      throw new Error(`SSR JavaScript contains a template delimiter: ${name}`);
  }
  for (const file of readdirSync(join(packageRoot, "src/ui/fonts"))
    .filter(
      (name) =>
        name.endsWith(".woff2") ||
        name.endsWith("-LICENSE.txt") ||
        name === "sources.json",
    )
    .sort())
    files["fonts/" + file] = readFileSync(
      join(packageRoot, "src/ui/fonts", file),
    );
  const hashes = Object.fromEntries(
    Object.entries(files).map(([name, content]) => [
      name,
      createHash("sha256").update(content).digest("hex"),
    ]),
  );
  files["fingerprint.json"] =
    JSON.stringify(
      { schemaVersion: 1, package: "@pdlc/ui", files: hashes },
      null,
      2,
    ) + "\n";
  return files;
}
export function exportSsr(out, check = false) {
  const files = ssrFiles();
  if (!check) mkdirSync(out, { recursive: true });
  for (const [name, content] of Object.entries(files)) {
    if (check) {
      if (!readFileSync(join(out, name)).equals(Buffer.from(content)))
        throw new Error(`Base SSR drift: ${name}`);
    } else {
      mkdirSync(dirname(join(out, name)), { recursive: true });
      writeFileSync(join(out, name), content);
    }
  }
}
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(resolve(process.argv[1])).href
) {
  const index = process.argv.indexOf("--out");
  if (index < 0 || !process.argv[index + 1])
    throw new Error("Usage: export-ssr.mjs --out DIRECTORY [--check]");
  if (process.argv.includes("--branding-schema")) {
    const target = resolve(process.argv[index + 1], "branding-presets.json");
    const schema = sourceText(
      join(packageRoot, "reference/branding-presets.json"),
    );
    if (process.argv.includes("--check")) {
      if (sourceText(target) !== schema) throw Error("Branding schema drift");
    } else {
      mkdirSync(dirname(target), { recursive: true });
      writeFileSync(target, schema);
    }
  } else if (process.argv.includes("--auth")) {
    const target = resolve(process.argv[index + 1], "theme-tokens.css");
    if (process.argv.includes("--check")) {
      if (sourceText(target) !== authThemeStyles())
        throw new Error("Auth theme token drift");
      if (
        sourceText(
          resolve(process.argv[index + 1], "branding-bootstrap.js"),
        ) !== ssrFiles()["branding-bootstrap.js"]
      )
        throw new Error("Auth branding runtime drift");
    } else {
      writeFileSync(target, authThemeStyles());
      writeFileSync(
        resolve(process.argv[index + 1], "branding-bootstrap.js"),
        ssrFiles()["branding-bootstrap.js"],
      );
    }
  } else
    exportSsr(
      resolve(process.argv[index + 1]),
      process.argv.includes("--check"),
    );
  console.log(
    process.argv.includes("--check")
      ? "Base SSR fingerprint matches."
      : "Base SSR assets exported.",
  );
}
