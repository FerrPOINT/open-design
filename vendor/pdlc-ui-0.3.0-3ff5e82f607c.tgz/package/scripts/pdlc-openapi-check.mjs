// Fleet-shared OpenAPI tooling (from @pdlc/ui scripts). Paths are
// parameterized: SPEC (default ../openapi/openapi.yaml), SCHEMA
// (default src/api/schema.d.ts) via CLI args --spec/--schema or env.

import { spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

// Run from the service frontend dir; the script itself lives in the shared kit.
const root = process.cwd();
const argAfter = (flag, fallback) => {
  const i = process.argv.indexOf(flag);
  return i >= 0 && process.argv[i + 1] ? resolve(root, process.argv[i + 1]) : fallback;
};
const specPath = argAfter("--spec", process.env.SPEC ? resolve(root, process.env.SPEC) : resolve(root, "..", "openapi", "openapi.yaml"));
const schemaPath = argAfter("--schema", process.env.SCHEMA ? resolve(root, process.env.SCHEMA) : resolve(root, "src", "api", "schema.d.ts"));
const tempDir = mkdtempSync(join(tmpdir(), "sdlc-openapi-"));
const tempSchemaPath = join(tempDir, "schema-check.d.ts");
const require = createRequire(join(root, "package.json"));
const openapiTypescriptRoot = resolve(dirname(require.resolve("openapi-typescript")), "..");
const openapiTypescriptCli = resolve(openapiTypescriptRoot, "bin", "cli.js");

const result = spawnSync(process.execPath, [openapiTypescriptCli, specPath, "-o", tempSchemaPath], {
  cwd: root,
  stdio: "inherit",
});

if (result.status !== 0) {
  rmSync(tempDir, { force: true, recursive: true });
  process.exit(result.status ?? 1);
}

const current = readFileSync(schemaPath, "utf8").replace(/\r\n/g, "\n");
const generated = readFileSync(tempSchemaPath, "utf8").replace(/\r\n/g, "\n");
rmSync(tempDir, { force: true, recursive: true });

if (current !== generated) {
  console.error(`${schemaPath} is out of date for ${specPath}. Run pnpm openapi:generate.`);
  process.exit(1);
}
