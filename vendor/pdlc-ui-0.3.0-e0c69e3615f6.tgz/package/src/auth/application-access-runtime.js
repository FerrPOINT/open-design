// Generated from application-access-client.ts by export-application-access.mjs.
export class ApplicationAccessError extends Error {
    status;
    constructor(status, message) {
        super(message);
        this.name = "ApplicationAccessError";
        this.status = status;
    }
}
const fields = [
    "schema_version",
    "issuer",
    "subject",
    "role",
    "applications",
    "revision",
    "enforced",
    "observed_at",
    "expires_at",
];
/** UI admission is derived from the owner response; JWT role hints are never read. */
export function confirmApplicationAccess(raw, clock) {
    const invalid = () => new ApplicationAccessError(503, "Не удалось проверить контракт доступа.");
    if (!raw || typeof raw !== "object" || Array.isArray(raw))
        throw invalid();
    const value = raw;
    if (Object.keys(value).length !== fields.length ||
        fields.some((field) => !Object.hasOwn(value, field)) ||
        value.schema_version !== 1 ||
        value.issuer !== clock.issuer ||
        value.subject !== clock.subject ||
        !clock.subject ||
        typeof value.role !== "string" ||
        !["user", "admin"].includes(value.role) ||
        typeof value.enforced !== "boolean" ||
        !Number.isSafeInteger(value.revision) ||
        value.revision < 1 ||
        !Array.isArray(value.applications) ||
        value.applications.length > 128 ||
        value.applications.some((key) => typeof key !== "string" || !/^[a-z0-9-]{1,64}$/.test(key)) ||
        new Set(value.applications).size !== value.applications.length ||
        typeof value.observed_at !== "string" ||
        typeof value.expires_at !== "string")
        throw invalid();
    const observed = Date.parse(value.observed_at), expires = Date.parse(value.expires_at);
    if (![
        observed,
        expires,
        clock.startedAt,
        clock.receivedAt,
        clock.wallAtReceipt,
        clock.tokenExpiresAt,
    ].every(Number.isFinite) ||
        clock.receivedAt < clock.startedAt ||
        expires <= observed ||
        expires - observed > 60000 ||
        observed > clock.wallAtReceipt + 5000)
        throw invalid();
    const remaining = Math.min(60000, expires - clock.wallAtReceipt, clock.tokenExpiresAt - clock.wallAtReceipt);
    const deadline = clock.startedAt + remaining;
    if (remaining <= 0 || deadline <= clock.receivedAt)
        throw new ApplicationAccessError(403, "Подтверждение доступа истекло.");
    const decision = Object.freeze({
        schema_version: 1,
        issuer: clock.issuer,
        subject: clock.subject,
        role: value.role,
        applications: Object.freeze([...value.applications]),
        revision: value.revision,
        enforced: value.enforced,
        observed_at: value.observed_at,
        expires_at: value.expires_at,
    });
    return Object.freeze({ decision, deadline });
}
export function permitsApplication(access, required, administrative = false, now = performance.now()) {
    if (!access ||
        now >= access.deadline ||
        (administrative && access.decision.role !== "admin"))
        return false;
    return (access.decision.role === "admin" ||
        !access.decision.enforced ||
        required.every((key) => access.decision.applications.includes(key)));
}
export function applicationAccessBoundary(access) {
    const d = access.decision;
    return JSON.stringify([
        d.issuer,
        d.subject,
        d.role,
        d.revision,
        d.enforced,
        [...d.applications].sort(),
    ]);
}
/** Subject/expiry are correlation bounds only; the owner still verifies the bearer. */
export function browserTokenIdentity(token) {
    try {
        const parts = token.split(".");
        const payload = parts[1];
        if (token.length > 16384 || parts.length !== 3 || !payload)
            return null;
        const part = payload.replace(/-/g, "+").replace(/_/g, "/");
        const value = JSON.parse(atob(part.padEnd(Math.ceil(part.length / 4) * 4, "=")));
        if (typeof value.sub !== "string" ||
            !value.sub ||
            typeof value.exp !== "number" ||
            !Number.isFinite(value.exp))
            return null;
        return { subject: value.sub, expiresAt: value.exp * 1000 };
    }
    catch {
        return null;
    }
}
export async function loadApplicationAccess(issuer, token, subject, tokenExpiresAt, signal) {
    let endpoint;
    try {
        endpoint = new URL(issuer);
        if (!["https:", "http:"].includes(endpoint.protocol) ||
            endpoint.username ||
            endpoint.password ||
            endpoint.search ||
            endpoint.hash)
            throw new Error("invalid issuer");
        endpoint.pathname = "/auth/access";
    }
    catch {
        throw new ApplicationAccessError(503, "Не настроен источник доступа.");
    }
    const startedAt = performance.now();
    const controller = new AbortController();
    const abort = () => controller.abort(signal?.reason);
    if (signal?.aborted)
        abort();
    signal?.addEventListener("abort", abort, { once: true });
    const timeout = setTimeout(() => controller.abort(), 5000);
    try {
        const response = await fetch(endpoint.href, {
            headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
            cache: "no-store",
            credentials: "omit",
            redirect: "error",
            signal: controller.signal,
        });
        if (!response.ok)
            throw new ApplicationAccessError(response.status, "Не удалось подтвердить доступ к приложениям.");
        if (!response.body)
            throw new ApplicationAccessError(503, "Пустое подтверждение доступа.");
        const reader = response.body.getReader(), chunks = [];
        let size = 0;
        try {
            while (true) {
                const next = await reader.read();
                if (next.done)
                    break;
                size += next.value.byteLength;
                if (size > 16384) {
                    await reader.cancel();
                    throw new ApplicationAccessError(503, "Некорректное подтверждение доступа.");
                }
                chunks.push(next.value);
            }
        }
        finally {
            reader.releaseLock();
        }
        const body = new Uint8Array(size);
        let offset = 0;
        for (const chunk of chunks) {
            body.set(chunk, offset);
            offset += chunk.byteLength;
        }
        const receivedAt = performance.now();
        let wallAtReceipt = Date.now();
        const ownerDate = response.headers.get("Date");
        if (ownerDate !== null) {
            // Trust only the uncached owner transport clock, never an arbitrary body TTL.
            // HTTP Date rounds down to seconds. Charge that second and the complete
            // request/body duration so skew tolerance cannot extend the original proof.
            const ownerWall = Date.parse(ownerDate);
            const age = response.headers.get("Age");
            if (!Number.isFinite(ownerWall) ||
                !response.headers
                    .get("Cache-Control")
                    ?.split(",")
                    .some((directive) => directive.trim().toLowerCase() === "no-store") ||
                (age !== null && Number(age) !== 0))
                throw new ApplicationAccessError(503, "Не удалось проверить время доступа.");
            wallAtReceipt = ownerWall + 1000 + (receivedAt - startedAt);
        }
        return confirmApplicationAccess(JSON.parse(new TextDecoder().decode(body)), { issuer, subject, tokenExpiresAt, startedAt, receivedAt, wallAtReceipt });
    }
    catch (error) {
        if (error instanceof ApplicationAccessError)
            throw error;
        throw new ApplicationAccessError(503, "Источник доступа временно недоступен.");
    }
    finally {
        clearTimeout(timeout);
        signal?.removeEventListener("abort", abort);
    }
}
